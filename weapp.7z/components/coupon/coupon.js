// components/coupon/coupon.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    isOut: {
      type: Boolean,
      value: true
    },
    couponData: {
      type: Object,
      value: {}
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    useCoupon(event) {
      this.triggerEvent('useCoupon',event.currentTarget.dataset)
    }
  }
})

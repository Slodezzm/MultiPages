const app = getApp()

Component({
  properties: {
    needBg: {// 是否需要背景
      type: Boolean,
      default: false
    },
    len: {// 是否只显示两条数据
      type: Number,
      default: 0
    },
  },
  data: {},
  methods: {
    // 资讯列表图片加载失败
    errorFun() { }
  }
})
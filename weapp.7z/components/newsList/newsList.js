Component({
  properties: {
    list:{  //列表
      type: Array,
      default: []
    }
  }
})
// components/tabHeader/tabHeader.js
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    navStyle: {
      height: 0,
      saveTop: 0
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {

  },
  attached: function () {
    let navStyle = {
      height: app.globalData.Wechat.navHeight,
      saveTop: app.globalData.Wechat.barTop
    }
    this.setData({
      navStyle: navStyle,
    })
  },

})

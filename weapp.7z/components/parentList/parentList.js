const app = getApp()

Component({
  properties: {
    len: { // 是否只显示两条数据
      type: Number,
      default: 0
    },
    list: { //列表
      type: Array,
      default: []
    },
    showNone: {
      type: Boolean,
      default: false
    }
  },
  data: {
    role: 0, //角色1保姆 2家长
    listIndex: []
  },
  methods: {
    prev(e) {
      let i = e.currentTarget.dataset.index
      var swiper = this.properties.list;
      var current = swiper[i].current || 0;
      swiper[i].current = current > 0 ? current - 1 : this.properties.list[i].childInfoList.length - 1;
      this.setData({
        listIndex: swiper,
      })
    },
    next(e) {
      let i = e.currentTarget.dataset.index
      var swiper = this.properties.list;
      var current = swiper[i].current || 0;
      swiper[i].current = current < (this.properties.list[i].childInfoList.length - 1) ? current + 1 : 0;
      this.setData({
        listIndex: swiper,
      })
    },

    attention(e) {
      this.data.role === 2 && wx.showToast({
        title: '角色相同,不可关注',
        icon: 'none'
      })
      this.data.role === 1 && this.triggerEvent("attention", { followerUid: e.currentTarget.dataset.uid, subscribeFlag: e.currentTarget.dataset.flag, index: e.currentTarget.dataset.index })
    }
  },
  attached() {
    let userInfo = app.globalData.userInfo()
    this.setData({
      role: userInfo.role
    })
  }
})
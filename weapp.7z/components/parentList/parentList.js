const app = getApp()

Component({
  properties: {
    len: {// 是否只显示两条数据
      type: Number,
      default: 0
    },
    list:{  //列表
      type: Array,
      default: []
    }
  },
  data: {
    listIndex:[]
  },
  methods:{
    prev(e) {
      let i = e.currentTarget.dataset.index
      var swiper = this.properties.list;
      var current = swiper[i].current || 0;
      swiper[i].current = current > 0 ? current - 1 : this.properties.list[i].children.length - 1;
      this.setData({
        listIndex: swiper,
      })
    },
    next(e) {
      let i = e.currentTarget.dataset.index
      var swiper = this.properties.list;
      var current = swiper[i].current || 0;
      swiper[i].current = current < (this.properties.list[i].children.length - 1) ? current + 1 : 0;
      this.setData({
        listIndex: swiper,
      })
    },
  }
})
// components/multiSelectBox/multiSelectBox.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    nannyAdressData: {
      type: Array,
      value: []
    },
    // radio
    select: {
      type: String,
      value: 'checkbox'
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    nannyAdress: [],
    addrerssIdList: [],
    selectId: ''
  },

  /**
   * 组件的方法列表
   */
  methods: {
    selectAdderss(event) {
      let { addressid } = event.currentTarget.dataset
      if (this.properties.select === 'radio') {
        this.setData({
          selectId: addressid
        })
        this.triggerEvent('selectAdderss', addressid)
      } else {
        if (this.data.addrerssIdList.includes(addressid)) {
          let newAddrerssId = this.data.addrerssIdList.filter((item) => {
            return item !== addressid
          })
          this.setData({
            addrerssIdList: newAddrerssId
          })
        } else {
          let idList = this.data.addrerssIdList
          idList.push(addressid)
          this.setData({
            addrerssIdList: idList
          })
        }
        let newNannyAdress = this.properties.nannyAdressData.map((item) => {
          if (item.id === addressid) {
            item.isActivity = this.data.addrerssIdList.includes(addressid)
          }
          return item
        })
        this.setData({
          nannyAdress: newNannyAdress
        })
        this.triggerEvent('selectAdderss', this.data.addrerssIdList)
      }
    },
  },
  ready: function () {
    this.setData({
      nannyAdress: JSON.parse(JSON.stringify(this.properties.nannyAdressData)),
    })
  },
})

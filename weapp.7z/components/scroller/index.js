Component({
    options: {
        multipleSlots: true,
        addGlobalClass: true,
    },
    behaviors: [],
    properties: {
        refresh: {
            type: Boolean,
            value: false
        },
        loadmore: {
            type: Boolean,
            value: false
        },
        refreshStyle: {
            type: 'default'
        },
        next: {
            type: Boolean,
            value: false,
            observer() {
                
            }
        },
        scrollTop: {
            type: Number,
            optionalTypes: [String, Number],
            value: 0,
            observer(newVal) {
                this.setData({
                    scroll: newVal
                })
            }
        }
    },

    data: {
        isRefreshLoading: false,
        isLoading: false,
        triggered: false,
        lazy: null,
        scroll: 0
    },
    methods: {
        onPulling: function () {
            this.setData({
                isRefreshLoading: true,
            });
        },
        onRefresh() {
            if (this._freshing)
                return;
            this._freshing = true;
            if (this.properties.refresh) {
                wx.vibrateShort();
            }
            // wx.showNavigationBarLoading()
            setTimeout(() => {
                this.setData({
                    triggered: false
                });
                this._freshing = false;
            }, 1000);
        },
        onRestore(e) {
            this.triggerEvent("refreshEvent", {
                page: 1
            });
            setTimeout(() => {
                this.setData({
                    isRefreshLoading: false,
                });
            }, 1000);
        },
        lower: function (e) {
            if (this.data.lazy) {
                clearTimeout(this.data.lazy);
            }
            // if (this.data.scrollOption.pagination.page <= this.data.scrollOption.pagination.totalPage) {
            if (this.properties.loadmore && this.properties.next) {
                let lazy = setTimeout(() => {
                    console.log('加载开始:显示loadmore');
                    if (this.properties.loadmore) {
                        wx.vibrateShort();
                    }
                    // wx.showNavigationBarLoading()
                    this.triggerEvent("loadMoreEvent");
                }, 800);
                this.setData({
                    lazy: lazy,
                });
            }
        },
        scroll: function (e) {

            if (this.properties.loadmore && this.properties.next) {
                this.setData({
                    isLoading: true,
                });
            } else {
                this.setData({
                    isLoading: false,
                });
            }
        },
    }
})
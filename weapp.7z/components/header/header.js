// components/header/header.js
const app = getApp();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    //  返回按钮是否需要返回文字显示
    goBackText: {
      type: Boolean,
      value: false
    },
    // 返回的层数 默认为1层
    back: {
      type: Number,
      value: 1
    },
    rightTitle: {
      type: Boolean,
      value: false
    },
    bgColor: {
      type: String,
      value: '#fff'
    },
    // 白色 返回
    white:{
      type: Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    offsetTop: 0,// 顶部吸附距离
    navStyle: {
      height: 0, // bar-box 高度
      saveTop: 0, // top-bar-box padding-top
      saveWidth: 0,
      saveHeight: 0,
    },

  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 返回 
    goBack(evet) {
      wx.navigateBack({
        delta: 1,  //返回的层数
      })
    },
  },
  lifetimes: {
    attached: function () {
      let navStyle = {
        height: app.globalData.Wechat.navHeight,
        saveTop: app.globalData.Wechat.barTop,
        saveWidth: app.globalData.Wechat.topSaveWidth,
        saveHeight: app.globalData.Wechat.barHeight,
      }
      console.log(navStyle)
      this.setData({
        navStyle: navStyle
      })
    },
  },
})

const app = getApp()

Page({
  data: {

  },
  onLoad() {
    wx.getSystemInfoSync({
      success (res) {
        console.log(res)
      }
    })
  }
})
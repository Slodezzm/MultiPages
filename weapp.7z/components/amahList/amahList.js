const app = getApp()

Component({
  properties: {
    list: { //列表
      type: Array,
      default: [],
      observer(newVal) {
        if (newVal.length ) {
          this.setData({
            dataList: newVal.map(item => {
              item.nurseInfo.nurseScore = item.nurseInfo.nurseScore.toFixed(1)
              return item
            })
          })
        } else {
          this.setData({
            dataList: newVal
          })
        }
      }
    },
    showNone: {
      type: Boolean,
      default: false
    }
  },
  data: {
    role: 0, //角色1保姆 2家长
    dataList: []
  },
  methods: {
    attention(e) {
      this.data.role === 1 && wx.showToast({
        title: '角色相同,不可关注',
        icon: 'none'
      })

      this.data.role === 2 && this.triggerEvent("attention", {
        followerUid: e.currentTarget.dataset.uid,
        subscribeFlag: e.currentTarget.dataset.flag,
        index: e.currentTarget.dataset.index
      })
    }
  },
  attached() {
    let userInfo = app.globalData.userInfo()
    this.setData({
      role: userInfo.role
    })
  }
})
// components/address/address.js
const app = getApp()
import {
  throttle
} from '../../utils/util.js'
let areaList = []
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 1.弹框的高度
    // 2.是否显示
    // 3.选择的数组
    show: {
      type: Boolean,
      value: false,
      observer(newVal) {
        if (newVal) {
          this.setData({
            currTab: 0,
            toView: `view_index_${this.data.adderss[0] ?this.data.adderss[0].code : 0}`,
            loading: true
          })
          this.getAreaList({
            type: 1
          })
        }
      }
    },
    height: {
      type: Number,
      value: 300
    },
    selectedArea: {
      type: Array,
      value: [0, 0, 0, 0],
      observer(newVal) {
        this.setData({
          adderss: newVal,
          selectedAdderss: newVal[0],
        })
      }
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    loading: false,
    title: '请选择地址',
    areaList: [],
    toView: '',
    currTab: 0, // 第几级
    adderss: [0, 0, 0, 0], // 选中的省市区街道 [{},{},{},{}]
    selectedAdderss: {}, // 选中的地址
  },
  // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
  attached: function () {},
  moved: function () {},
  detached: function () {},

  /**
   * 组件的方法列表
   */
  methods: {
    hide() {
      this.triggerEvent('cancel', false)
      // this.setData({
      //   show: false
      // })
    },
    clickAdderss(e) {
      let {
        index
      } = e.currentTarget.dataset
      this.setData({
        currTab: index,
        selectedAdderss: this.data.adderss[index],
        loading: true,
      })
      this.getAreaList({
        code: index == 0 ? '' : this.data.adderss[index - 1].code,
        type: index + 1
      })
    },
    // 选择 地址
    clickArea(e) {
      let newAdderss = this.data.adderss
      let arr = newAdderss.map((item, index) => {
        if (this.data.currTab > index) {
          return item
        } else if (this.data.currTab == index) {
          return e.currentTarget.dataset.data
        } else {
          return 0
        }
      })
      this.setData({
        adderss: arr,
        selectedAdderss: e.currentTarget.dataset.data,
      })
      if (this.data.currTab < 3) {
        this.setData({
          currTab: this.data.currTab < 3 ? this.data.currTab + 1 : this.data.currTab,
          loading: this.data.currTab < 3 ? true : false
        })
        this.getAreaList({
          code: e.currentTarget.dataset.data.code,
          type: this.data.currTab + 1
        })
      }

    },
    // 确定
    confirm() {
      if (this.data.adderss[this.data.adderss.length - 2]) {
        this.triggerEvent('confirm', this.data.adderss)
        this.hide()
      } else {
        wx.showToast({
          title: '必须选择到区县',
          icon: 'none'
        })
      }

    },
    // 获取地区 list 
    getAreaList(data) {
      app.globalData.agriknow.getAreaList(data, false)
        .then(res => {
          this.setData({
            areaList: res.data.areaList.map(item => {
              item.text = item.name
              return item
            }),
            loading: false,
          })
        })
    },

  },
  pageLifetimes: {
    show: function () {
      // 页面被展示

    },
    hide: function () {
      // 页面被隐藏
    },
    resize: function (size) {
      // 页面尺寸变化
    }
  }
})
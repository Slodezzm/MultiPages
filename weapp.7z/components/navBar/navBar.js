const app = getApp()

Component({
  properties: {
    needBg: {// 是否需要背景
      type: Boolean,
      default: false
    },
    needBack: {// 返回按钮显示与否
      type: Boolean,
      default: false
    },
    backIcon: {// 返回按钮图标
      type: String,
      default: "white"
    },
    backTitle: {// 返回文本
      type: String,
      default: ""
    },
    needScan: {// 是否需要扫描
      type: Boolean,
      default: false
    },
    needSearch: {// 是否需要搜索
      type: Boolean,
      default: false
    },
    needSearchGuide: {// 是否需要搜索导航
      type: Boolean,
      default: false
    },
    needService: {// 是否需要客服按钮
      type: Boolean,
      default: false
    },
    needWechat: {// 是否需要客服按钮
      type: Boolean,
      default: false
    },
    needLetter: {// 是否需要客服按钮
      type: Boolean,
      default: false
    },
    pageTitle: {// 页面标题
      type: String,
      default: ""
    },
    scrollTop: {
      type: Number,
      default: 0
    },
    keyWord: { //搜索关键字
      type: String,
      default: ""
    },
  },
  data: {
    navStyle: {
      height: 0, // bar-box 高度
      saveTop: 0, // top-bar-box padding-top
      saveWidth: 0,
      saveHeight: 0,
    },
    value: '', //搜索关键字
  },
  methods: {
    changeValue(e) {
      this.setData({
        value: e.detail.value
      })
      this.triggerEvent("changeValue", { keyWord: e.detail.value })
    },
    searchKey() { //点击搜索
      let word = this.data.value
      let historyList = wx.getStorageSync('historyList') ? JSON.parse(wx.getStorageSync('historyList')) : []
      word && historyList.unshift(word)
      historyList = Array.from(new Set(historyList))
      historyList.length > 10 && historyList.pop()
      wx.setStorage({
        key: "historyList",
        data: JSON.stringify(historyList)
      })
      this.triggerEvent("searchKey")
    },
    toSearch() {
      wx.navigateTo({
        url: '/pages/search/search'
      })
    },
    goBack(){ //返回上一页
      wx.navigateBack({
        delta: 1
      })
    },
    scanCode() {
      wx.scanCode({
        success (res) {
          console.log(res)
        }
      })
    }
  },
  attached() {
    let navStyle = {
      height: app.globalData.Wechat.navHeight,
      saveTop: app.globalData.Wechat.barTop,
      saveWidth: app.globalData.Wechat.topSaveWidth,
      saveHeight: app.globalData.Wechat.barHeight,
    }
    console.log(this.properties.needBg)
    this.setData({
      navStyle: navStyle
    })
  }
})
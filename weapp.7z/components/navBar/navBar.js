const app = getApp()
import {
  analysisUrlParam
} from "../../utils/util";
Component({
  properties: {
    needBg: { // 是否需要背景
      type: Boolean,
      default: false
    },
    needBack: { // 返回按钮显示与否
      type: Boolean,
      default: false
    },
    backIcon: { // 返回按钮图标
      type: String,
      default: "white"
    },
    backTitle: { // 返回文本
      type: String,
      default: ""
    },
    needScan: { // 是否需要扫描
      type: Boolean,
      default: false
    },
    needSearch: { // 是否需要搜索
      type: Boolean,
      default: false
    },
    needSearchGuide: { // 是否需要搜索导航
      type: Boolean,
      default: false
    },
    needService: { // 是否需要客服按钮
      type: Boolean,
      default: false
    },
    needWechat: { // 是否需要客服按钮
      type: Boolean,
      default: false
    },
    needLetter: { // 是否需要客服按钮
      type: Boolean,
      default: false
    },
    pageTitle: { // 页面标题
      type: String,
      default: ""
    },
    scrollTop: {
      type: Number,
      default: 0
    },
    keyWord: { //搜索关键字
      type: String,
      default: ""
    },
    sendWho: {
      type: String,
      default: ""
    },
    uid: {
      type: Number,
      default: 0
    },
    bgColor:{
      type:Number,
      value:true
    }
  },
  data: {
    navStyle: {
      height: 0, // bar-box 高度
      saveTop: 0, // top-bar-box padding-top
      saveWidth: 0,
      saveHeight: 0,
    },
    value: '', //搜索关键字
    show: false,
    message: '',
    remainCount: 0, // 短信剩余次数
    sendCount: 0, //已发送次数
    autoHight: {
      minHeight: 60
    }
  },
  methods: {
    changeValue(e) {
      this.setData({
        value: e.detail.value
      })
      this.triggerEvent("changeValue", {
        keyWord: e.detail.value
      })
    },
    searchKey() { //点击搜索
      let word = this.data.value
      let historyList = wx.getStorageSync('historyList') ? JSON.parse(wx.getStorageSync('historyList')) : []
      word && historyList.unshift(word)
      historyList = Array.from(new Set(historyList))
      historyList.length > 10 && historyList.pop()
      wx.setStorage({
        key: "historyList",
        data: JSON.stringify(historyList)
      })
      this.triggerEvent("searchKey")
    },
    toSearch() {
      wx.navigateTo({
        url: '/pages/search/search'
      })
    },
    goBack() { //返回上一页
      wx.navigateBack({
        delta: 1
      })
    },
    scanCode() {
      wx.scanCode({
        success(res) {
          if (res.errMsg === 'scanCode:ok') {
            let params = analysisUrlParam(res.result)
            if (params.uid) {
              wx.navigateTo({
                url: `/pages/availableCoupon/availableCoupon?uid=${params.uid}&name=${params.name}`,
              })
            } else {
              wx.showToast({
                title: '该二维码不可用,请选择正确的二维码进行扫描',
                iconL: 'none'
              })
            }
          }
        }
      })
    },
    // 获取还有多少可发送的短信条数
    getMessageCount() {
      app.globalData.agriknow.getMessageCount({type:1})
        .then(res => {
          this.setData({
            remainCount: res.data.remainCount, // 短信剩余次数
            sendCount: res.data.sendCount, //已发送次数
          })
        })
    },
    // 点击发送短信
    sendMessage() {
      this.getMessageCount()
      this.setData({
        show: !this.data.show,
        message: ''
      })
    },
    // 关闭弹框
    oncloseMessage() {
      this.setData({
        show: false,
        message: ''
      })
    },
    // 充值
    payVip() {
      this.oncloseMessage()
      wx.navigateTo({
        url: "/pages/setMeal/setMeal"
      })
    },
    //限制发送短信输入数字长度
    changeContent(e) {
      if (e.detail.length >= 50) {
        this.setData({
          message: e.detail.substring(0, 51)
        })
        wx.showToast({
          title: '输入字数不能超过50字',
          icon: 'none'
        })
      }
    },
    // 发送短信
    send() {
      if (!this.data.remainCount) {
        wx.showToast({
          title: '短信次数不够了，快去充值吧！',
          icon: 'none'
        })
        return
      }
      if (!this.data.message) {
        wx.showToast({
          title: '请输入发送你内容！',
          icon: 'none'
        })
        return
      }
      app.globalData.agriknow.sendMessage({
          content: this.data.message,
          uid: this.properties.uid
        })
        .then(res => {
          if (res.code === 'success') {
            wx.showToast({
              title: '发送成功',
            })
            this.oncloseMessage()
          }
        })
    },
    // 联系 用户 （环信）
    connection() {
      this.triggerEvent('connection')
    }
  },
  attached() {
    let navStyle = {
      height: app.globalData.Wechat.navHeight,
      saveTop: app.globalData.Wechat.barTop,
      saveWidth: app.globalData.Wechat.topSaveWidth,
      saveHeight: app.globalData.Wechat.barHeight,
    }
    this.setData({
      navStyle: navStyle
    })
  }
})
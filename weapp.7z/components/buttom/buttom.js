// components/buttom/buttom.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    top: {
      type: Number,
      value: 30
    },
    bagcolor:{
      type:String,
      value:'#0687fcff'
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    clickBtn(){
      this.triggerEvent('clickBtn')
    }
  }
})

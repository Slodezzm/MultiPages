// components/serveTimeInterval/serveTimeInterval.js
const app = getApp()
let timeTable = [],
  week = [{
    title: "一",
    value: 'MON'
  }, {
    title: "二",
    value: 'TUE'
  }, {
    title: "三",
    value: 'WED'
  }, {
    title: "四",
    value: 'THU'
  }, {
    title: "五",
    value: 'FRI'
  }, {
    title: "六",
    value: 'SAT'
  }, {
    title: "日",
    value: 'SUN'
  }],
  times = ["6AM", "9AM", "12AM", "3PM", "6PM", "9PM", "12PM"]
Component({

  /**
   * 组件的属性列表
   */
  properties: {
    timeList: {
      type: Array,
      value: [],
    },
    theTimeList: {
      type: Array,
    },
    flag: {
      type: Boolean,
      default: false
    },
    weeksLeft: {  // weeks 的left 距离多地方使用有样式问题 传入
      type: Number,
      value: 88
    }
  },
  // 侦听器
  observers: {
    'timeList,theTimeList': function (newVal1, newVal2) {
      let theTime = newVal2.map(item => {
        item.flag = false
        return item
      })
      let timeTable = week.map(item => {
        return {
          text: item.title,
          value: item.value,
          choice: 0,
          times: [...theTime]
        }
      })
      this.setData({
        timeTable: JSON.parse(JSON.stringify(timeTable)), // 深克隆 不然导致数据改变七天都一起变
        times: theTime.map(item => {
          return item.typeName
        }),
      })
      let selectTime = []
      if (newVal1.length) {
        selectTime = this.data.timeTable.map(item => {
          newVal1.forEach(val => {
            if (item.value === val.weekDay) {
              item.times.forEach(item1 => {
                // 后台返回这个字段会变
                let serviceTime = val.serviceTimeReqs || val.serviceTimeResps
                serviceTime.forEach(val1 => {
                  if (item1.serviceTimeId === val1.serviceTimeId) {
                    item1.flag = true
                    item.choice += item1.flag ? 1 : -1
                  }
                })

              })
            }
          })
          return item
        })
      }
      selectTime.length && this.setData({
        timeTable: JSON.parse(JSON.stringify(selectTime))
      })
    },

  },
  /**
   * 组件的初始数据
   */
  data: {
    times: [],
    timeTable: [],
  },
  /**
   * 组件的方法列表
   */
  methods: {
    clearFrame() { // 清空服务时段选择
      if (!this.data.flag) return
      this.setData({
        timeTable: JSON.parse(JSON.stringify(timeTable))
      })
      this.selectedTime(this.data.timeTable)
    },
    quickChoiceFrame() { // 快速选择服务时段
      if (!this.data.flag) return
      let theTimeTable = this.data.timeTable
      theTimeTable.forEach((a, i) => {
        theTimeTable[i].choice = 0
        a.times.forEach((b, ii) => {
          if (i < 5 && ii > 0 && ii < 4) {
            theTimeTable[i].choice++
            theTimeTable[i].times[ii].flag = true
          } else {
            theTimeTable[i].times[ii].flag = false
          }
        })
      })
      this.setData({
        timeTable: theTimeTable
      })
      this.selectedTime(this.data.timeTable)
    },
    choiceWeek(e) { // 服务时段单天选择
      if (!this.data.flag) return
      let {
        index
      } = e.currentTarget.dataset
      let theTimeTable = [...this.data.timeTable],
        theTimes = [...this.data.timeTable[index].times]
      for (let i = 0; i < theTimes.length; i++) {
        theTimes[i].flag = theTimeTable[index].choice < 7
      }
      theTimeTable[index].times = [...theTimes]
      theTimeTable[index].choice = theTimeTable[index].choice < 7 ? 7 : 0
      this.setData({
        timeTable: theTimeTable
      })
      this.selectedTime(this.data.timeTable)
    },
    choiceTime(e) { // 服务某时段选择
      if (!this.data.flag) return
      let {
        index
      } = e.currentTarget.dataset
      let theTimeTable = this.data.timeTable,
        flag = 0
      theTimeTable.forEach((a, i) => {
        if (theTimeTable[i].times[index].flag) flag++
      })
      flag = flag < 7
      theTimeTable.forEach((a, i) => {
        if (theTimeTable[i].times[index].flag != flag) {
          theTimeTable[i].times[index].flag = flag
          theTimeTable[i].choice += flag ? 1 : -1
        }
      })
      this.setData({
        timeTable: theTimeTable
      })
      this.selectedTime(this.data.timeTable)
    },
    choiceFrame(e) { // 服务时段单个选择
      if (!this.data.flag) return
      let theTimeTable = this.data.timeTable
      let {
        windex,
        tindex
      } = e.currentTarget.dataset
      theTimeTable[windex].times[tindex].flag = !theTimeTable[windex].times[tindex].flag
      theTimeTable[windex].choice += theTimeTable[windex].times[tindex].flag ? 1 : -1
      this.setData({
        timeTable: theTimeTable
      })
      this.selectedTime(this.data.timeTable)
    },
    // 把数据帮暴露出去
    selectedTime(data) {
      let selectedTimeData = []
      data.forEach(item => {
        let serviceTimeReqs = []
        item.times.forEach(val => {
          if (val.flag) {
            serviceTimeReqs.push({
              serviceTimeId: val.serviceTimeId,
              timeScale: val.timeScale
            })
          }
        })
        if (serviceTimeReqs.length) {
          selectedTimeData.push({
            weekDay: item.value,
            serviceTimeReqs
          })
        }
      })
      this.triggerEvent('selectedTimeList', selectedTimeData)
    },
    // 获取时间段的基础数据
    getPointTimeList() {
      app.globalData.agriknow.getTimePointList()
        .then(res => {
          let theTime = res.data.serviceTime.map(item => {
            item.flag = false
            return item
          })
          let timeTable = week.map(item => {
            return {
              text: item.title,
              value: item.value,
              choice: 0,
              times: [...theTime]
            }
          })
          this.setData({
            timeTable: JSON.parse(JSON.stringify(timeTable)), // 深克隆 不然导致数据改变七天都一起变
            times: theTime.map(item => {
              return item.typeName
            }),
          })
        })
    },
  },

  ready: function () {
    //    this.getPointTimeList()
  },
})
Component({
  properties: {
    list: {
      type: Array,
      default: []
    }
  },
  data: {},
  attached() {
    
  }
})
Component({
  properties: {},
  data: {},
  attached() {
    
  }
})
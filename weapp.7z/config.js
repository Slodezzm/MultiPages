module.exports = {
  baseUrl:'https://c08-dev-web.kf66.live/',  // 公共域名
  // baseUrl: 'https://c08-test-web.kf66.live/',
  h5Url: 'https://c08-dev-admin.kf66.live/', // webview 静态页面
  // huanxinKey:'1100210513091632#cl-childcare-test', // 环信key 测试
  huanxinKey: '1100210513091632#cl-childcare-dev' // 环信key 开发
}
// app.js
import agriknow from '/utils/agriknow'
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        console.log(res)
        console.log()
      }
    })

    const sInfo = wx.getSystemInfoSync()
    const mInfo = wx.getMenuButtonBoundingClientRect()
    let Wechat = {
      clientWidth: sInfo.screenWidth,// 设备宽
      clientHeight: sInfo.screenHeight,// 设备高
      pixelRatio: sInfo.pixelRatio,// 逻辑像素比
      system: sInfo.system,// 系统信息
      version: sInfo.version,// 微信版本
      battery: sInfo.batteryLevel, // 电池电量/%
      barTop: mInfo.top,// 胶囊[*]顶部距离[&]
      barLeft: mInfo.left,// **左边&&
      barRight: sInfo.screenWidth - mInfo.right,// **右侧&&
      barWidth: mInfo.width,// **宽
      barHeight: mInfo.height,// **高
      topSaveWidth: 0, // 顶部安全宽度
      navHeight: 0, // 顶部高度
      isIphoneX: false, // 是不是 iPhone X 
    }
    Wechat.topSaveWidth = Wechat.clientWidth - Wechat.barWidth - Wechat.barRight
    Wechat.navHeight = Wechat.barTop + Wechat.barHeight + Wechat.barRight * 2
    Wechat.navHeight = Wechat.barTop + Wechat.barHeight + Wechat.barRight * 2
    Wechat.isIphoneX = sInfo.model.search('iPhone X') != -1 ? true : false
    this.globalData.Wechat = Wechat
    if (wx.getStorageSync('userInfo')) this.globalData.userInfo = JSON.parse(wx.getStorageSync('userInfo'))
  },
  globalData: {
    userInfo: null,
    Wechat: null,
    agriknow: new agriknow(), // 封装的调用接口 request 
  }
})
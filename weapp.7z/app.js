// app.js
import agriknow from '/utils/agriknow'
import {
  formatTime,
  setStorageChat,
  commentTimeHandle
} from './utils/util'
let WebIM = wx.WebIM = require("utils/WebIM")["default"];
let disp = require("utils/broadcast");
App({
  globalData: {
    userInfo: null,
    Wechat: null,
    agriknow: new agriknow(), // 封装的调用接口 request 
    openid: null,
    // newMessageNum: 0, // 消息列表新消息 tab显示红点
    chatList: [], // 聊天列表
    nonetwork: false //判断是否有网络
  },
  onShow() {
    this.onNetworkStatusChange() //开启检测
  },

  onLaunch() {
    var self = this;
    // 监听环信
    WebIM.conn.listen({
      // 连接成功
      onOpened(message) {
        console.log('im登录成功')
        // self.getChatList()
        // wx.getSetting({
        //   success(res) {

        //   }
        // })

      },
      //收到文本消息
      onTextMessage: function (message) {
        if (message) {
          self.ack(message)
          message.time = formatTime(new Date(parseInt(message.time)))
          disp.fire('app.onTextMessage', JSON.parse(JSON.stringify(message)))
          // 缓存聊天记录
          setStorageChat('set', `${message.to}_${message.from}`, message, 'chat')
          // 收到消息+1

        }
      },
      // 收到语音
      onAudioMessage(message) {
        if (message) {
          self.ack(message)
          message.time = formatTime(new Date(parseInt(message.time)))
          disp.fire('app.onAudioMessage', JSON.parse(JSON.stringify(message)))
          // 缓存聊天记录
          setStorageChat('set', `${message.to}_${message.from}`, message, 'chat')
          // 收到消息+1
          // sel.globalData.newMessageNum += 1
        }
      },
      // 消息发送到服务器后的消息后返回的id
      onReceivedMessage(message) {
        disp.fire('app.received.onTextMessage', JSON.parse(JSON.stringify(message)))
      },
      // 关闭回调
      onClosed() {
        WebIM.conn.close();
      },
      // 已读回执
      onReadMessage(message) {
        disp.fire("app.read.onTextMessage", message);
      },
      // 处理订阅
      onPresence(message) {

      },
      // 各种异常
      onError(error) {
        if (error.type == 40) { //send msg fail
        }
        // 16: server-side close the websocket connection
        if (error.type == WebIM.statusCode.WEBIM_CONNCTION_DISCONNECTED) {
          if (WebIM.conn.autoReconnectNumTotal >= WebIM.conn.autoReconnectNumMax) {
            wx.showToast({
              title: "server-side close the websocket connection",
              duration: 1000
            });
            WebIM.conn.close();
          }
          return
        }
        // 8: offline by multi login
        if (error.type == WebIM.statusCode.WEBIM_CONNCTION_SERVER_ERROR) {
          wx.showToast({
            title: "offline by multi login",
            duration: 1000
          });
        }
        if (error.type == WebIM.statusCode.WEBIM_CONNCTION_OPEN_ERROR) {
          wx.hideLoading()
          // wx.showModal({
          //   title: "用户名或密码错误",
          //   confirmText: "OK",
          //   showCancel: false
          // });
        }
        if (error.type == WebIM.statusCode.WEBIM_CONNCTION_AUTH_ERROR) {
          wx.hideLoading()
        }
        if (error.type == 16) { ///sendMsgError
          // https://developers.weixin.qq.com/community/develop/doc/00084a400202787b54f8c9e6357800
          // 因为上面的原因 这里不要一直提示了
          return
        }
      },
    })
    // 判断环信是否登录
    if (!WebIM.conn.isOpened()) {
      let huanxinInfo = wx.getStorageSync('huanxin_info')
      if (huanxinInfo) {
        let userInfo = JSON.parse(huanxinInfo)
        this.hLogin(userInfo.username, userInfo.password)
      }
    }
    const sInfo = wx.getSystemInfoSync()
    const mInfo = wx.getMenuButtonBoundingClientRect()
    let Wechat = {
      clientWidth: sInfo.screenWidth, // 设备宽
      clientHeight: sInfo.screenHeight, // 设备高
      pixelRatio: sInfo.pixelRatio, // 逻辑像素比
      system: sInfo.system, // 系统信息
      version: sInfo.version, // 微信版本
      battery: sInfo.batteryLevel, // 电池电量/%
      barTop: mInfo.top, // 胶囊[*]顶部距离[&]
      barLeft: mInfo.left, // **左边&&
      barRight: sInfo.screenWidth - mInfo.right, // **右侧&&
      barWidth: mInfo.width, // **宽
      barHeight: mInfo.height, // **高
      topSaveWidth: 0, // 顶部安全宽度
      navHeight: 0, // 顶部高度
      isIphoneX: false, // 是不是 iPhone X 
    }
    Wechat.topSaveWidth = Wechat.clientWidth - Wechat.barWidth - Wechat.barRight
    Wechat.navHeight = Wechat.barTop + Wechat.barHeight + Wechat.barRight * 2
    Wechat.navHeight = Wechat.barTop + Wechat.barHeight + Wechat.barRight * 2
    console.log(sInfo.model, '机型')
    // 判断是否是苹果11及以上手机  top44是苹果样式不一
    if (sInfo.safeArea.top > 20 && sInfo.model.indexOf("iPhone") > -1) {
      Wechat.isIphoneX = true;
    } else {
      Wechat.isIphoneX = false;
    }
    console.log(Wechat.isIphoneX)
    this.globalData.Wechat = Wechat
    this.globalData.userInfo = () => {
      return wx.getStorageSync('userInfo') ? JSON.parse(wx.getStorageSync('userInfo')) : ''
    }
  },
  /**
   *  登录后的处理
   * @param {*} userInfo 登录后的用户信息
   * @param {*} register 是否是注册 默认不是
   */
  loginHandle(userInfo, register = false) {
    // 把用户信息 和token设置在本地
    wx.setStorageSync("token", userInfo.data.token)
    this.getCenterInfo(false).then((res) => {
      // 获取环信账号信息
      this.getHuanxinInfo()
      wx.setStorageSync("userInfo", JSON.stringify(res))

    })
    if (userInfo.data.role || !register) {
      wx.showToast({
        title: '登录成功',
        icon: 'info',
        duration: 2000,
        success: function () {
          wx.switchTab({
            url: '/pages/home/home'
          })
        }
      })
    } else {
      wx.navigateTo({
        url: '/pages/selectiveID/selectiveID'
      })
    }

  },
  // 环信登录
  hLogin(name, passwword) {
    // 登录环信
    WebIM.conn.open({
      apiUrl: WebIM.config.apiURL,
      user: name,
      pwd: passwword,
      // pwd: '2145240043ad3d7a98f60f0794f40964',
      grant_type: 'password',
      appKey: WebIM.config.appkey,
      success(token) {
        console.log('im登录成功')
      },
    })
  },
  // 获取环信账号密码
  getHuanxinInfo() {
    this.globalData.agriknow.getHuanxinInfo()
      .then(res => {
        wx.setStorageSync("huanxin_info", JSON.stringify(res.data))
        this.hLogin(res.data.username, res.data.password)
      })
  },
  // 执行回执
  ack(receiveMsg) {
    var bodyId = receiveMsg.id; // 需要发送已读回执的消息id
    var ackMsg = new WebIM.message("read", WebIM.conn.getUniqueId());
    ackMsg.set({
      id: bodyId,
      to: receiveMsg.from
    });
    WebIM.conn.send(ackMsg.body);
  },
  //会话列表
  getChatList(loading = false) {
    loading && wx.showLoading()
    return new Promise((resovle, reject) => {
      WebIM.conn.getSessionList().then((res) => {
          this.globalData.chatList = res.data.channel_infos.map(item => {
              item.meta.time = commentTimeHandle(new Date(item.meta.timestamp).getTime())
              item.meta.payload = JSON.parse(item.meta.payload)
              return item
            }),
            loading && wx.hideLoading()
          resovle()
        })
        .catch(err => {
          wx.showToast({
            title: '请求出错了',
            icon: 'none'
          })
          reject(err)
        })
    })
  },
  // 获取个人中心数据
  getCenterInfo(loading) {
    return new Promise((resolve, reject) => {
      this.globalData.agriknow.getUserCenterInfo(loading)
        .then(res => {
          this.globalData.userCenterInfo = res.data
          resolve(res.data)
        })
        .catch(err => {
          wx.showModal({
            content: err.data.message,
            showCancel: false,
            success(res) {
              wx.redirectTo({
                url: '/pages/login/login'
              })
              wx.removeStorageSync('token')
              wx.removeStorageSync('userInfo')
              wx.removeStorageSync('huanxin_info')
            }
          })
          reject(err)
        })
    })
  },
  // 监听网络 做相对处理
  onNetworkStatusChange() {
    var that = this
    //获取网络类型
    wx.getNetworkType({
      success: function (res) {
        const networkType = res.networkType
        //不为none代表有网络
        if ('none' != networkType) {
          that.globalData.nonetwork = true
          //网络状态变化事件的回调函数   开启网络监听，监听小程序的网络变化
          wx.onNetworkStatusChange(function (res) {
            console.log('网络问题')
            if (res.isConnected) {
              //网络变为有网
              that.globalData.nonetwork = true
            } else {
              //网络变为无网
              that.globalData.nonetwork = false
              wx.showToast({
                title: '网络好像有点问题哦',
                icon: 'none'
              })
            }
          })
        } else {
          //无网状态
          wx.onNetworkStatusChange(function (res) {
            console.log('网络问题')
            if (res.isConnected) {
              that.globalData.nonetwork = true
            } else {
              that.globalData.nonetwork = false
              wx.showToast({
                title: '网络好像有点问题哦',
                icon: 'none'
              })
            }
          })
        }
      },
    })
  },
  // 支付 
  playMoney(openId, orderNo) {
    return new Promise((resolve, reject) => {
      this.globalData.agriknow.wechatPlaceOrder({
          orderNo,
          openid: openId
        }, false)
        .then(res => {
          if (res.code === 'success') {
            resolve(res)
          } else {
            wx.showToast({
              title: '支付失败',
              icon: 'none'
            })
            reject(res)
          }
        })
        .catch(err => {
          reject(err)
        })
    })

  }
})
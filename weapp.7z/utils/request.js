/**
 * name: api.js
 * description: request处理基础类
 */
import {
  baseUrl
} from '../config.js'
class request {
  constructor() {
    this._baseUrl = baseUrl // 公共域名
  }
  //
  _header = () => {
    return {
      'data-tupe': 'application/json',
      'token': wx.getStorageSync('token') ? wx.getStorageSync('token') : ''
    }
  }
  /**
   * 设置统一的异常处理 
   */
  setErrorHandler(handler) {
    this._errorHandler = handler;
  }
  /**
   * GET类型的网络请求
   */
  getRequest({
    url,
    data,
    loading,
    header = this._header()
  }) {
    return this.requestAll(url, data, loading, header, 'GET', )
  }
  /**
   * DELETE类型的网络请求
   */
  deleteRequest({
    url,
    data,
    loading,
    header = this._header()
  }) {
    return this.requestAll(url, data, loading, header, 'DELETE')
  }
  /**
   * PUT类型的网络请求
   */
  putRequest({
    url,
    data,
    loading,
    header = this._header()
  }) {
    return this.requestAll(url, data, loading, header, 'PUT')
  }
  /**
   * POST类型的网络请求
   */
  postRequest({
    url,
    data,
    loading,
    header = this._header()
  }) {
    return this.requestAll(url, data, loading, header, 'POST')
  }
  /** */
  upload({
    url,
    file,
    header = this._header()
  }) {
    return this.requestUpload(url, file, header, 'POST')
  }

  /**
   * 网络请求
   */
  requestAll(url, data, loading = true, header, method) {
    loading && wx.showLoading({
      title: '加载中',
      mask: true
    })
    return new Promise((resolve, reject) => {
      wx.request({
        url: this._baseUrl + url,
        data: data,
        header: header,
        method: method,
        timeout: 6000,
        success: (res => {
          loading && wx.hideLoading()
          if (res.data.code === 'success') {
            resolve(res)
          } else {
            wx.showToast({
              title: res.data.msg || res.data.message || '请求出错了',
              icon: 'none'
            })
            //其它错误，提示用户错误信息
            if (this._errorHandler != null) {
              //如果有统一的异常处理，就先调用统一异常处理函数对异常进行处理
              this._errorHandler(res.data)
            }
            reject(res)
          }
        }),
        fail: (res => {
          loading && wx.hideLoading()
          wx.showToast({
            title: '好像出了点问题哦',
            icon: 'none'
          })
          if (this._errorHandler != null) {
            this._errorHandler(res.data)
          }
          reject(res)
        }),

      })
    })
  }
  /**
   * 上传文件
   */
  requestUpload(url, file, header, method) {
    return new Promise((resolve, reject) => {
      wx.uploadFile({
        url: this._baseUrl + url,
        filePath: file.url,
        header: header,
        name: 'file',
        method: method,
        formData: {
          'user': 'test'
        },
        success: (res => {
          let data = JSON.parse(res.data)
          if (data.code === 'success') {
            //success: 服务端业务处理正常结束
            resolve(data)
          } else {
            //其它错误，提示用户错误信息
            if (this._errorHandler != null) {
              //如果有统一的异常处理，就先调用统一异常处理函数对异常进行处理
              this._errorHandler(data)
            }
            reject(data)
          }
        }),
        fail: (res => {
          if (this._errorHandler != null) {
            this._errorHandler(res.data)
          }
          reject(res)
        }),
        complete: (res => {
          console.log(res, '上传')
        })
      })
    })
  }
}

export default request
/**
 * name: agriknow.js
 */
import request from './request.js'

// 获取是否有token
let getToken = wx.getStorageSync('token')
class agriknow {
  constructor() {
    this._defaultHeader = {
      'data-tupe': 'application/json',
      'token': getToken || ''
    }
    this._request = new request
    this._request._header = this._defaultHeader
    this._request.setErrorHandler(this.errorHander)  // 异常处理
  }
  /**
   * 统一的异常处理方法
   */
  errorHander(res) {
    console.error(res.msg)
    wx.showToast({
      title: res.msg,
      icon: 'none',
    })
  }
  /** 
   * 登录注册
   */
  login(data) {
    return this._request.postRequest('user/login/login', data).then(res => res.data)
  }
  /** 
  * 小程序临时code换openid
  */
  getOpenId(data) {
    return this._request.getRequest('user/wechat/getOpenId', data).then(res => res.data)
  }
  /** 
   * 小程序加密字符串解密
   */
  getPhone(data) {
    return this._request.postRequest('/wechat/getPhone', data).then(res => res.data)
  }
  /** 
   * 选择身份
   */
  chooseRole(role) {
    console.log(getToken)
    return this._request.getRequest('user/user/chooseRole', role).then(res => res.data)
  }
  // 
  /** 
  * 上传接口
  */
  uploadFile(file, useType) {
    return this._request.upload('user/resource/upload?useType=' + useType, file).then(res => res.data)
  }

  //家长
  /** 获取孩子信息list
   */
  getParentChildList() {
    return this._request.getRequest('user/child/get_parent_child_list').then(res => res.data)
  }
  /** 删除孩子信息
 */
  deleteChildInfo(data) {
    return this._request.postRequest('user/child/delete_child_info', data).then(res => res.data)
  }
  /** 新增编辑孩子资料
    */
  addAndUpdateChildInfo(data) {
    return this._request.postRequest('user/child/update_parent_child_info', data).then(res => res.data)
  }
  /** 获取孩子详细资料
  */
  getChildInfo(id) {
    return this._request.getRequest('user/child/get_child_detail_info', { id }).then(res => res.data)
  }
  // 
  /**获取家长账号设置数据
  */
  getParentsSetAccountInfo(data) {
    return this._request.getRequest('user/user/get_user_info', data).then(res => res.data)
  }
  /**保存家长账号设置
  */
  updataParentsSetAccount(data) {
    return this._request.postRequest('user/user', data).then(res => res.data)
  }
  /**获取招聘列表
  */
  getJobList(data) {
    return this._request.postRequest('order/job/query_parent_job_list', data).then(res => res.data)
  }
  /**发布招聘
   */
  publishParentsJob(data) {
    return this._request.postRequest('order/job/publish_parent_job', data).then(res => res.data)
  }
  /**获取地址
   */
  getAreaList(data) {
    return this._request.postRequest('user/user/address/init/query_area_list', data).then(res => res.data)
  }
  /**获取托育时间段
   */
  getTimePointList() {
    return this._request.getRequest('user/service-time/get_time_point_list').then(res => res.data)
  }
  /**查询符合条件的数量
    */
  getFitJobCount(data) {
    return this._request.postRequest('user/nurse/query_fit_job_count', data).then(res => res.data)
  }
  /** 获取 保姆专业证书
     */
  getNannyCertificate() {
    return this._request.getRequest('user/user/nurse/get_service_certificate_list').then(res => res.data)
  }
  // 保姆
}
export default agriknow

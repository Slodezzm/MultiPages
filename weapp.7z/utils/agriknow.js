/**
 * name: agriknow.js
 */
import request from './request.js'
class agriknow {
  constructor() {
    this._request = new request
    this._request.setErrorHandler(this.errorHander) // 异常处理
  }
  /**
   * 统一的异常处理方法
   */
  errorHander(res) {
    console.error(res)
  }
  /** 
   * 登录注册
   */
  login(data, loading) {
    return this._request.postRequest({url:'user/login/login', data, loading}).then(res => res.data)
  }
  /** 
   * 小程序临时code换openid
   */
  getOpenId(data, loading) {
    return this._request.getRequest({
      url: 'user/wechat/getOpenId',
      data,
      loading
    }).then(res => res.data)
  }
  /** 
   * 小程序加密字符串解密
   */

  getToken(data, loading) {
    return this._request.postRequest({url:'user/wechat/getToken', data, loading}).then(res => res.data)
  }
  /** 
   * 选择身份
   */
  chooseRole(data, loading) {
    return this._request.getRequest({url:'user/user/chooseRole', data, loading}).then(res => res.data)
  }
  /** 
   * 获取个人中心信息 
   */
  getUserCenterInfo(loading) {
    return this._request.getRequest({
      url: 'user/user/get_user_center_info',
      loading
    }).then(res => res.data)
  }

  /** 
   * 上传接口
   */
  uploadFile(file, useType, loading) {
    return this._request.upload({url:'user/resource/upload?useType=' + useType, file, loading}).then(res => res.data)
  }

  //家长
  /** 获取孩子信息list
   */
  getParentChildList(loading) {
    return this._request.getRequest({
      url: 'user/child/get_parent_child_list',
      loading
    }).then(res => res.data)
  }
  /** 删除孩子信息
   */
  deleteChildInfo(childId, loading) {
    return this._request.postRequest({url:`user/child/delete_child_info?childId=${childId}`, loading}).then(res => res.data)
  }
  /** 新增编辑孩子资料
   */
  addAndUpdateChildInfo(data, loading) {
    return this._request.postRequest({url:'user/child/update_parent_child_info', data, loading}).then(res => res.data)
  }
  /** 获取孩子详细资料
   */
  getChildInfo(id, loading) {
    return this._request.getRequest({
      url: 'user/child/get_child_detail_info',
      data: {id},
      loading
    }).then(res => res.data)
  }
  // 
  /**获取家长保姆账号设置数据
   */
  getParentsSetAccountInfo(data, loading) {
    return this._request.getRequest({url:'user/user/get_user_info', data, loading}).then(res => res.data)
  }
  /**保存家长账号设置
   */
  updataParentsSetAccount(data, loading) {
    return this._request.postRequest({url:'user/user/update_parent_info', data, loading}).then(res => res.data)
  }
  /**获取招聘列表
   */
  getJobList(data, loading) {
    return this._request.postRequest({url:'order/job/query_parent_job_list', data, loading}).then(res => res.data)
  }
  /**开启关闭招聘
   */
  updateJobSwitch(data, loading) {
    return this._request.getRequest({url:'order/job/updateJobSwitch', data, loading}).then(res => res.data)
  }
  /**判断时候有发布招聘次数
   */
  checkPublishCount(data, loading) {
    return this._request.getRequest({url:'order/job/checkPublishCount', data, loading}).then(res => res.data)
  }
  /**发布招聘
   */
  publishParentsJob(data, loading) {
    return this._request.postRequest({url:'order/job/publish_parent_job', data, loading}).then(res => res.data)
  }
  /**编辑招聘拉取信息
   */
  getJobInfo(data, loading) {
    return this._request.getRequest({url:'order/job/get_job_info', data, loading}).then(res => res.data)
  }
  /**获取地址
   */
  getAreaList(data, loading) {
    return this._request.postRequest({url:'user/address/init/query_area_list', data, loading}).then(res => res.data)
  }
  /**获取托育时间段
   */
  getTimePointList(loading) {
    return this._request.getRequest({url:'user/service-time/get_time_point_list', loading}).then(res => res.data)
  }
  /**查询符合条件的数量
   */
  getFitJobCount(data, loading) {
    return this._request.postRequest({url:'user/nurse/query_fit_job_count', data, loading}).then(res => res.data)
  }
  /** 获取 保姆专业证书
   */
  getNannyCertificate(loading) {
    return this._request.getRequest({url:'user/nurse/get_service_certificate_list', loading}).then(res => res.data)
  }
  /** 获取会员套餐的套餐列表
   */
  getProgramList(data, loading) {
    return this._request.postRequest({url:'order/program/get_program_list', data, loading}).then(res => res.data)
  }
  /** 获取会员套餐的购买兑换记录列表
   */
  getOrderAndExchangeList(data, loading) {
    return this._request.getRequest({url:'order/program/get_order_and_exchange_list', data, loading}).then(res => res.data)
  }
  /** 购买套餐 下单 获取订单id 
   */
  userProgramPurchase(data, loading) {
    return this._request.getRequest({url:'order/program/user_program_purchase', data, loading}).then(res => res.data)
  }
  /** 根据订单id 获取订单信息
   */
  getOrderInfo(data, loading) {
    return this._request.getRequest({url:'order/program/get_order_info', data, loading}).then(res => res.data)
  }
  /** 获取我的卡券列表
   */
  getCouponList(data, loading) {
    return this._request.getRequest({url:'order/coupon/get_my_coupon_list', data, loading}).then(res => res.data)
  }
  /** 清空无效优惠券
   */
  clearCoupon(data, loading) {
    return this._request.postRequest({url:'order/coupon/clean_non_coupon', data, loading}).then(res => res.data)
  }
  /** 获取banner 图
   */
  getBannerList(data, loading) {
    return this._request.postRequest({url:'information/banner/query_banner_list', data, loading}).then(res => res.data)
  }

  /**获取家长关注列表
   */
  getParentFocusList(data, loading) {
    return this._request.postRequest({url:'order/job/query_subscribe_list', data, loading}).then(res => res.data)
  }
  /**获取家长列表 
   */
  getParentList(data, loading) {
    return this._request.postRequest({url:'order/job/query_job_list', data, loading}).then(res => res.data)
  }
  // 搜索
  search(data, loading) {
    return this._request.getRequest({url:'order/job/search', data, loading}).then(res => res.data)
  }
  // 保姆
  /**获取保姆关注列表
   */
  getamahFocusList(data, loading) {
    return this._request.postRequest({url:'user/nurse/query_subscribe_list', data, loading}).then(res => res.data)
  }
  /** 获取保姆技能列表
   */
  getServiceSkillList(loading) {
    return this._request.getRequest({url:'user/nurse/get_service_skill_list', loading}).then(res => res.data)
  }
  /** 保姆账号设置提交资料
   */
  updateNurseInfo(data, loading) {
    return this._request.postRequest({url:'user/nurse/update_nurse_info', data, loading}).then(res => res.data)
  }
  /** 保姆账号设置 回显编辑数据
   */
  getNurseInfo(data, loading) { // 获取保姆信息详情
    return this._request.getRequest({url:'user/nurse/get_nurse_info', data, loading}).then(res => res.data)
  }
  /** 保姆账号设置 回显编辑数据 资料上传页面  
   */
  getNurseCertificateList(loading) {
    return this._request.getRequest({url:'user/nurse/get_nurse_certificate_list', loading}).then(res => res.data)
  }
  /** 保姆账号设置 回显编辑数据 托育服务页面  
   */
  getNurseServiceInfo(loading) {
    return this._request.getRequest({url:'user/user/get_nurse_service_info', loading}).then(res => res.data)
  }
  /** 扫码后 家长显示的可用券
   */
  getScancodeCouponList(data, loading) {
    return this._request.postRequest({url:`order/coupon/query_scan_code_coupon_list?pageNo=${data.pageNo}&pageSize=${data.pageSize}`, loading}).then(res => res.data)
  }
  /** 使用优惠券
   */
  useCoupon(data, loading) {
    return this._request.postRequest({url:`order/coupon/use_coupon`, data, loading}).then(res => res.data)
  }
  /** 优惠券使用记录列表
   */
  getCouponExchangeList(data, loading) {
    return this._request.postRequest({url:`order/coupon/query_coupon_exchange_list`, data, loading}).then(res => res.data)
  }

  /**获取保姆列表
   */
  getAmahList(data, loading) {
    return this._request.postRequest({url:'user/nurse/query_nurse_list', data, loading}).then(res => res.data)
  }
  /**获取家长求助列表
   */
  getParentsList(data, loading) {
    return this._request.postRequest({url:'order/job/query_job_list', data, loading}).then(res => res.data)
  }
  // 资讯
  /**获取资讯列表
   */
  getNewsList(data, loading) {
    return this._request.postRequest({url:'information/new/query_new_list', data, loading}).then(res => res.data)
  }
  /**
   * 获取资讯分类列表
   */
  sortOfNews(loading) {
    return this._request.getRequest({url:'information/category/get_new_classify_list', loading}).then(res => res.data)
  }
  // 关注
  /**获取资讯列表
   */
  attention(data, loading) {
    return this._request.postRequest({url:'user/subscribe/subscribe', data, loading}).then(res => res.data)
  }
  /**发送短信剩余次数
   */
  getMessageCount({type},loading) {
    return this._request.getRequest({
      url: `order/message/get_send_message_count?type=${type}`,
      loading
    }).then(res => res.data)
  }
  /**发送短信 
   */
  sendMessage(data, loading) {
    return this._request.postRequest({url:'order/message/send_message', data, loading}).then(res => res.data)
  }
  /**短信发送记录list
   */
  messageList(data, loading) {
    return this._request.postRequest({url:'order/message/send_message_list', data, loading}).then(res => res.data)
  }
  /**环信获取用户信息
   */
  getHuanxinInfo(loading) {
    return this._request.getRequest({
      url: 'user/huanxin/getUserInfo',
      loading
    }).then(res => res.data)
  }
  getAmahReviewList(data, loading) { // 获取保姆评价列表
    return this._request.postRequest({url:'order/user-evaluate/query_nurse_evaluate_list', data, loading}).then(res => res.data)
  }
  reviewToAmah(data, loading) { //评价保姆
    return this._request.postRequest({url:'order/user-evaluate/evaluate_nurse', data, loading}).then(res => res.data)
  }
  toggleMyPage(data, loading) { //打开或者关闭个人主页
    return this._request.getRequest({
      url: 'user/user/set_home_switch',
      data,
      loading
    }).then(res => res.data)
  }
  getNewsDetail(data, loading) {
    return this._request.getRequest({
      url: 'information/new/get_new_info',
      data,
      loading
    }).then(res => res.data)
  }
  /**获取随机客服
   */
  getKefu(loading) {
    return this._request.getRequest({url: 'user/huanxin/kefu',loading}).then(res => res.data)
  }
   /**聊天记录 
   */
  getChatRecord(data,loading) {
    return this._request.postRequest({url: `user/huanxin/getUserChatMsg`,data,loading}).then(res => res.data)
  }
   /**客服提示语
   */
  getServiceHint(data,loading) {
    return this._request.getRequest({url: `user/dict/get_dict_info`,data,loading}).then(res => res.data)
  }
    /**小程序支付获取参数
   */
  wechatPlaceOrder({orderNo,openid},loading) {
    return this._request.getRequest({url: `pay/wechat/micro_app_static_place_order?orderNo=${orderNo}&openId=${openid}`,loading}).then(res => res.data)
  }

} 
export default agriknow
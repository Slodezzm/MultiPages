/**
 * 年月日时分秒
 * @param {*} date 
 * @returns 
 */
const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`
}
/**
 * 年月
 * @param {*} n 
 * @returns 
 */
const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}
const formatDay = (time, format) => {
  const date = new Date(time)
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  if (format) {
    return `${year}-${month < 10 ? '0' + month : month}-${day < 10 ? '0' + day : day}`
  } else {
    return `${year}年 ${month}月 ${day}日`
  }
}
/**
 * 校验手机号码
 * @param {*} data 
 * @returns 
 */
const rulePhone = (data) => {
  if (!data) return false
  let reg = /^[1]\d{10}$/
  return reg.test(data)
}
/**
 * 校验密码
 * 含有字母数字组成 大于6位小于 15位
 * @param {*} password 
 */
const rulePassword = (password) => {
  if (!password) return false
  let reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,15}$/
  return reg.test(password)
}
/**
 * 校验验证码
 * @param {} code 
 */
const ruleCode = (code) => {}
/**
 * 节流
 * @param {*} callback 
 * @param {*} time 
 */
var throttle = (fn, interval) => {
  var enterTime = 0; //触发的时间
  var gapTime = interval || 500; //间隔时间，如果interval不传，则默认300ms
  return function () {
    var context = this;
    var backTime = new Date(); //第一次函数return即触发的时间
    if (backTime - enterTime > gapTime) {
      fn()
      enterTime = backTime; //赋值给第一次触发的时间，这样就保存了第二次触发的时间
    }
  };
}
/**
 * @param {*} type  获取get 设置set
 * name 自己名字 加 对方名字 例如  aaa_bbb   
 * 设置 列表存储 name+list  例如 aaa_list
 * @param {*} name 
 * @param {*} message  消息内容 列表 就是列表的list
 */
var setStorageChat = (type, name, message, chat) => {
  if (type === 'get') {
    return wx.getStorageSync(name)
  } else if (type === 'set') {
    // 判断是否已经有存储的
    if (wx.getStorageSync(name)) {
      let oldData = wx.getStorageSync(name)
      if (chat === 'chat' && oldData.length >= 10) {
        oldData.shift()
        oldData.push(message)
        wx.setStorageSync(name, oldData)
      } else {
        wx.setStorageSync(name, [...oldData, message])
      }

    } else {
      wx.setStorageSync(name, [message])
    }
  }
}
/**
 * 
 * @param {*} dateStr 时间戳
 */
function commentTimeHandle(dateStr) {
  var publishTime = dateStr / 1000, //获取dataStr的秒数  打印结果--1536230820000
    date = new Date(publishTime * 1000), //获取dateStr的标准格式 console.log(date) 打印结果  Thu Sep 06 2018 18:47:00 GMT+0800 (中国标准时间)
    // 获取date 中的 年 月 日 时 分 秒
    Y = date.getFullYear(),
    M = date.getMonth() + 1,
    D = date.getDate(),
    H = date.getHours(),
    m = date.getMinutes(),
    s = date.getSeconds();
  // 对 月 日 时 分 秒 小于10时, 加0显示 例如: 09-09 09:01
  if (M < 10) {
    M = '0' + M;
  }
  if (D < 10) {
    D = '0' + D;
  }
  if (H < 10) {
    H = '0' + H;
  }
  if (m < 10) {
    m = '0' + m;
  }
  if (s < 10) {
    s = '0' + s;
  }
  var nowTime = new Date().getTime() / 1000, //获取此时此刻日期的秒数
    diffValue = nowTime - publishTime, // 获取此时 秒数 与 要处理的日期秒数 之间的差值
    diff_days = parseInt(diffValue / 86400), // 一天86400秒 获取相差的天数 取整
    diff_hours = parseInt(diffValue / 3600), // 一时3600秒
    diff_minutes = parseInt(diffValue / 60),
    diff_secodes = parseInt(diffValue);

  if (diff_days > 0 && diff_days < 3) { //相差天数 0 < diff_days < 3 时, 直接返出
    return diff_days + "天前";
  } else if (diff_days <= 0 && diff_hours > 0) {
    return diff_hours + "小时前";
  } else if (diff_hours <= 0 && diff_minutes > 0) {
    return diff_minutes + "分钟前";
  } else if (diff_secodes < 60) {
    if (diff_secodes <= 0) {
      // 刚刚
      return "";
    } else {
      return diff_secodes + "秒前";
    }
  } else if (diff_days >= 3 && diff_days < 30) {
    return M + '-' + D + ' ' + H + ':' + m;
  } else if (diff_days >= 30) {
    return Y + '-' + M + '-' + D + ' ' + H + ':' + m;
  }
}
/**
   * 解析url参数
   */
  function analysisUrlParam (url) {
    var queryParts = url.slice(url.indexOf("?") + 1).split('&');
    var params = queryParts.length > 0 ? {} : null;
    queryParts.map(function (item) {
      var a = item.split('=')
      params[a[0]] = a[1]
    })
    return params
  }
module.exports = {
  formatTime,
  formatDay,
  rulePhone,
  rulePassword,
  throttle,
  setStorageChat,
  commentTimeHandle,
  analysisUrlParam
}
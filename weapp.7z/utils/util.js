/**
 * 年月日时分秒
 * @param {*} date 
 * @returns 
 */
const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`
}
/**
 * 年月
 * @param {*} n 
 * @returns 
 */
const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}
const formatDay = (time, format) => {
  const date = new Date(time)
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  if (format) {
    return `${year}-${month < 10 ? '0' + month : month}-${day < 10 ? '0' + day : day}`
  } else {
    return `${year}年 ${month}月 ${day}日`
  }
}
/**
 * 校验手机号码
 * @param {*} data 
 * @returns 
 */
const rulePhone = (data) => {
  if (!data) return false
  let reg = /^[1]\d{10}$/
  return reg.test(data)
}
/**
 * 校验密码
 * 含有字母数字组成 大于6位小于 15位
 * @param {*} password 
 */
const rulePassword = (password) => {
  if (!password) return false
  let reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,15}$/
  return reg.test(password)
}
/**
 * 校验验证码
 * @param {} code 
 */
const ruleCode = (code) => {

}

module.exports = {
  formatTime,
  formatDay,
  rulePhone,
  rulePassword
}

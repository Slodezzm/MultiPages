// pages/set_meal/set_meal.js
const app = getApp();
var WxParse = require('../../utils/wxParse/wxParse');
Page({
  /**
   * 页面的初始数据 
   */
  data: {
    clientHeight: 0,
    navHeight: 0,
    loading: true,
    currentTab: 0,
    isShow: false,
    redeemCode: '',
    isExchange: false,
    //套餐 list
    comboList: [],
    pageSize: 10,
    pageNo: 1,
    // 购买兑换记录
    orderAndExchangeList: [],
    orderAndExchangeHasNextPage: 0,
    bannerList: [],
    statusType: [
      "购买套餐",
      "会员兑换",
      "购买/兑换记录"
    ],
  },
  // 选中 兑换 同意条款
  termsChange(event) {
    this.setData({
      isExchange: event.detail
    })
  },
  termsConfirm() {
    if (this.data.isExchange) {
      wx.showToast({
        title: '兑换成功',
        icon: 'none',
      })
    } else {
      wx.showToast({
        title: '请先勾选条款！',
        icon: 'none',
      })
    }

  },
  // 切换标签栏
  tabChange(event) {
    event.detail.index === 1 && this.getOrderAndExchangeList({
      pageSize: this.data.pageSize,
      pageNo: this.data.pageNo
    })
    event.detail.index === 0 && this.getComboList({
      pageSize: this.data.pageSize,
      pageNo: this.data.pageNo
    })
  },
  // 购买成功 确定
  gotoMine() {
    this.setData({
      isShow: false
    })
    // wx.switchTab({
    //   url: '/pages/mine/mine'
    // })
  },
  // 判断是否有 openid 购买下单 
  purchase(event) {
    wx.showLoading({
      title: '支付中...',
    })
    let self = this
    let {
      id
    } = event.currentTarget.dataset
    if (app.globalData.openid) {
      self.order(app.globalData.openid, id)
    } else {
      wx.login({
        success(res) {
          app.globalData.agriknow.getOpenId({
              code: res.code
            }, false)
            .then(res => {
              app.globalData.openid = res.data
              self.order(res.data, id)
            })

        }
      })
    }
  },
  order(opneid, id) {
    let self = this
    app.globalData.agriknow.userProgramPurchase({
        programId: id
      }, false)
      .then(resCode => {
        if (resCode.code === 'success') {
          app.playMoney(opneid, resCode.data.orderInfo.orderNo)
            .then(res => {
              wx.hideLoading()
              if (res.code === 'success') {
                let {
                  nonceStr,
                  prepayId,
                  sign,
                  signType,
                  timestamp
                } = res.data
                wx.requestPayment({
                  timeStamp: timestamp,
                  nonceStr: nonceStr,
                  package: `prepay_id=${prepayId}`,
                  signType: signType,
                  paySign: sign,
                  success(res) {
                    wx.hideLoading()
                    self.setData({
                      isShow: true
                    })
                  },
                  fail(err) {
                    wx.hideLoading()
                    wx.showToast({
                      title: '支付失败',
                      icon:"none"
                    })
                  }
                })
              }
            })
        }
      })
  },
  // getCombo 获取套餐
  getCombo(data, loading = false) {
    loading && this.setData({
      loading: true
    })
    return new Promise((resolve, reject) => {
      app.globalData.agriknow.getProgramList(data, loading)
        .then(res => {
          loading && this.setData({
            loading: false
          })
          resolve(res)
        })
        .catch(err => {
          loading && this.setData({
            loading: false
          })
          reject(err)
        })
    })
  },
  getComboList(data, loading = false) {
    this.getCombo(data, loading)
      .then(res => {
        let that = this
        if (data.pageNo === 1) {
          this.setData({
            comboList: res.data.programList,
            hasNextPage: res.data.hasNextPage,
          })
        } else {
          let newList = JSON.parse(JSON.stringify(this.data.comboList))
          this.setData({
            comboList: [...newList, ...res.data.programList],
            hasNextPage: res.data.hasNextPage
          })
        }
        // 把 html 转为wxml
        let _data = res.data.programList
        let _len = _data.length
        for (let i = 0; i < _len; i++) {
          WxParse.wxParse('content' + i, 'html', _data[i].programInfo.content, that);
          if (i === _len - 1) {
            WxParse.wxParseTemArray("askItemsArr", 'content', _data.length, that)
          }
        }
      })
  },
  // 获取购买兑换记录
  getOrderAndExchangeList(data, loading = false) {
    loading && this.setData({
      loading: true
    })
    app.globalData.agriknow.getOrderAndExchangeList(data, loading)
      .then(res => {
        loading && this.setData({
          loading: false
        })
        if (res.code === 'success') {
          this.setData({
            orderAndExchangeList: res.data.programList,
            orderAndExchangeHasNextPage: res.data.hasNextPage
          })
        } else {
          wx.showToast({
            title: '请求出错了！',
            icon: 'none'
          })
        }
      })
  },
  // 获取banner 
  getBannerList() {
    return new Promise((resolve, reject) => {
      app.globalData.agriknow.getBannerList({
          bannerUseType: 5,
          clientType: 2
        })
        .then(res => {
          resolve(res)
        })
        .catch(err => {
          reject(err)
        })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      clientHeight: app.globalData.Wechat.clientHeight - app.globalData.Wechat.navHeight,
      navHeight: app.globalData.Wechat.navHeight
    })
    if (options.tab) {
      this.setData({
        currentTab: parseInt(options.tab)
      })
    }
    Promise.all([this.getCombo({
      pageSize: this.data.pageSize,
      pageNo: this.data.pageNo
    }, true), this.getBannerList()]).then(res => {
      // 套餐 接口
      if (res[0].code === 'success' || res[1].code === 'success') {
        let that = this
        this.setData({
          comboList: res[0].data.programList,
          hasNextPage: res[0].data.hasNextPage,
          bannerList: res[1].data
        })
        // 把 html 转为wxml
        let _data = res[0].data.programList
        let _len = _data.length
        for (let i = 0; i < _len; i++) {
          WxParse.wxParse('content' + i, 'html', _data[i].programInfo.content, that);
          if (i === _len - 1) {
            WxParse.wxParseTemArray("askItemsArr", 'content', _data.length, that)
          }
        }
      } else {
        wx.showToast({
          title: '请求出错了！',
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.hasNextPage) {
      this.getComboList({
        pageSize: this.data.pageSize,
        pageNo: ++this.data.pageNo
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},

  // // 滚动切换标签样式
  // switchTab: function (e) {
  //   this.setData({
  //     currentTab: e.detail.current
  //   });
  //   if (this.data.currentTab >= 3) {
  //     this.setData({
  //       scrollLeft: (this.data.currentTab - 2) * this.properties.item_width
  //     })
  //   } else {
  //     this.setData({
  //       scrollLeft: 0
  //     })
  //   }
  // },
  // // 点击标题切换当前页时改变样式
  // swichNav: function (e) {
  //   var cur = e.target.dataset.current;
  //   if (this.data.currentTaB == cur) {
  //     return false;
  //   } else {
  //     this.setData({
  //       currentTab: cur
  //     })
  //   }
  // },
})
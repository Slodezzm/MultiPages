// pages/recruitment/recruitment.js
const app = getApp();
import { formatDay } from '../../utils/util.js'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    navHeight: 0,
    steps: [
      { desc: '选择宝宝' },
      { desc: '招聘需求' },
      { desc: '确认发布' },
      { desc: '发布成功' },
    ],
    selectbady: [],
    badyList: [],
    setpsActive: 1,
    provinceList: [],
    cityList: [],
    areaList: [],
    streetList: [],
    province: {},
    city: {},
    area: {},
    street: {},
    adderssText: '请选择地址',
    nannyAdress: [
      {
        title: '到府',
        subhead: '到家长家',
        id: 1,
      },
      {
        title: '在家',
        subhead: '在保姆家',
        id: 2,
      }
    ],
    serviceMode: null,
    serveType: [
      {
        title: '短期',
        subhead: '临时，几个礼拜',
        id: 1,
        isActivity: false
      },
      {
        title: '长期',
        subhead: '一年以上',
        id: 2,
        isActivity: false
      }
    ],
    serviceCycleType: null,
    addrerssId: [],
    recruitDataList: [
      {
        title: '服务地点',
        value: '北京市朝阳区',
        id: 234
      },
      {
        title: '服务类型',
        value: '短期',
        id: 2343
      },
      {
        title: '开始日期',
        value: '2021/03/01',
        id: 2344
      },
      {
        title: '结束日期',
        value: '2021/03/01',
        id: 23432
      }, {
        title: '备注',
        value: '可以面谈',
        id: 23466
      },
      {
        title: '服务地点',
        value: '北京市朝阳区',
        id: 234656
      }
    ],
    workTimeList: [
      {
        title: '不限',
        value: 0
      },
      {
        title: '1年以上',
        value: 1
      },
      {
        title: '5年以上',
        value: 5
      },
      {
        title: '10年以上',
        value: 10
      }
    ],
    workTime: '',
    profession: [],
    resultList: [
      {
        title: '符合筛选条件结果',
        value: '7',
        id: 3433
      },
      {
        title: '服务区域',
        value: '北京市朝阳区',
        id: 34333
      },
    ],
    programList: [
      {
        time: 1,
        content: {
          title: '单次救急方案',
          contentList: ['含5则定制化信息', '490']
        },
        price: 123,
        id: 24
      },
      {
        time: 1,
        content: {
          title: '单次救急方案',
          contentList: ['含5则定制化信息', '490']
        },
        price: 123,
        id: 24234
      }
    ],
    adderssActive: 0,
    isAdderss: false,
    // 时间选择
    startTime: '请选择开始日期',
    endTime: '请选择结束日期',
    startDate: '',
    endDate: '',
    isStartTime: false,
    isEndTime: false,
    jobDesc: '', // 描述
    currentDate: new Date().getTime(),
    minDate: new Date().getTime(),
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      if (type === 'day') {
        return `${value}日`;
      }
      return value;
    },
    resultNum: 0,
    timeList: [] // 托育时间段 
  },
  // 选择开始时间
  startConfirm(event) {
    this.setData({
      startTime: formatDay(event.detail),
      startDate: formatDay(event.detail, true)
    })
    this.startClose()
  },
  updataStartTime() {
    this.setData({
      isStartTime: true
    })
  },
  startClose() {
    this.setData({
      isStartTime: false
    })
  },
  // 选择结束时间
  endConfirm(event) {
    console.log(event, '结束时间')
    console.log(formatDay(event.detail))
    this.setData({
      endTime: formatDay(event.detail),
      endDate: formatDay(event.detail, true)
    })
    this.endClose()
  },
  updataEndTime() {
    this.setData({
      isEndTime: true
    })
  },
  endClose() {
    this.setData({
      isEndTime: false
    })
  },
  // 选择 地址
  adderssSelect() {
    this.getAreaList({ type: 1 })
    this.setData({
      isAdderss: true
    })
  },
  closeAdderssSelect() {
    this.setData({
      isAdderss: false
    })
  },
  confirmAdderssSelect() {
    if (Object.keys(this.data.province).length <= 0 || Object.keys(this.data.city).length <= 0 || Object.keys(this.data.area).length <= 0 || Object.keys(this.data.street).length <= 0) {
      wx.showToast({
        title: '请先选择完省市区省份！',
        icon: 'none'
      })
      return
    }
    this.setData({
      adderssText: this.data.province.name + ' ' + this.data.city.name + ' ' + this.data.area.name + ' ' + this.data.street.name
    })
    this.closeAdderssSelect()
  },
  selectProvince(event) {
    console.log()
    let { type } = event.currentTarget.dataset
    let data = {}
    if (type === 1) {
      data = {
        province: event.detail.value,
        city: {},
        area: {},
        street: {},
      }
    } else if (type === 2) {
      data = {
        city: event.detail.value,
        area: {},
        street: {},
      }
    } else if (type === 3) {
      data = {
        area: event.detail.value,
        street: {},
      }
    } else if (type === 4) {
      data = {
        street: event.detail.value
      }
    }
    this.setData(data)
  },
  tabChange(event) {
    event.detail.index === 1 &&
      this.getAreaList({ code: this.data.province.code, type: event.detail.index + 1 })
    event.detail.index === 2 &&
      this.getAreaList({ code: this.data.city.code, type: event.detail.index + 1 })
    event.detail.index === 3 &&
      this.getAreaList({ code: this.data.area.code, type: event.detail.index + 1 })
  },
  // 托育时间段 所选择的 时间list 
  selectedTimeList(event) {
    this.setData({
      timeList: event.detail
    })
  },
  // 托育 地点 选中的
  selectAdderss(event) {
    this.setData({
      serviceMode: event.detail
    })
  },
  // 服务类型选择
  selectServeType(event) {
    this.setData({
      serviceCycleType: event.detail
    })
  },
  // 选择 从业时间
  selectWorkTime(event) {
    let { value } = event.currentTarget.dataset
    this.setData({
      workTime: value
    })
    this.getFitJobCount()
  },
  // 查询 符合条件的数量
  getFitJobCount() {
    let ids = []
    this.data.profession.forEach(item => {
      item.isActivity && ids.push(item.id)
    })
    app.globalData.agriknow.getFitJobCount({
      certificateIds: ids,
      workYearsAbove: this.data.workTime
    })
      .then(res => {
        this.setData({
          resultNum: res.data
        })
      })
  },
  // 获取保姆专业证书
  getNannyCertificate() {
    app.globalData.agriknow.getNannyCertificate()
      .then(res => {
        let list = res.data.certificateList.map(item => {
          item.isActivity = false
          return item
        })
        this.setData({
          profession: list,
          setpsActive: this.data.setpsActive + 1
        })
      })
  },
  // 专业资格 多选
  selectProfession(event) {
    let newProfession = this.data.profession.map((item, index) => {
      if (index === event.currentTarget.dataset.index) {
        item.isActivity = !item.isActivity
      }
      return item
    })
    this.setData({
      profession: newProfession
    })
    this.getFitJobCount()
  },
  nextBtn(event) {
    if (!this.data.selectbady.length) {
      wx.showToast({
        title: '请选择宝宝!',
        icon: 'none'
      })
      return
    }
    this.setData({
      setpsActive: this.data.setpsActive + 1
    })
  },
  back() {
    this.setData({
      setpsActive: this.data.setpsActive - 1
    })
  },
  // 确认内容
  confirmContent() {
    let { province, city, area, street, serviceMode, serviceCycleType, startDate, endDate, timeList } = this.data
    // 地址
    if (!Object.keys(province).length || !Object.keys(city).length || !Object.keys(area).length || !Object.keys(street).length) {
      wx.showToast({
        title: '请选择地址！',
        icon: 'none'
      })
      return
    }
    // 托育地点
    if (!serviceMode) {
      wx.showToast({
        title: '请选择托育地点!',
        icon: 'none'
      })
      return
    }
    // 服务类型
    if (!serviceCycleType) {
      wx.showToast({
        title: '请选择服务类型!',
        icon: 'none'
      })
      return
    }
    // 开始时间   结束时间
    if (!startDate || !endDate) {
      wx.showToast({
        title: '请选择开始日期和结束日期',
        icon: 'none'
      })
      return
    }
    // 托育时间段
    if (timeList.length <= 0) {
      wx.showToast({
        title: '请选择托育时间段！',
        icon: 'none'
      })
      return
    }
    this.getNannyCertificate()
  },
  // 获取孩子list 
  // 获取bady list数据 
  getChildList() {
    app.globalData.agriknow.getParentChildList()
      .then((res) => {
        let badyList = res.data.childList.map(item => {
          item.isSelect = false
          return item
        })
        this.setData({
          badyList: badyList
        })
      })
  },
  // 选择孩子
  selectBadyChange(event) {
    this.setData({
      selectbady: event.detail,
    });
  },
  // 编辑孩子信息
  editChildInfo(event) {
    let { id } = event.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/addBady/addBady?id=${id}`,
    })
  },
  // 删除孩子信息
  deleteChildInfo(event) {
    let { birthdate,
      birthflag,
      gender,
      id } = event.currentTarget.dataset
    app.globalData.agriknow.deleteChildInfo({
      birthDate: birthdate,
      birthFlag: birthflag,
      gender,
      id
    })
      .then((res) => {
        wx.showToast({
          title: res.msg,
          icon: 'none',
        })
        this.getChildList()
      })
  },
  // 新增宝宝资料
  addBadyData() {
    wx.navigateTo({
      url: '/pages/addBady/addBady'
    })
  },
  // 获取地区 list 
  getAreaList(data) {
    app.globalData.agriknow.getAreaList(data)
      .then(res => {
        let areaList = res.data.areaList.map(item => {
          item.text = item.name
          return item
        })
        data.type === 1 && this.setData({
          provinceList: areaList,
          province: areaList[0]
        })
        console
        data.type === 2 && this.setData({
          cityList: areaList,
          city: areaList[0]
        })
        data.type === 3 && this.setData({
          areaList: areaList,
          area: areaList[0]
        })
        data.type === 4 && this.setData({
          streetList: areaList,
          street: areaList[0]
          // street: areaList.length === 1 ? areaList[0] : {},
        })

      })
  },
  // 发送通知 
  sendNotice() {
    let params = {
      certificateIds: this.data.profession.map(item => { return item.id }),
      childList: this.data.selectbady.map(item => { return parseInt(item) }),
      startDate: this.data.startDate,
      endDate: this.data.endDate,
      jobDesc: this.data.jobDesc,
      result: this.data.resultNum,
      serviceArea: {
        provinceCode: this.data.province.code,
        cityCode: this.data.city.code,
        areaCode: this.data.area.code,
        streetCode: this.data.street.code
      },
      serviceCycleType: this.data.serviceCycleType,
      serviceMode: this.data.serviceMode,
      serviceTimes: this.data.timeList,
      workYearsAbove: this.data.workTime
    }
    app.globalData.agriknow.publishParentsJob(params)
      .then(res => {
        let _this = this
        if (res.code === 'success') {
          wx.showToast({
            title: '发送成功!',
            success: function () {
              setTimeout(() => {
                _this.setData({
                  setpsActive: _this.data.setpsActive + 1
                })
              }, 1000)
            }
          })
        }
      })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options, '招聘页面接收到的参数')

    this.setData({
      navHeight: app.globalData.Wechat.navHeight
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getChildList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
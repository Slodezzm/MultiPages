// pages/recruitment/recruitment.js
const app = getApp();
import {
  formatDay,
  throttle
} from '../../utils/util.js'
var WxParse = require('../../utils/wxParse/wxParse');
Page({
  /**
   * 页面的初始数据
   */
  data: {

    steps: [{
        desc: '选择宝宝'
      },
      {
        desc: '招聘需求'
      },
      {
        desc: '确认发布'
      },
      {
        desc: '发布成功'
      },
    ],
    selectbady: [],
    badyList: [],
    setpsActive: 1,
    addressList: [0, 0, 0, 0],
    adderssText: '请选择地址',
    nannyAdress: [{
        title: '到府',
        subhead: '到家长家',
        id: 1,
      },
      {
        title: '在家',
        subhead: '在保姆家',
        id: 2,
      }
    ],
    serviceMode: null,
    serveType: [{
        title: '短期',
        subhead: '临时，几个礼拜',
        id: 1,
        isActivity: false
      },
      {
        title: '长期',
        subhead: '一年以上',
        id: 2,
        isActivity: false
      }
    ],
    serviceCycleType: null,
    addrerssId: [],
    workTimeList: [{
        title: '不限',
        value: 0
      },
      {
        title: '1年以上',
        value: 1
      },
      {
        title: '5年以上',
        value: 5
      },
      {
        title: '10年以上',
        value: 10
      }
    ],
    workTime: '',
    profession: [],
    professionIds: [],
    resultList: [{
        title: '符合筛选条件结果',
        value: '7',
        id: 3433
      },
      {
        title: '服务区域',
        value: '北京市朝阳区',
        id: 34333
      },
    ],
    programList: [],
    adderssActive: 0,
    isAdderss: false,
    // 时间选择
    startTime: '请选择开始日期',
    endTime: '请选择结束日期',
    startDate: 0,
    endDate: 0,
    jobDesc: '', // 描述
    currentDate: new Date().getTime(),
    minDate: formatDay(new Date()),
    resultNum: 0,
    timeList: [], // 托育时间段 
    theTimeList: [], // 托育时间的基础数据
  },
  // 选择开始时间
  startConfirm(event) {
    if (this.data.endDate && new Date(event.detail.value).getTime() >= new Date(this.data.endDate).getTime()) {
      wx.showToast({
        title: '开始时间需要小于结束时间',
        icon: 'none'
      })
      return
    }
    this.setData({
      startDate: event.detail.value,
      startTime: event.detail.value,
      minDate: event.detail.value
    })

  },

  // 选择结束时间
  endConfirm(event) {
    if (this.data.startDate && (new Date(this.data.startDate).getTime() >= new Date(event.detail.value).getTime())) {
      wx.showToast({
        title: '结束时间需要大于开始时间',
        icon: 'none'
      })
      return
    }
    this.setData({
      endTime: event.detail.value,
      endDate: event.detail.value
    })
  },
  // 选择 地址
  adderssSelect() {
    this.setData({
      isAdderss: true
    })
  },
  closeAdderssSelect() {
    this.setData({
      isAdderss: false
    })
  },
  confirmAdderssSelect(e) {
    let text = e.detail.map(item => {
      return item.name ? item.name : ''
    })
    this.setData({
      adderssText: text.join(''),
      addressList: e.detail
    })
  },
  cancel(e) {
    this.setData({
      isAdderss: e.detail
    })
  },
  // 托育时间段 所选择的 时间list 
  selectedTimeList(event) {
    this.setData({
      timeList: event.detail
    })
  },
  // 托育 地点 选中的
  selectAdderss(event) {
    this.setData({
      serviceMode: event.detail
    })
  },
  // 服务类型选择
  selectServeType(event) {
    this.setData({
      serviceCycleType: event.detail
    })
  },
  // 选择 从业时间
  selectWorkTime(event) {
    let {
      value
    } = event.currentTarget.dataset
    this.setData({
      workTime: value
    })
    this.getFitJobCount()
  },
  // 查询 符合条件的数量
  getFitJobCount() {
    let ids = []
    this.data.profession.forEach(item => {
      item.isActivity && ids.push(item.id)
    })
    app.globalData.agriknow.getFitJobCount({
        certificateIds: ids,
        workYearsAbove: this.data.workTime
      })
      .then(res => {
        this.setData({
          resultNum: res.data
        })
      })
  },
  // 获取保姆专业证书
  getNannyCertificate() {
    app.globalData.agriknow.getNannyCertificate()
      .then(res => {
        let list = res.data.certificateList.map(item => {
          if (this.data.professionIds.includes(item.id)) {
            item.isActivity = true
          } else {
            item.isActivity = false
          }
          return item
        })
        this.setData({
          profession: list,
          setpsActive: this.data.setpsActive + 1
        })
        wx.pageScrollTo({
          scrollTop: 0
        })
      })
  },
  // 专业资格 多选
  selectProfession(event) {
    let newProfession = this.data.profession.map((item, index) => {
      if (index === event.currentTarget.dataset.index) {
        item.isActivity = !item.isActivity
      }
      return item
    })
    this.setData({
      profession: newProfession
    })
    this.getFitJobCount()
  },
  nextBtn(event) {
    if (!this.data.selectbady.length) {
      wx.showToast({
        title: '请选择宝宝!',
        icon: 'none'
      })
      return
    }
    throttle(() => {
      this.setData({
        setpsActive: this.data.setpsActive + 1
      })
      wx.pageScrollTo({
        scrollTop: 0
      })
    })()
  },
  back() {
    throttle(() => {
      this.setData({
        setpsActive: this.data.setpsActive - 1
      })
    })()
  },
  // 确认内容
  confirmContent() {
    let {
      addressList,
      serviceMode,
      serviceCycleType,
      startDate,
      endDate,
      timeList
    } = this.data
    // 地址
    if (!addressList[0]) {
      wx.showToast({
        title: '请选择地址！',
        icon: 'none'
      })
      return
    }
    // 托育地点
    if (!serviceMode) {
      wx.showToast({
        title: '请选择托育地点!',
        icon: 'none'
      })
      return
    }
    // 服务类型
    if (!serviceCycleType) {
      wx.showToast({
        title: '请选择服务类型!',
        icon: 'none'
      })
      return
    }
    // 开始时间   结束时间
    if (!startDate || !endDate) {
      wx.showToast({
        title: '请选择开始日期和结束日期',
        icon: 'none'
      })
      return
    }
    // 托育时间段
    if (timeList.length <= 0) {
      wx.showToast({
        title: '请选择托育时间段！',
        icon: 'none'
      })
      return
    }
    this.getNannyCertificate()

  },
  // 获取孩子list 
  // 获取bady list数据 
  getChildList() {
    this.setData({
      loading: true
    })
    app.globalData.agriknow.getParentChildList()
      .then((res) => {
        this.setData({
          loading: false
        })
        let badyList = res.data.childList.map(item => {
          item.isSelect = false
          return item
        })
        this.setData({
          badyList: badyList
        })
      })
  },
  // 选择孩子
  selectBadyChange(event) {
    this.setData({
      selectbady: event.detail,
    });
  },
  // 编辑孩子信息
  editChildInfo(event) {
    let {
      id
    } = event.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/addBady/addBady?id=${id}`,
    })
  },
  // 删除孩子信息
  deleteChildInfo(event) {
    let {
      id,
      childprofile
    } = event.currentTarget.dataset
    let _this = this
    wx.showModal({
      content: `确定删除“${childprofile}”宝宝吗？`,
      success(res) {
        if (res.confirm) {
          app.globalData.agriknow.deleteChildInfo(id)
            .then((res) => {
              wx.showToast({
                title: '删除成功',
              })
              _this.getChildList()
            })
        }
      }
    })


  },
  // 新增宝宝资料
  addBadyData() {
    wx.navigateTo({
      url: '/pages/addBady/addBady'
    })
  },
  // 发送通知 
  sendNotice(e) {
    if (!(this.data.workTime || this.data.workTime === 0) || !this.data.profession.length) {
      wx.showToast({
        title: '请选择从业时间和专业资格！',
        icon: 'none'
      })
      return
    }
    let params = {
      certificateIds: this.data.profession.map(item => {
        return item.id
      }),
      childList: this.data.selectbady.map(item => {
        return parseInt(item)
      }),
      startDate: this.data.startDate,
      endDate: this.data.endDate,
      jobDesc: this.data.jobDesc,
      result: this.data.resultNum,
      serviceArea: {
        provinceCode: this.data.addressList[0].code,
        cityCode: this.data.addressList[1].code,
        areaCode: this.data.addressList[2].code,
        streetCode: this.data.addressList[3] ? this.data.addressList[3].code : ''
      },
      serviceCycleType: this.data.serviceCycleType,
      serviceMode: this.data.serviceMode,
      serviceTimes: this.data.timeList,
      workYearsAbove: this.data.workTime
    }
    app.globalData.agriknow.publishParentsJob(params, true)
      .then(res => {
        let _this = this
        if (res.code === 'success') {
          wx.showToast({
            title: '发布成功!',
            success: function () {
              setTimeout(() => {
                _this.setData({
                  setpsActive: _this.data.setpsActive + 1
                })
                _this.getCombo()
              }, 1000)
            }
          })
        }
        wx.pageScrollTo({
          scrollTop: 0
        })
      })
  },
  downloadQRcode() {
    wx.showLoading()
    wx.downloadFile({
      url: 'https://dss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1986451467,394304688&fm=26&gp=0.jpg',
      success(res) {
        if (res.statusCode === 200) {
          wx.hideLoading()
          wx.showToast({
            title: '保存成功',
            icon: 'none'
          })
        }
      }
    })
  },
  // 获取时间段的基础数据
  getPointTimeList() {
    app.globalData.agriknow.getTimePointList()
      .then(res => {
        let theTimeList = res.data.serviceTime
        this.setData({
          theTimeList: theTimeList
        })
      })
  },
  // 编辑 拉数据
  editRecruitment(id) {
    app.globalData.agriknow.getJobInfo({
        id
      })
      .then(res => {
        if (res.code === 'success') {
          let data = res.data.jobInfo
          let list = [{
              name: data.serviceArea.provinceName,
              code: data.serviceArea.provinceCode
            },
            {
              name: data.serviceArea.cityName,
              code: data.serviceArea.cityCode
            },
            {
              name: data.serviceArea.areaName,
              code: data.serviceArea.areaCode
            }
          ]
          if ((data.serviceArea.streetName && data.serviceArea.streetCode)) {
            list.push({
              name: data.serviceArea.streetName,
              code: data.serviceArea.streetCode
            })
          }

          this.setData({
            selectbady: res.data.childInfoList.map(item => {
              return (item.childId).toString()
            }),
            addressList: list,
            adderssText: data.locationDesc,
            serviceMode: data.serviceMode,
            serviceCycleType: data.serviceCycleType,
            startTime: data.startDate,
            endTime: data.endDate,
            startDate: data.startDate,
            endDate: data.endDate,
            jobDesc: data.jobDesc,
            timeList: data.serviceTimes,
            workTime: data.workYear,
            professionIds: data.certificateIds
          })

        }
      })
  },
  // getCombo 获取套餐
  getCombo() {
    let that = this
    app.globalData.agriknow.getProgramList({
        pageSize: 2,
        pageNo: 1
      })
      .then(res => {
        if (res.code === 'success') {
          this.setData({
            programList: res.data.programList
          })
          // 把 html 转为wxml
          let _data = that.data.programList
          let _len = _data.length
          for (let i = 0; i < _len; i++) {
            WxParse.wxParse('content' + i, 'html', _data[i].programInfo.content, that);
            if (i === _len - 1) {
              WxParse.wxParseTemArray("askItemsArr", 'content', _data.length, that)
            }
          }
        }

      })
  },
  viewRecruit() {
    wx.navigateTo({
      url: '/pages/myRecruit/myRecruit',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getPointTimeList()
    if (options.recruitId) {
      this.editRecruitment(options.recruitId)
    }
    this.getCombo()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getChildList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
const app = getApp()
console.log(app.globalData.agriknow)

let timeTable = [], week = ["一","二","三","四","五","六","日"], times = ["6AM","9AM","12AM","3PM","6PM","9PM","12PM"]
const itemList = ["province","city","area","street"]
// pages/amah/amah.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loading: false,
    offsetTop: 0,// 顶部吸附距离
    navHeight: 0,// nav高度
    banner: [// 轮播图
      {image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F01cbe958c128eba801219c7730c022.jpg&refer=http%3A%2F%2Fimg.zcool.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620371288&t=49e6b80cf8349af6719e3514915911d4', url: '/page/index/index'},
      {image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg011.hc360.cn%2Fk3%2FM0E%2FD1%2F27%2FwKhQx1kNh1qEblJuAAAAALuo5oA225.jpg&refer=http%3A%2F%2Fimg011.hc360.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620373134&t=6c817f8cec38c245159da36b12325fb3', url: '/page/index/index'},
      {image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F01196a58affd53a801219c775892b5.jpg%401280w_1l_2o_100sh.jpg&refer=http%3A%2F%2Fimg.zcool.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620371288&t=7da7a5f459b11f7081af3d8d8f009684', url: '/page/index/index'},
      {image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F013a4f58c128e7a801219c77271242.jpg&refer=http%3A%2F%2Fimg.zcool.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620371288&t=6fe2874185b7d3c8dc04d3f9b5382cce', url: '/page/index/index'},
    ],
    currentNav: 0,// 当前导航栏
    checkNav: [// 导航栏
      {navText: "专业保姆", navIcon: '/image/checknav10.png', navIconAct: '/image/checknav11.png' },
      {navText: "家长求助", navIcon: '/image/checknav20.png', navIconAct: '/image/checknav21.png' }
    ],
    scrollTop: 0,
    shifIndex: 0,
    shifList: [// 筛选条件列表
      {shifText: '服务区域', shifShow: false},
      {shifText: '托育地点', shifShow: false},
      {shifText: '服务时段', shifShow: false},
      {shifText: '从业时间', shifShow: false}
    ],
    selectAreaList: ['不限', '到家长家', '在保姆家'], // 托育地点
    selectExpList: ['不限','1年以上','2年以上','3年以上','5年以上','10年以上'], // 从业时间
    siftListShow: false, // 筛选弹框展示与否
    siftList: [ // 筛选条件
      {
        title: "在线状态",
        label: "lineStatus",
        choices: [
          {text: "不限", choice: true},
          {text: "在线", choice: false},
          {text: "离线", choice: false}
        ]
      },
      {
        title: "服务类型",
        label: "serveType",
        choices: [
          {text: "不限", choice: true},
          {text: "长期", choice: false},
          {text: "短期", choice: false}
        ]
      },
      {
        title: "参考收费",
        label: "charge",
        choices: [
          {text: "不限", choice: true},
          {text: "从高到低", choice: false},
          {text: "从低到高", choice: false}
        ]
      },
      {
        title: "服务评价",
        label: "graded",
        choices: [
          {text: "不限", choice: true},
          {text: "4.4分以上", choice: false},
          {text: "4.5分以上", choice: false},
          {text: "4.6分以上", choice: false},
          {text: "4.7分以上", choice: false},
          {text: "4.8分以上", choice: false},
          {text: "4.9分以上", choice: false},
          {text: "5分", choice: false}
        ]
      },
    ],
    times: [],
    timeTable: [],
    parentList:[{current:0,children:[1,2,3]},{current:0,children:[1,2]},{current:0,children:[1]},{current:0,children:[1]}],
    // 省市区街道数据
    province: ["北京市","天津市","河北省","山西省","内蒙古自治区","辽宁省"],
    city: ["沈阳市","大连市","鞍山市","抚顺市","本溪市","丹东市","锦州市","营口市","阜新市","辽阳市","盘锦市","铁岭市","朝阳市","葫芦岛市"],
    area: ["连山区","龙港区","南票区","绥中县","建昌县","兴城市"],
    street: ["古城街道","宁远街道","温泉街道","四家屯街道","菊花街道","曹庄镇","沙后所满族镇","东辛庄满族镇","郭家满族镇","红崖子镇","徐大堡镇","高家岭满族镇","羊安满族乡","元台子满族乡","白塔满族乡","望海满族乡","刘台子满族乡","大寨满族乡","南大满族乡","围屏满族乡","碱厂满族乡","三道沟满族乡","旧门满族乡","药王满族乡","兴城飞地经济区"],
    pcasLoading: true,
    pcas: [],
    pcasIndex: 0,
    pcdsItem: ["选择省","选择市","选择区","选择街道"]
  },
  onLoad: function (options) {//生命周期函数--监听页面加载
    let theTime = []
    times.forEach(a => {
      theTime.push({
        text: a,
        flag: false
      })
    })
    week.forEach(a => {
      timeTable.push({
        text: a,
        choice: 0,
        times: [...theTime]
      })
    })
    this.setData({
      timeTable: JSON.parse(JSON.stringify(timeTable)),
      times: times,
      navHeight: app.globalData.Wechat.navHeight
    })
  },
  onReady: function () {//生命周期函数--监听页面初次渲染完成

  },
  onShow: function () {//生命周期函数--监听页面显示
    this.setData({
      offsetTop: app.globalData.Wechat.navHeight
    })
    this.getTabBar().setData({// 显示/隐藏底部Tab
      selected: 2
    })
  },
  onHide: function () {//生命周期函数--监听页面隐藏

  },
  onUnload: function () {//生命周期函数--监听页面卸载

  },
  onPullDownRefresh: function () {//页面相关事件处理函数--监听用户下拉动作

  },
  onReachBottom: function () {//页面上拉触底事件的处理函数

  },
  onShareAppMessage: function () {//用户点击右上角分享

  },
  onPageScroll(e) {// 页面滚动
    this.setData({
      scrollTop: e.scrollTop
    })
  },
  checkNavItem(e) {//切换保姆和家长
    this.setData({
      currentNav: e.currentTarget.dataset.index
    })
  },
  openSift() {// 点击筛选按钮
    this.setData({
      siftListShow: true
    })
    this.tabBarToggle(false)
  },
  closeSift() {// 关闭筛选面板
    this.setData({
      siftListShow: false
    })
    this.tabBarToggle(true)
  },
  onEmptySelect() { // 清空筛选
    let siftList = [...this.data.siftList]
    siftList.forEach(a => {
      a.choices.forEach((b, i) => {
        if (i === 0) {
          b.choice = true
        } else {
          b.choice = false
        }
      })
    })
    this.setData({
      siftList: siftList
    })
  },
  choiceSift(e) {// 筛选面板内选择
    let index = e.currentTarget.dataset.index, cIndex = e.currentTarget.dataset.cindex
    let siftList = [...this.data.siftList]
    let item = {...siftList[index]}
    item.choices.forEach(a => {
      a.choice = false
    })
    item.choices[cIndex].choice = true
    siftList[index] = {...item}
    this.setData({
      siftList: siftList
    })
  },
  selectSift(e) { // 点击筛选左侧按钮
    let shifList = this.data.shifList
    shifList[e.currentTarget.dataset.index].shifShow = true
    this.setData({
      shifList: shifList,
      shifIndex: e.currentTarget.dataset.index
    })
    if (e.currentTarget.dataset.index === 0) {
      setTimeout(() => {
        this.setData({
          pcas: [...this.data.province],
          pcasLoading: false
        })
        console.log(this.data.pcas)
      }, 1000)
    }
    this.tabBarToggle(false)
  },
  onChange(event) {
    const { picker, value, index } = event.detail
    console.log(`当前值：${picker}, ${value}, 当前索引：${index}`)
  },
  onCancelSelect() {// 关闭选择弹框
    let shifList = this.data.shifList
    shifList[this.data.shifIndex].shifShow = false
    this.setData({
      shifList: shifList
    })
    this.tabBarToggle(true)
  },
  choicePcas(e) {// 选择服务区域
    this.setData({
      pcasIndex: e.currentTarget.dataset.index
    })
  },
  cancelPcas(event) {// 取消选择服务区域
    this.setData({
      pcasIndex: (this.data.pcasIndex - 1) < 0 ? 0 : this.data.pcasIndex - 1
    })
  },
  confirmPcas(event) {// 确定选择服务区域
    console.log(event)
    let pcdsItem = this.data.pcdsItem
    pcdsItem[this.data.pcasIndex] = event.detail.value
    this.setData({
      pcasIndex: (this.data.pcasIndex + 1) > 3 ? 0 : this.data.pcasIndex + 1,
      pcdsItem: pcdsItem,
      pcasLoading: true
    })
    setTimeout(() => {
      this.setData({
        pcas: this.data[itemList[this.data.pcasIndex]],
        pcasLoading: false
      })
    }, 1500)
  },
  onConfirmExpList(event) { // 选择从业时间
    const { picker, value, index } = event.detail
    console.log(`当前值：${picker}, ${value}, 当前索引：${index}`)
  },
  onReachBottom(){// 触底加载
    console.log(app)
  },
  tabBarToggle(flag) {
    this.getTabBar().setData({// 显示/隐藏底部Tab
      show: flag
    })
  },
  choiceWeek(e) {// 服务时段单天选择
    let theTimeTable = [...this.data.timeTable], theTimes = [...this.data.timeTable[e.currentTarget.dataset.index].times]
    for (let i = 0; i < theTimes.length; i++ ) {
      theTimes[i].flag = theTimeTable[e.currentTarget.dataset.index].choice < 7
    }
    theTimeTable[e.currentTarget.dataset.index].times = [...theTimes]
    theTimeTable[e.currentTarget.dataset.index].choice = theTimeTable[e.currentTarget.dataset.index].choice < 7 ? 7 : 0    
    this.setData({
      timeTable: theTimeTable
    })
  },
  choiceTime(e) {// 服务某时段选择
    let theTimeTable = this.data.timeTable, flag = 0
    theTimeTable.forEach((a, i) => {
      if (theTimeTable[i].times[e.currentTarget.dataset.index].flag) flag++
    })
    flag = flag < 7
    theTimeTable.forEach((a, i) => {
      if (theTimeTable[i].times[e.currentTarget.dataset.index].flag != flag) {
        theTimeTable[i].times[e.currentTarget.dataset.index].flag = flag
        theTimeTable[i].choice += flag ? 1 : -1
      }
    })
    this.setData({
      timeTable: theTimeTable
    })
  },
  choiceFrame(e){// 服务时段单个选择
    let theTimeTable = this.data.timeTable
    theTimeTable[e.currentTarget.dataset.windex].times[e.currentTarget.dataset.tindex].flag = !theTimeTable[e.currentTarget.dataset.windex].times[e.currentTarget.dataset.tindex].flag
    theTimeTable[e.currentTarget.dataset.windex].choice += theTimeTable[e.currentTarget.dataset.windex].times[e.currentTarget.dataset.tindex].flag ? 1 : -1
    this.setData({
      timeTable: theTimeTable
    })
  },
  clearFrame() {// 清空服务时段选择
    this.setData({
      timeTable: JSON.parse(JSON.stringify(timeTable))
    })
  },
  quickChoiceFrame() {// 快速选择服务时段
    let theTimeTable = this.data.timeTable
    theTimeTable.forEach((a, i) => {
      theTimeTable[i].choice = 0
      a.times.forEach((b, ii) => {
        if (i < 5 && ii > 0 && ii < 4) {
          theTimeTable[i].choice++
          theTimeTable[i].times[ii].flag = true
        } else {
          theTimeTable[i].times[ii].flag = false
        }
      })
    })
    this.setData({
      timeTable: theTimeTable
    })
  }
})
const app = getApp()

let serviceTimeResps = []
for (let i = 0; i < 24; i++) {
  serviceTimeResps.push(i)
}

Page({
  data: {
    topHeight: 330,
    scrollTop: 0,
    offsetTop: false,
    needScan: true,
    banner: [], // 轮播图
    currentNav: 0, // 当前导航栏
    checkNav: [ // 导航栏
      {
        navText: "专业保姆",
        navIcon: '/image/checknav10.png',
        navIconAct: '/image/checknav11.png'
      },
      {
        navText: "家长求助",
        navIcon: '/image/checknav20.png',
        navIconAct: '/image/checknav21.png'
      }
    ],
    siftIndex: -1,
    siftTerms: [ // 筛选条件列表
      {
        text: '服务区域',
        label: "serviceArea"
      },
      {
        text: '托育地点',
        list: ['不限', '到家长家', '在保姆家'],
        label: "serviceMode"
      },
      {
        text: '服务时段',
        label: "serviceTimes"
      },
      {
        text: '从业时间',
        label: "workYearsAbove",
        list: [{
          name: '不限',
          value: 0
        }, {
          name: '1年以上',
          value: 1
        }, {
          name: '2年以上',
          value: 2
        }, {
          name: '3年以上',
          value: 3
        }, {
          name: '5年以上',
          value: 5
        }, {
          name: '10年以上',
          value: 10
        }] // 从业时间
      }
    ],
    areaItem: ["选择省", "选择市", "选择区", "选择街道"],
    areaLists: [], // 区域选择列表
    areaIndex: 0, // 当前所在地域N级
    areaCodes: [], // 已选择的地区code码
    areaLoading: false, // 拉取地区列表加载
    theTimeList: [], // 托育时间的基础数据
    timeList: [], // 托育时间段 
    serviceTimeResps: serviceTimeResps,
    siftList: [ // 筛选条件
      {
        title: "在线状态",
        label: "onlineStatus",
        choices: [{
            text: "不限",
            choice: true,
            value: 0
          },
          {
            text: "在线",
            choice: false,
            value: 1
          },
          {
            text: "离线",
            choice: false,
            value: 2
          }
        ]
      },
      {
        title: "服务类型",
        label: "serviceCycleType",
        choices: [{
            text: "不限",
            choice: true,
            value: 0
          },
          {
            text: "长期",
            choice: false,
            value: 1
          },
          {
            text: "短期",
            choice: false,
            value: 2
          }
        ]
      },
      {
        title: "参考收费",
        label: "serviceWageOrder",
        choices: [{
            text: "不限",
            choice: true,
            value: ''
          },
          {
            text: "从高到低",
            choice: false,
            value: 'desc'
          },
          {
            text: "从低到高",
            choice: false,
            value: 'asc'
          }
        ]
      },
      {
        title: "服务评价",
        label: "nurseScoreAbove",
        choices: [{
            text: "不限",
            choice: true,
            value: 0
          },
          {
            text: "4.4分以上",
            choice: false,
            value: 4.4
          },
          {
            text: "4.5分以上",
            choice: false,
            value: 4.5
          },
          {
            text: "4.6分以上",
            choice: false,
            value: 4.6
          },
          {
            text: "4.7分以上",
            choice: false,
            value: 4.7
          },
          {
            text: "4.8分以上",
            choice: false,
            value: 4.8
          },
          {
            text: "4.9分以上",
            choice: false,
            value: 4.9
          },
          {
            text: "5分",
            choice: false,
            value: 5
          }
        ]
      },
    ],
    siftShow: false,
    amahList: [], // 保姆列表
    parentsList: [], // 家长求助列表
    querys: [{
        pageNum: 1,
        pageSize: 10,
        finish: false,
        loading: false
      },
      {
        pageNum: 1,
        pageSize: 10,
        finish: false,
        loading: false
      }
    ],
    query: null,
    offsetTopStyle: ''
  },
  onPageScroll(e) { // 页面滚动
    if (e.scrollTop >= this.data.topHeight) {
      if (this.data.offsetTop) return
      this.setData({
        offsetTopStyle: `position: fixed;left: 0;top:${this.data.navHeight}px;z-index: 9999;`,
        offsetTop: true
      })
    } else {
      if (!this.data.offsetTop) return
      this.setData({
        offsetTop: false,
        offsetTopStyle: ``,
      })
    }
  },
  onLoad(options) {
    let needScan = wx.getStorageSync('userInfo') ? JSON.parse(wx.getStorageSync('userInfo')).role : 2
    needScan = needScan === 1
    this.setData({
      needScan: needScan,
      navHeight: app.globalData.Wechat.navHeight
    })
    this.getAmahList()
    this.getBanner()
  },
  onReady() {
    wx.createSelectorQuery().select('#bannerAndS').boundingClientRect((rect) => {
      this.setData({
        topHeight: rect.height
      })
    }).exec()
  },
  onShow() {
    this.setData({})
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 2
      })
    }
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    if (this.data.querys[this.data.currentNav].finish || this.data.querys[this.data.currentNav].loading) return false
    let querys = [...this.data.querys]
    querys[this.data.currentNav].pageNum += 1
    this.setData({
      querys: querys
    })
    if (this.data.currentNav) {
      this.getHelpList()
    } else {
      this.getAmahList()
    }
  },
  tabBarToggle(flag) { // 展示、隐藏底部导航栏
    this.getTabBar().setData({ // 显示/隐藏底部Tab
      show: flag
    })
  },
  selectSift(e) { // 点击筛选左侧按钮
    let index = e.currentTarget.dataset.index
    this.setData({
      siftIndex: index
    })
    switch (index) {
      case 0:
        if (this.data.areaLists.length === (this.data.areaIndex + 1) && this.data.areaLists[this.data.areaIndex].length > 0) {
          break
        } else {
          this.getAreaList()
        }
        break
      case 2:
        if (this.data.theTimeList.length === 0) {
          this.getPointTimeList()
        }
        break
      default:
        break
    }
    this.tabBarToggle(false)
  },
  openSift() { // 右侧筛选
    this.setData({
      siftShow: true
    })
    this.tabBarToggle(false)
  },
  onCancelSelect() { // 取消选择面板
    this.setData({
      siftIndex: -1
    })
    this.tabBarToggle(true)
  },
  confirmSift(event) { // 确认托育地点/从业时间选择面板
    let data = {}
    data[this.data.siftTerms[this.data.siftIndex].label] = event.detail.value.value || event.detail.index
    this.queryData(data)
    this.onCancelSelect()
  },
  confirmSift0(event) { // 服务区域确认选择面板
    let areaCodes = [...this.data.areaCodes],
      areaItem = [...this.data.areaItem]
    areaCodes[this.data.areaIndex] = event.detail.value.code
    areaItem[this.data.areaIndex] = event.detail.value.name
    if (this.data.areaIndex != 3) {
      this.setData({
        areaCodes: areaCodes,
        areaItem: areaItem,
        areaIndex: this.data.areaIndex + 1
      })
      this.getAreaList(event.detail.value.code)
    } else {
      let siftTerms = [...this.data.siftTerms]
      if (event.detail.value.name.length > 4) event.detail.value.name = event.detail.value.name.substr(0, 3) + '…'
      siftTerms[0].text = event.detail.value.name
      this.setData({
        siftTerms: siftTerms,
        areaCodes: areaCodes,
        areaItem: areaItem
      })
      this.queryData()
      this.onCancelSelect()
    }
  },
  confirmSift1() { // 服务时段确认选择面板
    let query = this.data.query || {}
    query.serviceTimes = this.data.theTimeList
    this.setData({
      query: query
    })
    this.queryData()
    this.onCancelSelect()
  },
  choicePcas(e) {
    if (e.currentTarget.dataset.index > this.data.areaIndex && !this.data.areaCodes[this.data.areaIndex]) {
      return false
    } else {
      this.setData({
        areaIndex: e.currentTarget.dataset.index
      })
    }
  },
  clearAreaChoice() {
    let siftTerms = [...this.data.siftTerms]
    siftTerms[0].text = "服务区域"
    this.setData({
      siftTerms: siftTerms,
      areaItem: ["选择省", "选择市", "选择区", "选择街道"],
      areaLists: [],
      areaIndex: 0,
      areaCodes: [],
      areaLoading: false
    })
    this.queryData()
    this.onCancelSelect()
  },
  getAreaList(code) { // 获取区域列表
    let data = {
      type: this.data.areaIndex + 1
    }
    if (code) {
      data.code = code
    } else {
      data.code = this.data.areaCodes[this.data.areaIndex] || 0
    }
    this.setData({
      areaLoading: true
    })
    app.globalData.agriknow.getAreaList(data).then(res => {
      if (res.code === "success") {
        let areaLists = [...this.data.areaLists]
        areaLists[this.data.areaIndex] = [...res.data.areaList]
        this.setData({
          areaLists: [...areaLists],
          areaLoading: false
        })
      } else {
        this.setData({
          areaLoading: false
        })
        wx.showToast({
          title: "获取地址失败，请重新尝试！",
          icon: "error",
          duration: 1000
        })
      }
    })
  },
  getPointTimeList() { // 获取时段列表基础数据
    wx.showLoading()
    app.globalData.agriknow.getTimePointList().then(res => {
      wx.hideLoading()
      let theTimeList = res.data.serviceTime
      this.setData({
        theTimeList: theTimeList
      })
    })
  },
  onEmptySelect() { // 清空筛选
    let siftList = [...this.data.siftList]
    siftList.forEach(a => {
      a.choices.forEach((b, i) => {
        if (i === 0) {
          b.choice = true
        } else {
          b.choice = false
        }
      })
    })
    this.setData({
      siftList: siftList
    })
  },
  closeSift() { // 查看筛选结果
    this.setData({
      siftShow: false
    })
    this.tabBarToggle(true)
  },
  choiceSift(e) { // 筛选面板内选择
    let index = e.currentTarget.dataset.index,
      cIndex = e.currentTarget.dataset.cindex
    let siftList = [...this.data.siftList]
    let item = {
      ...siftList[index]
    }
    item.choices.forEach(a => {
      a.choice = false
    })
    item.choices[cIndex].choice = true
    siftList[index] = {
      ...item
    }
    this.setData({
      siftList: siftList
    })
  },
  checkNavItem(e) { //切换保姆和家长
    this.setData({
      currentNav: e.currentTarget.dataset.index
    })
    if (this.data.querys[e.currentTarget.dataset.index].pageNum != 0 && this.data.querys[e.currentTarget.dataset.index].finish) return false
    if (this.data.currentNav === 0) {
      if (this.data.amahList.length > 0) return false
      this.getAmahList()
    } else if (this.data.currentNav === 1) {
      if (this.data.parentsList.length > 0) return false
      this.getHelpList()
    }
  },
  cancelPcas(event) { // 取消选择服务区域
    this.setData({
      pcasIndex: (this.data.pcasIndex - 1) < 0 ? 0 : this.data.pcasIndex - 1
    })
  },
  onConfirmExpList(event) { // 选择从业时间
    const {
      picker,
      value,
      index
    } = event.detail
  },
  showSiftReasult() {
    let data = {},
      query = {
        ...this.data.query
      }
    this.data.siftList.forEach(a => {
      delete query[a.label]
      if (!a.choices[0].choice) {
        a.choices.forEach(b => {
          if (b.choice) {
            data[a.label] = b.value
          }
        })
      }
    })
    this.setData({
      query: query
    })
    this.queryData(data)
    this.closeSift()
  },
  tabBarToggle(flag) {
    this.getTabBar().setData({ // 显示/隐藏底部Tab
      show: flag
    })
  },
  getAmahList() { // 获取保姆列表
    wx.showLoading()
    let querys = [...this.data.querys]
    let queryData = {
      ...querys[this.data.currentNav],
      ...this.data.query
    }
    delete queryData.finish
    delete queryData.loading
    if (queryData.serviceMode === 0) delete queryData.serviceMode
    app.globalData.agriknow.getAmahList(queryData).then(res => {
      wx.hideLoading()
      if (res.code === "success") {
        querys[this.data.currentNav].finish = res.data.next === 0
        this.setData({
          querys: querys,
          amahList: querys[this.data.currentNav].pageNum > 1 ? [...this.data.amahList, ...res.data.records] : res.data.records
        })
      }
    })
  },
  getHelpList(data) { //获取家长求助列表
    wx.showLoading()
    let querys = [...this.data.querys]
    let queryData = {
      ...querys[this.data.currentNav],
      ...this.data.query
    }
    delete queryData.finish
    delete queryData.loading
    if (queryData.serviceMode === 0) delete queryData.serviceMode
    app.globalData.agriknow.getParentsList(queryData).then(res => {
      wx.hideLoading()
      if (res.code === "success") {
        querys[this.data.currentNav].finish = res.data.next === 0
        this.setData({
          querys: querys,
          parentsList: querys[this.data.currentNav].pageNum > 1 ? [...this.data.parentsList, ...res.data.records] : res.data.records
        })
      }
    })
  },
  queryData(query) {
    let data = {}
    // 生成地区查询条件
    if (this.data.areaCodes.length === 4) {
      data.serviceArea = {
        provinceCode: this.data.areaCodes[0],
        cityCode: this.data.areaCodes[1],
        areaCode: this.data.areaCodes[2],
        streetCode: this.data.areaCodes[3]
      }
    }
    if (query) {
      data = {
        ...data,
        ...query
      }
    }
    let querys = this.data.query
    querys = {
      ...querys,
      ...data
    }
    if (this.data.areaCodes.length != 4 && querys.serviceArea) {
      delete querys.serviceArea
    }
    let dataQuerys = [...this.data.querys]
    dataQuerys[this.data.currentNav].pageNum = 1
    this.setData({
      query: querys,
      querys: dataQuerys
    })
    this[['getAmahList', 'getHelpList'][this.data.currentNav]]()
  },
  getBanner() {
    app.globalData.agriknow.getBannerList({
      bannerUseType: 3,
      clientType: 2
    }).then(res => {
      if (res.code === "success") {
        this.setData({
          banner: res.data
        })
      }
    })
  },
  focus(data) { // 关注取消关注
    let subscribeFlag = data.detail.subscribeFlag
    app.globalData.agriknow.attention({
      followerUid: data.detail.followerUid,
      subscribeFlag: [1, 0][subscribeFlag]
    }, true).then(res => {
      if (res.code === "success") {
        wx.showToast({
          title: ['关注成功', '已取消关注'][subscribeFlag],
          icon: "success",
          duration: 1000
        })
        let List = this.data.currentNav === 1 ? [...this.data.parentsList] : [...this.data.amahList]
        List[data.detail.index].subscribeFlag = ([1, 0][subscribeFlag])
        if (this.data.currentNav === 1) {
          this.setData({
            parentsList: [...List]
          })
        } else {
          this.setData({
            amahList: [...List]
          })
        }
      } else {
        wx.showToast({
          title: res.msg,
          icon: "error",
          duration: 2000
        })
      }
    })
  }
})
// pages/myRecruit/myRecruit.js
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    myRecruitList: [],
    show: false,
    loading: false,
    pageNum: 1,
    pageSize: 10,
    next: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      pageNum: 1,
      pageSize: 10
    })
    this.getParentsJobList({
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize
    }, true)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},
  releaseRecruit() {
    app.globalData.agriknow.checkPublishCount()
      .then(res => {
        // wx.navigateTo({
        //   url: '/pages/recruitment/recruitment'
        // })

        if (res.code === 'success') {
          if (res.data === -1 || res.data > 0) {
            wx.navigateTo({
              url: '/pages/recruitment/recruitment'
            })
          } else if (res.data === 0) {
            wx.showModal({
              title: '提示',
              content: '招骋条数已用完，是否现在去充值',
              success(res) {
                if (res.confirm) {
                  wx.navigateTo({
                    url: '/pages/setMeal/setMeal'
                  })
                }
              }
            })
          }
        } else {
          wx.showToast({
            title: '请求出错了！',
            icon: 'none'
          })
        }
      })

  },
  editRecruit(event) {
    wx.navigateTo({
      url: `/pages/recruitment/recruitment?recruitId=${event.currentTarget.dataset.recruitid}`
    })
  },
  // 获取招聘列表  // "enablePullDownRefresh": true 
  getParentsJobList(data, loading = false) {
    this.setData({
      loading: true
    })
    app.globalData.agriknow.getJobList(data, loading)
      .then(res => {
        this.setData({
          loading: false
        })
        if (data.pageNum === 1) {
          this.setData({
            myRecruitList: res.data.records,
            next: res.data.next
          })
        } else {
          let newList = JSON.parse(JSON.stringify(this.data.myRecruitList))
          this.setData({
            myRecruitList: [...newList, ...res.data.records],
            next: res.data.next
          })
        }
      })
  },
  handleRecruit(event) {
    wx.showModal({
      content: '您确定关闭招骋吗？',
      success(res) {
        if (res.confirm) {
          let {
            id,
            jobswitch
          } = event.currentTarget.dataset
          app.globalData.agriknow.updateJobSwitch({
              id,
              jobSwitch: jobswitch ? 0 : 1
            })
            .then(res => {
              if (res.code === 'success') {
                wx.showToast({
                  title: '关闭成功！',
                  duration: 2000,
                  success: () => {
                    setTimeout(() => {
                      this.getParentsJobList({
                        pageNum: this.data.pageNum,
                        pageSize: this.data.pageSize
                      })
                    }, 1000)
                  }
                })
              }
            })
        }
      }
    })


  },
  // 刷新
  refreshEvent() {
    this.setData({
      pageNum: 1,
      pageSize: 10
    })
    this.getParentsJobList({
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize
    })
  },
  // 上拉加载
  loadMoreEvent() {
    if (this.data.next) {
      this.getParentsJobList({
        pageNum: ++this.data.pageNum,
        pageSize: this.data.pageSize
      })
    }
  }
})
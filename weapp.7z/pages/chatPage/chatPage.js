const app = getApp();
let disp = require("../../utils/broadcast");
import {
  formatTime,
  setStorageChat,
  commentTimeHandle
} from '../../utils/util'
const recorderManager = wx.getRecorderManager()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    next: 0, // 上一页,
    pageSize: 20,
    pageNum: 1,
    clientHeight: 0,
    isIphoneX: false,
    textorVoice: true,
    userId: '',
    chatList: [],
    sendData: '',
    btnText: '按住说话',
    hxchatName: null,
    whoChat: '客服',
    isService: true,
    inputHeight: 0,
    faceList: [],
    isFace: false, // 是否显示表情
    inputAutosize: {
      maxHeight: 40,
      minHeight: 20
    },
    serviceHint: '',
    animationIndex: 0,
    scrollTop: 0
  },

  // 发送文本消息
  sendMessage() {
    if (!this.data.sendData) {
      wx.showToast({
        title: '请输入内容再发送',
        icon: 'none'
      })
      return
    }
    let self = this
    // 环信发送消息
    let id = wx.WebIM.conn.getUniqueId(); // 生成本地消息id
    let msg = new wx.WebIM.message('txt', id); // 创建文本消息
    msg.set({
      msg: this.data.sendData, // 消息内容
      to: this.data.hxchatName, // 接收消息对象（用户id）
      from: JSON.parse(wx.getStorageSync('huanxin_info')).username,
      chatType: 'singleChat', // 设置为单聊,
      ext: {
        name: app.globalData.userInfo().nickName, // 发送人的name
        avatar: 'https://dss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3052225689,834940206&fm=26&gp=0.jpg', // 测试用的头像
        time: formatTime(new Date())
      },
    });
    wx.WebIM.conn.send(msg.body);
    msg.body.nickName = app.globalData.userInfo().nickName
    msg.body.paly = false
    let msgList = self.data.chatList
    msgList.push(msg.body)
    this.setData({
      chatList: msgList,
      sendData: '',
    }, () => {
      this.pageScrollToBottom()
    })
  },
  // 录音授权
  executeRecord() {
    wx.getSetting({
      success: (res) => {
        let recordAuth = res.authSetting['scope.record']
        if (recordAuth == false) { //已申请过授权，但是用户拒绝
          wx.openSetting({
            success: function (res) {
              let recordAuth = res.authSetting['scope.record']
              if (recordAuth == true) {
                wx.showToast({
                  title: "授权成功",
                  icon: "success"
                })
              } else {
                wx.showToast({
                  title: "请授权录音",
                  icon: "none"
                })
              }
              // me.setData({
              //   isLongPress: false
              // })
            }
          })
        } else if (recordAuth == true) { // 用户已经同意授权
          this.startHandel()
        } else { // 第一次进来，未发起授权
          wx.authorize({
            scope: 'scope.record',
            success: () => { //授权成功
              wx.showToast({
                title: "授权成功",
                icon: "success"
              })
            }
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: "鉴权失败，请重试",
          icon: "none"
        })
      }
    })
  },
  // 按住录音
  startHandel(e) {
    this.setData({
      btnText: '向上滑动取消',
      startPageY: e.changedTouches[0].pageY
    })
    wx.showLoading({
      icon: 'none',
      title: '正在录音...',
    })
    const options = {
      duration: 10000,
      sampleRate: 44100,
      numberOfChannels: 1,
      encodeBitRate: 192000,
      format: 'mp3',
      frameSize: 60
    }
    recorderManager.start(options)
    recorderManager.onError(err => {
      console.log(err, '444')
    })
  },
  // 松开按钮
  endHandle(e) {
    let endPageY = e.changedTouches[0].pageY
    if (this.data.startPageY - endPageY >= 100) {
      wx.showToast({
        title: '你取消了发送',
        icon: 'none'
      })
      return
    }
    recorderManager.onStop((res) => {
      if (res.duration < 1000) {
        wx.showToast({
          title: "录音时间太短",
          icon: "none"
        })
      } else {
        // 上传
        this.uploadRecord(res.tempFilePath, res.duration)
      }
    })
    recorderManager.stop()
    wx.hideLoading()
    this.setData({
      btnText: '按住说话',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let self = this
    this.setData({
      isIphoneX: app.globalData.Wechat.isIphoneX,
      clientHeight: app.globalData.Wechat.clientHeight - app.globalData.Wechat.navHeight - 56 - (this.data.isIphoneX ? 40 : 20),
      userId: JSON.parse(wx.getStorageSync('huanxin_info')).username
    })
    // 没有参数默认是客服
    if (Object.keys(options).length) {
      this.setData({
        hxchatName: options.huanxinUserName,
        whoChat: options.huanxinUserName,
        isService: false,
        pageSize: 20,
        pageNum: 1
      })
      this.getChatRecordList({
        fromUserName: JSON.parse(wx.getStorageSync('huanxin_info')).username,
        pageNum: this.data.pageNum,
        pageSize: this.data.pageSize,
        toUserName: this.data.hxchatName
      }).then(res => {
        this.pageScrollToBottom()
      })
    } else {
      Promise.all([this.getService({
          type: 'service_time_desc'
        }), this.getKefu()])
        .then(res => {
          if (res[0].code === 'success' && res[1].code === 'success') {
            this.setData({
              hxchatName: res[1].data,
              isService: true,
              serviceHint: res[0].data[0].dictLabel
            })
          }
        })
    }
    //收到普通消息
    disp.on('app.onTextMessage', function (message) {
      // 只对正在聊天的人才加入消息
      if (message.from != self.data.hxchatName) return
      let msgList = JSON.parse(JSON.stringify(self.data.chatList))
      message.paly = false
      message.time = commentTimeHandle(new Date(message.time || message.ext.time).getTime())
      msgList.push(message)
      self.setData({
        chatList: msgList
      }, () => {
        self.pageScrollToBottom()
      })

    })
    // 收到 语音 
    disp.on('app.onAudioMessage', function (message) {
      // 只对正在聊天的人才加入消息
      if (message.from != self.data.hxchatName) return
      let msgList = JSON.parse(JSON.stringify(self.data.chatList))
      message.time = commentTimeHandle(new Date(message.time || message.ext.time).getTime())
      msgList.push(message)
      self.setData({
        chatList: msgList
      }, () => {
        self.pageScrollToBottom()
      })

    })
    // 已读 id 对不上会有点问题
    disp.on('app.read.onTextMessage', function (message) {
      let msgList = JSON.parse(JSON.stringify(self.data.chatList)).map(item => {
        if (item.mid === message.mid) {
          item.read = true
        }
        return item
      })
      self.setData({
        chatList: msgList
      })

    })
    // 成功发送到服务器后设置mid
    disp.on('app.received.onTextMessage', function (message) {
      //  // 缓存聊天记录
      //  setStorageChat('set', `${msg.body.from}_${msg.body.to}`, msg.body, 'chat')
      self.setData({
        chatList: self.data.chatList.map(item => {
          if (item.id == message.id) {
            item.id = message.mid
            // 缓存聊天记录
            setStorageChat('set', `${item.from}_${item.to}`, item, 'chat')
          }
          return item
        })
      })
    })
    // 查找 本地聊天记录
    self.setData({
      // chatList: [...this.data.chatList, ...setStorageChat('get', `${this.data.userId}_${this.data.hxchatName}`)].map(item => {
      //   item.time = commentTimeHandle(new Date(item.time || item.ext.time).getTime())
      //   item.isplay = false
      //   return item
      // }),
      // 表情
      faceList: wx.WebIM.emoji
    })
    // 执行回执
    // this.data.chatList.length && app.ack(this.data.chatList[this.data.chatList.length - 1])
  },
  refreshEvent() {
    this.getChatRecordList({
      fromUserName: JSON.parse(wx.getStorageSync('huanxin_info')).username,
      pageNum: ++this.data.pageNum,
      pageSize: this.data.pageSize,
      toUserName: this.data.hxchatName
    }).then(res => {
      this.setData({
        scrollTop: (65 * res) - app.globalData.Wechat.clientHeight
      })
      console.log(this.data.scrollTop)
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成 
   */
  onReady: function () {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},
  // 获取随机客服
  getKefu() {
    return new Promise((resolve, reject) => {
      app.globalData.agriknow.getKefu()
        .then(res => {
          resolve(res)
        }).catch(err => {
          reject(err)
        })
    })

  },
  pageScrollToBottom: function () {
    this.setData({
      scrollTop: 65 * this.data.chatList.length
    })
    // wx.createSelectorQuery().select('#scrollpage').boundingClientRect(function (rect) {
    //   if (rect.height > (app.globalData.Wechat.clientHeight - app.globalData.Wechat.navHeight - 96)) {
    //     wx.pageScrollTo({
    //       scrollTop: rect.height,
    //     });
    //   }
    // }).exec()
  },
  // 获取聊天记录
  getChatRecordList(val) {
    return new Promise((resolve, reject) => {
      app.globalData.agriknow.getChatRecord(val)
        .then(res => {
          if (res.code === 'success') {
            let data = res.data.records.map(item => {
              item.time = commentTimeHandle(new Date(item.createTime))
              return item
            })
            if (val.pageNum > 1) {
              let list = this.data.chatList
              list.unshift(...data)
              this.setData({
                chatList: list,
                next: res.data.next
              })
            } else {
              this.setData({
                chatList: data,
                next: res.data.next
              })
            }
            resolve(data.length)
          }
        })
        .catch(err => {
          reject(err)
        })
    })

  },
  // 文字语音切换
  changeManner() {
    this.setData({
      textorVoice: !this.data.textorVoice,
      isFace: false,
    })
  },
  inputFocus(e) {
    this.setData({
      inputHeight: e.detail.height,
      isFace: false
    })
  },
  inputBlur() {
    this.setData({
      inputHeight: 0,
    })
  },
  showFace() {
    this.setData({
      isFace: !this.data.isFace,
    })
  },
  selectedFace(e) {
    let {
      facekey,
      faceval
    } = e.currentTarget.dataset
    this.setData({
      sendData: this.data.sendData + facekey,

    })
  },
  // 获取客服默认展示语
  getService(data) {
    return new Promise((resovle, reject) => {
      app.globalData.agriknow.getServiceHint(data, false)
        .then(res => {
          resovle(res)
        }).catch(err => {
          reject(res)
        })
    })
  },
  // 上传
  uploadRecord(tempFilePath, dur) {
    var str = wx.WebIM.config.appkey.split("#");
    var self = this;
    var token = wx.WebIM.conn.context.accessToken
    var domain = wx.WebIM.conn.apiUrl
    wx.uploadFile({
      url: domain + "/" + str[0] + "/" + str[1] + "/chatfiles",
      filePath: tempFilePath,
      name: "file",
      header: {
        "Content-Type": "multipart/form-data",
        Authorization: "Bearer " + token
      },
      success(res) {
        // 发送 xmpp 消息
        var id = wx.WebIM.conn.getUniqueId();
        var msg = new wx.WebIM.message('audio', id);
        var dataObj = JSON.parse(res.data);
        // 接收消息对象
        msg.set({
          apiUrl: wx.WebIM.config.apiURL,
          accessToken: token,
          body: {
            type: 'audio',
            url: dataObj.uri + "/" + dataObj.entities[0].uuid,
            filetype: "audio",
            filename: tempFilePath,
            accessToken: token,
            length: Math.ceil(dur / 1000),
          },
          to: self.data.hxchatName, // 接收消息对象（用户id）
          from: JSON.parse(wx.getStorageSync('huanxin_info')).username,
          roomType: false,
          chatType: 'singleChat',
          success: function (argument) {
            disp.fire('em.chat.sendSuccess', id);
          }
        });
        msg.body.length = Math.ceil(dur / 1000);
        wx.WebIM.conn.send(msg.body);
        msg.body.nickName = app.globalData.userInfo().nickName
        let msgList = self.data.chatList
        msgList.push(msg.body)
        self.setData({
          chatList: msgList,
        }, () => {
          self.pageScrollToBottom()
        })
      }
    });
  },
  // 点击播放其他全部不能播放
  playAudio(e) {
    this.setData({
      chatList: this.data.chatList.map(item => {
        item.id === e.detail.id ? item.isplay = true : item.isplay = false
        return item
      })
    })
  },
  audioEnd() {
    this.setData({
      chatList: this.data.chatList.map(item => {
        item.isplay = false
        return item
      })
    })
  },
})
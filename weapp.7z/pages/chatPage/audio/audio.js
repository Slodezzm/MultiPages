// pages/chatPage/audio/audio.js
let audioCtxFc = wx.createInnerAudioContext();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    msg: {
      type: Object
    },
    left: {
      type: Boolean,
      value: false
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    loading: false
  },

  /**
   * 组件的方法列表
   */
  methods: {
    playAudio(e) {
      if (this.properties.msg.isplay) {
        audioCtxFc.stop()
        this.triggerEvent('audioEnd')
        return
      }
      let msg = e.currentTarget.dataset.msg
      let self = this
      let data = e.currentTarget.dataset
      self.setData({
        loading: true
      })
      wx.downloadFile({
        url: data.msg.url || data.msg.body.url,
        header: {
          "X-Requested-With": "XMLHttpRequest",
          Accept: "audio/mp3",
          Authorization: "Bearer " + data.msg.accessToken || data.msg.body.accessToken
        },
        success(res) {
          audioCtxFc.src = res.tempFilePath;
          audioCtxFc.play();
          self.triggerEvent('playAudio', msg)
          self.setData({
            loading: false
          })
          audioCtxFc.onEnded(() => {
             self.triggerEvent('audioEnd')
          })

        },
        fail(e) {
          wx.showToast({
            title: "播放失败",
            duration: 1000
          });
          self.setData({
            loading: false
          })
        }
      });

    },

  }
})
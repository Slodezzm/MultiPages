// pages/serve/serve.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loading: false,
    nannyAdress: [
      {
        title: '到府',
        subhead: '到家长家',
        id: 1,
        isActivity: false
      },
      {
        title: '在家',
        subhead: '在保姆家',
        id: 2,
        isActivity: false
      }
    ],
    addrerssId: [],
    serveType: [
      {
        title: '短期',
        subhead: '临时，几个礼拜',
        id: 1,
        isActivity: false
      },
      {
        title: '长期',
        subhead: '一年以上',
        id: 2,
        isActivity: false
      },
    ],
    selectServeTyped: [],
    result: [],
    serveScope: [],
    hideScope: true,
    hideTime: true,
    chargeScope: [
      {
        isHoliday: false,
        isHour: true,
        isDay: false,
        isMonth: false,
        priceStart: '',
        priceEnd: '',
        id: 1
      },
      {
        isHoliday: false,
        isHour: false,
        isDay: true,
        isMonth: false,
        priceStart: '',
        priceEnd: '',
        id: 2
      },
      {
        isHoliday: true,
        isHour: true,
        isDay: false,
        isMonth: false,
        priceStart: '',
        priceEnd: '',
        id: 3
      }, {
        isHoliday: true,
        isHour: false,
        isDay: true,
        isMonth: false,
        priceStart: '',
        priceEnd: '',
        id: 4
      }, {
        isHoliday: false,
        isHour: false,
        isDay: false,
        isMonth: true,
        priceStart: '',
        priceEnd: '',
        id: 5
      }
    ],
    timeList: [], // 托育时间段 
    theTimeList: [], // 托育时间的基础数据
    addAdderssList: [],  // 新增的地址list
    adderssActive: 0,
    isAdderss: false,
    provinceList: [],
    cityList: [],
    areaList: [],
    streetList: [],
    province: {},
    city: {},
    area: {},
    street: {},
    editIndex: null,
    // 
    provincDefaultindex: 0,
    cityDefaultindex: 0,
    areaDefaultindex: 0,
    streetDefaultindex: 0,
  },
  // 设置数组中的对象属性的双向绑定
  bindAndSet(e) {
    let name = 'chargeScope[' + e.currentTarget.dataset.inpval + '].' + e.currentTarget.dataset.inpkey
    this.setData({
      [name]: e.detail
    })
  },
  // 选择托育
  selectAdderss(event) {
    let { id } = event.currentTarget.dataset
    if (this.data.serveType.includes(id)) {
      let newServeType = this.data.addrerssId.filter((item) => {
        return item !== id
      })
      this.setData({
        addrerssId: newServeType
      })
    } else {
      let idList = this.data.addrerssId
      idList.push(id)
      this.setData({
        addrerssId: idList
      })
    }
    this.selectLocale(id)
  },
  // 回显选择
  selectLocale(id) {
    let newNannyAdress = this.data.nannyAdress.map((item) => {
      if (item.id === id) {
        item.isActivity = this.data.addrerssId.includes(id)
      }
      return item
    })
    this.setData({
      nannyAdress: newNannyAdress
    })
  },

  // 服务形态
  selectServeType(event) {
    let { id } = event.currentTarget.dataset
    if (this.data.selectServeTyped.includes(id)) {
      let newSelectServeTyped = this.data.selectServeTyped.filter((item) => {
        return item !== id
      })
      this.setData({
        selectServeTyped: newSelectServeTyped
      })
    } else {
      let idList = this.data.selectServeTyped
      idList.push(id)
      this.setData({
        selectServeTyped: idList
      })
    }
    this.selectServeTyped(id)
  },
  // 服务形态 回显
  selectServeTyped(id) {
    let newNannyAdress = this.data.serveType.map((item) => {
      if (item.id === id) {
        item.isActivity = this.data.selectServeTyped.includes(id)
      }
      return item
    })
    this.setData({
      serveType: newNannyAdress
    })
  },

  // 选择指定服务范围
  selectServeChange(event) {
    this.setData({
      result: event.detail,
    });
  },
  // 隐藏 选择自定服务范围
  hideServeScope() {
    this.setData({
      hideScope: !this.data.hideScope
    })
  },
  // 隐藏 服务时间段
  hideServeTime() {
    this.setData({
      hideTime: !this.data.hideTime
    })
  },
  // 获取保姆服务范围
  getServiceSkillList() {
    return new Promise((resolve, reject) => {
      app.globalData.agriknow.getServiceSkillList()
        .then(res => {
          resolve(res)
        })
        .catch(err=>{
          reject(err)
        })
    })
  },
  // 获取时间段的基础数据
  getPointTimeList() {
    return new Promise((resolve, reject) => {
      app.globalData.agriknow.getTimePointList()
        .then(res => {
          resolve(res)
        })
        .catch(err=>{
          reject(err)
        })
    })
  },
  // 托育时间段 所选择的 时间list 
  selectedTimeList(event) {
    this.setData({
      timeList: event.detail
    })
  },
  // 获取地区 list 
  getAreaList(data) {
    if (data.type > 1 && !data.code) {
      wx.showToast({
        title: '请选择上一级的地址！',
        icon: 'none'
      })
      return
    }
    this.setData({
      adderssLoading: true
    })
    app.globalData.agriknow.getAreaList(data)
      .then(res => {
        this.setData({
          adderssLoading: false
        })
        let areaList = res.data.areaList.map(item => {
          item.text = item.name
          return item
        })
        data.type === 1 && this.setData({
          provinceList: areaList,
          province: {
            ...areaList[0],
            defaultIndex: 0
          }
        })
        console
        data.type === 2 && this.setData({
          cityList: areaList,
          city: {
            ...areaList[0],
            index: 0
          }
        })
        data.type === 3 && this.setData({
          areaList: areaList,
          area: {
            ...areaList[0],
            index: 0
          }
        })
        data.type === 4 && this.setData({
          streetList: areaList,
          street: {
            ...areaList[0],
            index: 0
          }
        })
      })
  },
  // 选择 地址
  adderssSelect() {
    this.getAreaList({ type: 1 })
    this.setData({
      isAdderss: true
    })
  },
  closeAdderssSelect() {
    this.setData({
      isAdderss: false
    })
  },
  confirmAdderssSelect() {
    if (Object.keys(this.data.province).length <= 0 || Object.keys(this.data.city).length <= 0 || Object.keys(this.data.area).length <= 0 || Object.keys(this.data.street).length <= 0) {
      wx.showToast({
        title: '请先选择完省市区省份！',
        icon: 'none'
      })
      return
    }
    let list = JSON.parse(JSON.stringify(this.data.addAdderssList))
    let add = {
      province: {
        provinceCode: this.data.province.code,
        provinceName: this.data.province.name,
        type: this.data.province.type,
        index: this.data.province.index
      },
      city: {
        cityCode: this.data.city.code,
        cityName: this.data.city.name,
        type: this.data.city.type,
        index: this.data.city.index
      },
      area: {
        areaCode: this.data.area.code,
        areaName: this.data.area.name,
        type: this.data.area.type,
        index: this.data.area.index
      },
      street: {
        streetCode: this.data.street.code,
        streetName: this.data.street.name,
        type: this.data.street.type,
        index: this.data.street.index
      }
    }
    if (this.data.editIndex != null) {
      list[this.data.editIndex] = add
      this.setData({
        editIndex: null
      })
    } else {
      list.push(add)
    }
    // 地址选择后清空
    this.setData({
      addAdderssList: list,
      province: {},
      city: {},
      area: {},
      street: {},
      provinceList: [],
      cityList: [],
      areaList: [],
      streetList: [],
    })
    this.closeAdderssSelect()
  },
  selectProvince(event) {
    let { type } = event.currentTarget.dataset
    let { index } = event.detail
    let data = {}
    if (type === 1) {
      data = {
        province: {
          ...event.detail.value,
          index: index
        },
        city: {},
        area: {},
        street: {},
      }
    } else if (type === 2) {
      data = {
        city: {
          ...event.detail.value,
          index: index
        },
        area: {},
        street: {},
      }
    } else if (type === 3) {
      data = {
        area: {
          ...event.detail.value,
          index: index
        },
        street: {},
      }
    } else if (type === 4) {
      data = {
        street: {
          ...event.detail.value,
          index: index
        },
      }
    }
    this.setData(data)
  },
  tabChange(event) {
    let { index } = event.detail
    index === 1 &&
      this.getAreaList({ code: this.data.province.code, type: index + 1 })
    index === 2 &&
      this.getAreaList({ code: this.data.city.code, type: index + 1 })
    index === 3 &&
      this.getAreaList({ code: this.data.area.code, type: index + 1 })
  },
  // 删除已选择地址 
  deleteChildInfo(e) {
    let list = JSON.parse(JSON.stringify(this.data.addAdderssList))
    list.splice(e.currentTarget.dataset.index, 1)
    this.setData({
      addAdderssList: list
    })
  },
  // 修改地址 默认展示全地址有点问题
  editChildInfo(e) {
    let { index } = e.currentTarget.dataset
    this.setData({
      editIndex: index,
    })
    let { province, area, city, street } = this.data.addAdderssList[index]
    //   this.setData({
    //     provincDefaultindex: province.index,
    //     cityDefaultindex: city.index,
    //     areaDefaultindex: area.index,
    //     streetDefaultindex: street.index,
    //     adderssActive:3
    //   })
    this.adderssSelect()
    // this.setData({
    //   province,
    //   city,
    //   area,
    //   street,
    // })
    //   this.getAreaList({detail:province.provinceCode},2) 
    //   this.getAreaList({detail:province.cityCode},3) 
    //   this.getAreaList({detail:province.areaCode},4) 
    // this.data.addAdderssList[index].forEach(item=>{
    //   this.adderssSelect()
    //   this.tabChange({detail:item.province.code}) 
    //   this.tabChange({detail:item.city.code}) 
    //   this.tabChange({detail:item.area.code}) 
    // }) 

  },
  // 提交审核
  submitCheck() {
    if (!this.data.addrerssId.length || !this.data.selectServeTyped.length
      || !this.data.result.length || !this.data.addAdderssList.length
      || !this.data.timeList.length) {
      wx.showToast({
        title: '请选择完所有必填项！',
        icon: 'none'
      })
      return
    }
    let servicePrice = this.data.chargeScope.length && this.data.chargeScope.filter(item => {
      return item.priceStart && item.priceEnd
    })
    if (!servicePrice.length) {
      wx.showToast({
        title: '请输入至少一项收费范围',
        icon: 'none'
      })
      return
    }
    let params = {
      serviceModes: this.data.addrerssId,
      serviceCycleTypes: this.data.selectServeTyped,
      serviceAreas: this.data.addAdderssList,
      serviceSkills: this.data.result.map(item => { return parseInt(item) }),
      serviceTimes: this.data.timeList,
      serviceWages: []
    }
    let price = {}
    this.data.chargeScope.forEach(item => {
      if (item.priceStart && item.priceEnd) {
        price.highestPrice = item.priceStart
        price.lowestPrice = item.priceEnd
        if (item.isHoliday && item.isHour) {
          price.wageType = 3
          params.serviceWages.push(price)
          price = {}
        } else if (item.isHoliday && item.isDay) {
          price.wageType = 4
          params.serviceWages.push(price)
          price = {}
        }
        else if (!item.isHoliday && item.isDay) {
          price.wageType = 1
          params.serviceWages.push(price)
          price = {}
        }
        else if (!item.isHoliday && item.isHour) {
          price.wageType = 2
          params.serviceWages.push(price)
          price = {}
        }
        else if (item.isMonth) {
          price.wageType = 5
          params.serviceWages.push(price)
          price = {}
        }
      }
    })



    let infoFile = JSON.parse(wx.getStorageSync('_nannySetAccountInfo'))
    let data = {
      ...infoFile,
      ...params
    }
    wx.setStorageSync('_nannySetAccountInfo', JSON.stringify(data))

    let newadderss = data.serviceAreas.map(item => {
      return {
        areaCode: item.area.areaCode.toString(),
        cityCode: item.city.cityCode.toString(),
        provinceCode: item.province.provinceCode.toString(),
        streetCode: item.street.streetCode.toString(),
      }
    })
    data.healthCardResourceId = data.healthCardResourceId[0].id
    data.idCardBackResourceId = data.idCardBackResourceId[0].id
    data.idCardFrontResourceId = data.idCardFrontResourceId[0].id
    data.serviceAreas = newadderss
    delete data.nurse
    delete data.environment
    delete data.avatar
    app.globalData.agriknow.updateNurseInfo(data)
      .then(res => {
        if (res.code === 'success') {
          wx.removeStorageSync('_nannySetAccountInfo')
          wx.showToast({
            title: '提交成功！',
            success: () => {
              setTimeout(() => {
                wx.switchTab({
                  url: '/pages/mine/mine'
                })
              }, 1000)
            }
          })
        }
      })
      .catch(err => {
        console(err, 111)
        wx.showToast({
          title: '请求出错了',
          icon: 'none'
        })
      })

  },
  // 回显  返回后页面销毁了再次进来需要拉接口数据  但是本地缓存的数据就不能展示了
  echo(data) {
    let { serviceArea, serviceMode, serviceTime, serviceCycleType, serviceSkill, serviceWage } = data
    let serviceAreaList = serviceArea.map(item => {
      return {
        area: {
          areaCode: item.areaCode,
          areaName: item.areaName
        },
        city: {
          cityCode: item.cityCode,
          cityName: item.cityName
        },
        province: {
          provinceCode: item.provinceCode,
          provinceName: item.provinceName
        },
        street: {
          streetCode: item.streetCode,
          streetName: item.streetName
        }
      }
    })
    let dataInfo = {
      addrerssId: serviceMode.length ? serviceMode : [],
      selectServeTyped: serviceCycleType.length ? serviceCycleType : [],
      addAdderssList: serviceArea.length ? serviceAreaList : [], // 地址
      result: [],
      timeList: serviceTime.length ? serviceTime : [],
      chargeScope: this.data.chargeScope.map((item, index) => {
        serviceWage.forEach(val => {
          if (val.wageType === item.id && val.highestPrice && val.lowestPrice) {
            item.priceStart = val.highestPrice
            item.priceEnd = val.lowestPrice
          }
        })
        return item
      })
    }
    if (serviceSkill.length) {
      serviceSkill.forEach(item => {
        item.status === 1 && dataInfo.result.push(item.id.toString())
      })
    }

    this.setData(dataInfo)
    // 循环选中
    this.data.addrerssId.forEach(id => {
      this.selectLocale(id)
    });
    this.data.selectServeTyped.forEach(id => {
      this.selectServeTyped(id)
    });
  },
  // 编辑拉数据
  getNurseServiceInfo() {
    return new Promise((resolve, reject) => {
      app.globalData.agriknow.getNurseServiceInfo()
        .then(res => {
          resolve(res)
        })
        .catch(err=>{
          reject(err)
        })
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      loading: true
    })
    Promise.all([this.getServiceSkillList(), this.getPointTimeList(), this.getNurseServiceInfo()])
      .then(res => {
        if (res[0].code === 'success' && res[1].code === 'success' && res[2].code === 'success') {
          this.setData({
            serveScope: res[0].data.skillList,
            theTimeList: res[1].data.serviceTime
          })
          this.echo(res[2].data)
        } else {
          wx.showToast({
            title: '请求出错了！',
            icon: 'none'
          })
        }
        this.setData({
          loading: false
        })
      })
      .catch(err => {
        wx.showToast({
          title: '请求出错了！',
          icon: 'none'
        })
      })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
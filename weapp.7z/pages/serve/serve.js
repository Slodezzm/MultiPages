// pages/serve/serve.js
const app =  getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navHeight:0,
    nannyAdress: [
      {
        title: '到府',
        subhead: '到家长家',
        id: 0,
        isActivity: false
      },
      {
        title: '在宅',
        subhead: '在保姆家',
        id: 1,
        isActivity: false
      }
    ],
    addrerssId: [],
    serveType: [
      {
        title: '短期',
        subhead: '临时，几个礼拜',
        id: 0,
        isActivity: false
      },
      {
        title: '长期',
        subhead: '一年以上',
        id: 1,
        isActivity: false
      },
    ],
    result: [],
    serveScope: ['制作副食品', '奶瓶清洗',
      '宝宝衣物清洗', '宝宝周遭环境打扫',
      '其他家务', '可配合不使用3C育儿',
      '可配合家长外出', '可接送小朋友'],
    hideScope: false,
    hideTime: true,
    chargeScope: [
      {
        isHoliday: false,
        isHour: true,
        isDay: false,
        isMonth: false,
        priceStart: '',
        priceEnd: '',
        id: 0
      },
      {
        isHoliday: false,
        isHour: false,
        isDay: true,
        isMonth: false,
        priceStart: '',
        priceEnd: '',
        id: 1
      },
      {
        isHoliday: true,
        isHour: true,
        isDay: false,
        isMonth: false,
        priceStart: '',
        priceEnd: '',
        id: 2
      }, {
        isHoliday: true,
        isHour: false,
        isDay: true,
        isMonth: false,
        priceStart: '',
        priceEnd: '',
        id: 3
      }, {
        isHoliday: false,
        isHour: false,
        isDay: false,
        isMonth: true,
        priceStart: '',
        priceEnd: '',
        id: 4
      }
    ]
  },
  // 选择地址
  selectAdderss(event) {
    let { id } = event.currentTarget.dataset
    if (this.data.addrerssId.includes(id)) {
      let newAddrerssId = this.data.addrerssId.filter((item) => {
        return item !== id
      })
      this.setData({
        addrerssId: newAddrerssId
      })
    } else {
      let idList = this.data.addrerssId
      idList.push(id)
      this.setData({
        addrerssId: idList
      })
    }
    let newNannyAdress = this.data.nannyAdress.map((item) => {
      if (item.id === id) {
        item.isActivity = this.data.addrerssId.includes(id)
      }
      return item
    })
    this.setData({
      nannyAdress: newNannyAdress
    })
  },
  // 选择指定服务范围
  selectServeChange(event) {
    this.setData({
      result: event.detail,
    });
  },
  // 隐藏 选择自定服务范围
  hideServeScope() {
    this.setData({
      hideScope: !this.data.hideScope
    })
  },
  // 隐藏 服务时间段
  hideServeTime() {
    this.setData({
      hideTime: !this.data.hideTime
    })
  },
  // 提交审核
  submitCheck(){
  
    wx.switchTab({
      url: '/pages/mine/mine'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navHeight: app.globalData.Wechat.navHeight
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
// pages/focus/focus.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    height: 0,
    role: 0, //角色1保姆 2家长
    pageNum: 1,
    pageSize: 10,
    next: 0, //是否有下一页
    parentList: [], //家长关注列表
    nurseList: [], //保姆关注列表
    loading: false
  },
  // 刷新
  refreshEvent() {
    this.setData({
      pageNum: 1,
      next: 1,
      parentList: [],
      nurseList: []
    })
    let userInfo = app.globalData.userInfo()
    userInfo.role === 1 && this.getParentList({
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize,
    }, false)
    userInfo.role === 2 && this.getAmahList({
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize,
    }, false)
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let userInfo = app.globalData.userInfo()
    userInfo.role === 1 && this.getParentList({
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize,
    }, true)
    userInfo.role === 2 && this.getAmahList({
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize,
    }, true)
    this.setData({
      role: userInfo.role,
      height: (app.globalData.Wechat.navHeight)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 1
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  loadMoreEvent(e) { // 滚动到底部
    let role = this.data.role
    let next = this.data.next
    role === 1 && next && this.getParentList({
      pageNum: ++this.data.pageNum,
      pageSize: this.data.pageSize,
    }, false)
    role === 2 && next && this.getAmahList({
      pageNum: ++this.data.pageNum,
      pageSize: this.data.pageSize,
    }, false)
  },
  // 获取家长关注列表

  getParentList(data, load = false) {
    this.setData({
      loading: true
    })
    app.globalData.agriknow.getParentFocusList(data, load)
      .then((result) => {
        this.setData({
          loading: false,
          pageNum: ++this.data.pageNum,
          parentList: [...this.data.parentList, ...result.data.records],
          next: result.data.next
        })
      })
  },
  // 获取保姆关注列表
  getAmahList(data, load = false) {
    this.setData({
      loading: true
    })
    app.globalData.agriknow.getamahFocusList(data, load)
      .then((result) => {
        if (data.pageNum > 1) {
          this.setData({
            loading: false,
            nurseList: [...this.data.nurseList, ...result.data.records],
            next: result.data.next
          })
        } else {
          this.setData({
            loading: false,
            nurseList: result.data.records,
            next: result.data.next
          })
        }
      })
  },
  attention(e) { //用户取消关注
    let {
      followerUid,
      subscribeFlag
    } = e.detail
    app.globalData.agriknow.attention({
        followerUid,
        subscribeFlag: 0
      })
      .then((result) => {
        // 更新列表
        this.setData({
          pageNum: 1,
          next: 1,
          parentList: [],
          nurseList: []
        })
        let role = this.data.role
        role === 1 && this.getParentList({
          pageNum: this.data.pageNum,
          pageSize: this.data.pageSize,
        })
        role === 2 && this.getAmahList({
          pageNum: this.data.pageNum,
          pageSize: this.data.pageSize,
        })
      })
  }
})
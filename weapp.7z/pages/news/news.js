const app = getApp()
// pages/amah/amah.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    scrollTop: 0,
    loading: true,
    navHeight: 0,// nav高度
    banner: [// 轮播图
      {image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F01cbe958c128eba801219c7730c022.jpg&refer=http%3A%2F%2Fimg.zcool.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620371288&t=49e6b80cf8349af6719e3514915911d4', url: '/page/index/index'},
      {image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg011.hc360.cn%2Fk3%2FM0E%2FD1%2F27%2FwKhQx1kNh1qEblJuAAAAALuo5oA225.jpg&refer=http%3A%2F%2Fimg011.hc360.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620373134&t=6c817f8cec38c245159da36b12325fb3', url: '/page/index/index'},
      {image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F01196a58affd53a801219c775892b5.jpg%401280w_1l_2o_100sh.jpg&refer=http%3A%2F%2Fimg.zcool.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620371288&t=7da7a5f459b11f7081af3d8d8f009684', url: '/page/index/index'},
      {image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F013a4f58c128e7a801219c77271242.jpg&refer=http%3A%2F%2Fimg.zcool.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620371288&t=6fe2874185b7d3c8dc04d3f9b5382cce', url: '/page/index/index'},
    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    setTimeout(() => {
      this.setData({
        loading: false
      })
    }, 2000)
    console.log(app.globalData.Wechat.navHeight)
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.setData({
      navHeight: app.globalData.Wechat.navHeight
    })
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getTabBar().setData({// 显示/隐藏底部Tab
      selected: 0,
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },
  onPageScroll(e) {// 页面滚动
    this.setData({
      scrollTop: e.scrollTop
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log(123)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
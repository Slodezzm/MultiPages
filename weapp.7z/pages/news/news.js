const app = getApp()
// pages/amah/amah.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    offsetTop: 0,
    scrollTop: 0,
    loading: false,
    navHeight: 0,// nav高度
    showBanner: true,
    banner: [],
    newsList: [],
    newsNextPage: false,
    newsTab: [],
    tabIndex: 0,
    pageNums: [],
    tabsHasNextPage: [],
    loadNews: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      loading: true,
    })

    app.globalData.agriknow.getBannerList({
      bannerUseType: 2,
      clientType: 2
    }).then(res => {
      if (res.code === "success") {
        this.setData({
          loading: false,
          //  res.data.length || 
          banner: this.data.banner,
          // showBanner: res.data.length > 0
        })
      } else {
        this.setData({
          loading: false
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.setData({
      navHeight: app.globalData.Wechat.navHeight
    })
    this.getNewsTab()
    this.getBanner()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      offsetTop: app.globalData.Wechat.navHeight,
      showIndex: this.data.showIndex + 1
    })
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 0
      })
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function (e) {
    this.setData({
      tabIndex: 0
    })
    this.getNewsTab()
    wx.stopPullDownRefresh()
  },
  onPageScroll(e) {// 页面滚动
    this.setData({
      scrollTop: e.scrollTop
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (!this.data.tabsHasNextPage[this.data.tabIndex] || this.data.loadNews) return
    let pageNums = [...this.data.pageNums]
    pageNums[this.data.tabIndex] = pageNums[this.data.tabIndex] + 1
    this.setData({
      pageNums: pageNums
    })
    this.getNewsList()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getNewsTab() {// 获取新闻分类列表
    this.setData({
      loading: true
    })
    app.globalData.agriknow.sortOfNews().then(res => {
      if (res.code === "success") {
        let newsList = this.data.newsList, tabsHasNextPage = [], pageNums = []
        for (let i = 0; i < res.data.newClassifyList.length; i++) {
          newsList.push([])
          tabsHasNextPage.push(false)
          pageNums.push(1)
        }
        this.setData({
          newsTab: res.data.newClassifyList,
          newsList: newsList,
          tabsHasNextPage: tabsHasNextPage,
          pageNums: pageNums,
          loading: false
        })
        this.getNewsList()
      } else {
        wx.showToast({
          title: res.msg,
          duration: 1000,
          icon: "error"
        })
      }
    })
  },
  getNewsList() { //获取资讯列表
    this.setData({
      loadNews: true
    })
    app.globalData.agriknow.getNewsList({
      classifyId: this.data.newsTab[this.data.tabIndex].id,
      pageNum: this.data.pageNums[this.data.tabIndex],
      pageSize: 10
    }).then(res => {
      if (res.code === "success") {
        let newsList = [...this.data.newsList], tabsHasNextPage = [...this.data.tabsHasNextPage]
        newsList[this.data.tabIndex] = this.data.pageNums[this.data.tabIndex] === 1 ? [...res.data.records] : [...newsList[this.data.tabIndex], ...res.data.records],
          tabsHasNextPage[this.data.tabIndex] = res.data.next == 1
        this.setData({
          newsList: newsList,
          newsNextPage: res.data.next != 0,
          loadNews: false,
          tabsHasNextPage: tabsHasNextPage
        })
   
      } else {
        wx.showModal({
          title: "提示",
          content: "获取资讯失败，是否重新获取？",
          success(res) {
            if (res.confirm) {
              this.getNewsList()
            } else {
              wx.showToast({
                title: '点击右上角...后选择重新进入小程序',
                icon: 'error',
                duration: 1000
              })
            }
          }
        })
      }
    })
  },
  checkNewsTab(e) { // 切换新闻标签
    let queryNews = { ...this.data.queryNews }
    queryNews.classifyId = this.data.newsTab[e.currentTarget.dataset.index].id
    queryNews.pageNum = 1
    this.setData({
      queryNews: { ...queryNews }
    })
  },
  changeTabs(event) {// 改变tab
    this.setData({
      tabIndex: event.detail.index
    })
    this.getNewsList()
  },
  getBanner() {
    app.globalData.agriknow.getBannerList({
      bannerUseType: 2,
      clientType: 2
    }).then(res => {
      if (res.code === "success") {
        this.setData({
          banner: res.data,
          showBanner: res.data.length > 0
        })
      }
    })
  }
})
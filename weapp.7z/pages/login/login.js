// pages/login/login.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navHeight: 0, // nav高度
    protocol: true, //是否阅读协议
    code: null

  },
  accountLogin() {
    wx.navigateTo({
      url: '/pages/accountLogin/accountLogin'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let self = this
    this.setData({
      navHeight: app.globalData.Wechat.navHeight,
    })
    // 进入登录页面时 先获取code 
    wx.login({
      success(res) {
        self.setData({
          code: res.code
        })
      },
      fail(err) {
        wx.showToast({
          title: '授权失败',
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},

  changeProtocol() {
    this.setData({
      protocol: !this.data.protocol
    })
  },
  // 授权并获取手机号码
  wechatLogin(e) {
    let self = this
    let {
      encryptedData,
      iv
    } = e.detail
    if (e.detail.errMsg === 'getPhoneNumber:ok') {
      wx.checkSession({
        success() {
          self.codeLogin({
            encryptedData,
            iv,
            code: self.data.code
          })
        },
        fail() {
          // session_key 已经失效，需要重新执行登录流程
          wx.login({
            success(res) {
              self.setData({
                code: res.code
              })
              self.codeLogin({
                encryptedData,
                iv,
                code: res.code
              })
            },
            fail(err) {
              wx.showToast({
                title: '授权失败',
                icon: 'none'
              })
            }
          })
        }
      })
    } else {
      wx.showToast({
        title: '授权失败！',
        icon: 'none'
      })
    }
  },
  // 用code 登录
  codeLogin({
    encryptedData,
    iv,
    code
  }) {
    // code 换 openId
    app.globalData.agriknow.getOpenId({
        code: code
      })
      .then(res => {
        if (res.code === 'success') {
          // 把openid 存放在 globalData中
          app.globalData.openid = res.data
          app.globalData.agriknow.getToken({
              encryptedData: encryptedData,
              iv: iv,
              openid: res.data
            })
            .then(result => {
              app.loginHandle(result)
            })
        }
      })
      .catch(err => {
        wx.showToast({
          title: '获取openId失败',
          icon: 'none'
        })
      })
  }
})
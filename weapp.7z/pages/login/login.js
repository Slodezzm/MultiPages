// pages/login/login.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navHeight: 0,// nav高度
    protocol: false, //是否阅读协议
  },
  accountLogin() {
    wx.navigateTo({
      url: '/pages/accountLogin/accountLogin'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navHeight: app.globalData.Wechat.navHeight,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  changeProtocol() {
    this.setData({
      protocol: !this.data.protocol
    })
  },
  wechatLogin(e) {
    if (!this.data.protocol) {
      wx.showToast({
        title: '请勾选协议',
        icon: 'none',
      })
      return
    }
    wx.login({
      success (res) {
        if (res.code) {
          //发起网络请求
          console.log(res)
          app.globalData.agriknow.getOpenId({
            code:res.code
          })
            .then((result) => {
              // 获取token
            })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
    
    // wx.getUserProfile({
    //   desc: '用于完善会员资料', // 获取用户个人信息并保存在app.js中
    //   success: (res) => {
    //     console.log(res)
    //     wx.showToast({
    //       title: res.userInfo.nickName,
    //       icon: 'none',
    //     })
    //     console.log(res)
    //     app.userInfo = res.userInfo
    //   },
    //   fail: (err) => {
    //     wx.showToast({
    //       title: '授权失败',
    //       icon: 'none',
    //     })
    //   }
    // })

    // wx.navigateTo({
    //   url:"/pages/bindingAccount/bindingAccount"
    // })
  }
})
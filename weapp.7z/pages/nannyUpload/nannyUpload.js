// pages/nannyUpload/nannyUpload.js
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    loading: false,
    cardFront: [], // 身份证正面
    cardTail: [], // 反面
    nurse: [], // 护理证
    physicalExamination: [], // 体检
    environment: [], // 环境
  },
  next() {
    let { cardFront, cardTail, nurse, physicalExamination, environment } = this.data
    if (!cardFront.length || !cardTail.length) {
      wx.showToast({
        title: '请上传身份证正反面',
        icon: 'none'
      })
      return
    }
    if (!physicalExamination.length) {
      wx.showToast({
        title: '请上传健康证明',
        icon: 'none'
      })
      return
    }
    let infoFile = JSON.parse(wx.getStorageSync('_nannySetAccountInfo'))
    let data = {
      ...infoFile,
      idCardFrontResourceId: cardFront, // 正面
      idCardBackResourceId: cardTail, // 反面
      healthCardResourceId: physicalExamination, // 健康证
      nurse: nurse.length && nurse,
      environment: environment.length && environment
    }
    wx.setStorageSync('_nannySetAccountInfo', JSON.stringify(data))
    wx.navigateTo({
      url: '/pages/serve/serve'
    })
  },
  // 编辑回显
  editGetdata() {
    app.globalData.agriknow.getNurseCertificateList()
      .then(res => {
        if (res.code === 'success') {
          let imgUrl = {
            cardFront: [], // 身份证正面
            cardTail: [], // 反面
            nurse: [], // 护理证
            physicalExamination: [], // 体检
            environment: [], // 环境
          }
          res.data.forEach(item => {
            item.useType === 2 && imgUrl.cardFront.length < 1 && (imgUrl.cardFront = item.resourceResps.map(val => {
              return { url: val.path, type: 'image', id: val.id }
            }))
            item.useType === 3 && imgUrl.cardTail.length < 1 && (imgUrl.cardTail = item.resourceResps.map(val => {
              return { url:  val.path, type: 'image', id: val.id }
            }))
            item.useType === 4 && imgUrl.physicalExamination.length < 1 && (imgUrl.physicalExamination = item.resourceResps.map(val => {
              return { url: val.path, type: 'image', id: val.id }
            }))
            item.useType === 5 && imgUrl.nurse.length < 1 && (imgUrl.nurse = item.resourceResps.map(val => {
              return { url: val.path, type: 'image', id: val.id }
            }))
            item.useType === 6 && imgUrl.environment.length < 5 && (imgUrl.environment = item.resourceResps.map(val => {
              return { url:  val.path, type: 'image', id: val.id }
            }))
          })
          this.setData(imgUrl)
        }
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.editGetdata()
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  },
  // 身份证正面
  cardFrontAfterRead(event) {
    this.upload({ file: event.detail.file, useType: 2 })
  },
  cardFrontDelete() {
    this.setData({
      cardFront: []
    })
  },
  // 反面
  cardTailAfterRead(event) {
    this.upload({ file: event.detail.file, useType: 3 })
  },
  cardTailDelete() {
    this.setData({
      cardTail: []
    })
  },
  // 护理证
  nurseAfterRead(event) {
    this.upload({ file: event.detail.file, useType: 5 })
  },
  nurseDelete() {
    this.setData({
      nurse: []
    })
  },
  // 体检
  physicalExaminationAfterRead(event) {
    this.upload({ file: event.detail.file, useType: 4 })
  },
  physicalExaminationDelete() {
    this.setData({
      physicalExamination: []
    })
  },
  // 环境
  environmentAfterRead(event) {
    this.upload({ file: event.detail.file, useType: 6 })
  },
  environmentDelete(e) {
    let environmentList = JSON.parse(JSON.stringify(this.data.environment))
    environmentList.splice(e.detail.index, 1)
    this.setData({
      environment: environmentList
    })
  },
  // 上传
  upload({ file, useType }) {
    this.setData({
      loading: true
    })
    app.globalData.agriknow.uploadFile(file, useType)
      .then(res => {
        this.setData({
          loading: false
        })
        wx.showToast({
          title: '上传成功',
          success: () => {
            let file = { url: res.path, type: 'image', id: res.id }
            if (useType === 2) {
              file.name = '身份证正面'
              this.setData({
                cardFront: [file]
              })
            } else if (useType === 3) {
              file.name = '身份证反面面'
              this.setData({
                cardTail: [file]
              })
            } else if (useType === 4) {
              file.name = '健康证'
              this.setData({
                physicalExamination: [file]
              })
            } else if (useType === 5) {
              file.name = '护理师证'
              this.setData({
                nurse: [file]
              })
            } else if (useType === 6) {
              file.name = '环境照片'
              let list = JSON.parse(JSON.stringify(this.data.environment))
              if (this.data.environment.length < 5) {
                list.push(file)
              }
              this.setData({
                environment: list
              })
            }
          }
        })
      })
  }
})

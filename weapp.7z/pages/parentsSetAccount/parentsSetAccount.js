// pages/parentsSetAccount/parentsSetAccount.js
const app = getApp();
import myRegExp from '../../utils/myRegExp.js'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    avatar: '',
    avatarImg: '',
    name: '',
    gender: 1,
    phone: '',
    weChat: '',
    qqNum: '',
    babyList: [],
    sexList: [{
        text: '女',
        id: 1,
      },
      {
        text: '男',
        id: 2
      },
      {
        text: '保密',
        id: 3,
      },
    ],
    isWeChatFocus: false,
    isqqFocus: false,

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let {
      nickName,
      phone,
      avatar,
      gender,
      id
    } = app.globalData.userInfo()
    if (id) {
      this.setData({
        name: nickName,
        phone,
        avatarImg: avatar,
        avatar,
        gender
      })
      this.getParentsInfo(id)
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getChildList()
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},
  confirmSex(event) {
    this.setData({
      gender: parseInt(event.detail.value) + 1
    })
  },
  // 获取bady list数据 getParentChildList
  getChildList() {
    app.globalData.agriknow.getParentChildList()
      .then((res) => {
        this.setData({
          babyList: res.data.childList
        })
      })
  },
  // 新增宝宝资料
  addBadyData() {
    wx.navigateTo({
      url: '/pages/addBady/addBady'
    })
  },
  // 编辑孩子信息
  editChildInfo(event) {
    let {
      id
    } = event.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/addBady/addBady?id=${id}`,
    })
  },
  // 删除孩子信息
  deleteChildInfo(event) {
    let self = this
    let {
      childprofile,
      id
    } = event.currentTarget.dataset
    wx.showModal({
      content: `确定删除“${childprofile}”宝宝吗？`,
      success(res) {

        if (res.confirm) {
          app.globalData.agriknow.deleteChildInfo(id)
            .then((res) => {
              wx.showToast({
                title: res.msg,
                icon: 'none',
                success: () => {
                  self.getChildList()
                }
              })

            })
        }
      }
    })
  },
  // 保存家长用户信息
  saveBtn() {
    let {
      avatar,
      gender,
      name,
      qqNum,
      weChat
    } = this.data
    if (!gender) {
      wx.showToast({
        title: '请选择性别！',
        icon: 'none'
      });
      return
    }
    if (!name) {
      wx.showToast({
        title: '请输入姓名！',
        icon: 'none'
      });
      return
    }
    // 输入和没输入都要走
    if ((!weChat || weChat) && !myRegExp.isWechat(this.data.weChat)) {
      wx.showToast({
        title: !this.data.weChat ? '请输入的微信号' : '请输入正确格式的微信号',
        icon: 'none'
      })
      return
    }
    // 只有输入后才去校验，没输入就不管不是必填项
    if (qqNum && !myRegExp.isQQ(this.data.qqNum)) {
      wx.showToast({
        title: '请输入正确格式的QQ号',
        icon: 'none'
      })
      return
    }
    app.globalData.agriknow.updataParentsSetAccount({
        avatar,
        gender,
        name,
        qq: qqNum,
        wechat: weChat
      })
      .then(res => {
        wx.showToast({
          title: res.msg,
          icon: 'none',
          mask: true,
          duration: 1000,
          success: function () {
            setTimeout(() => {
              wx.switchTab({
                url: '/pages/mine/mine',
              })
            }, 1000)
          }
        })

      })
  },
  // 获取账号设置的数据
  getParentsInfo(uid) {
    app.globalData.agriknow.getParentsSetAccountInfo({
        uid
      })
      .then(res => {
        let {
          avatar,
          name,
          gender,
          phone,
          wechat,
          qq
        } = res.data
        this.setData({
          avatar,
          avatarImg: avatar,
          name,
          gender,
          phone,
          weChat: wechat,
          qqNum: qq,
        })
      })
  },
  // uploadFile  上传接口
  uploadFile(event) {
    app.globalData.agriknow.uploadFile(event.detail.file, 1)
      .then(res => {
        wx.showToast({
          title: '更换成功',
          success: () => {
            this.setData({
              avatar: res.path,
              avatarImg: res.path,
            })
          }
        })
      })
  },
  // 校验
  checkQQ() {
    if (!myRegExp.isQQ(this.data.qqNum)) {
      wx.showToast({
        title: !this.data.qqNum ? '请输入QQ号码' : '请输入正确格式的QQ号码',
        icon: 'none'
      })
    }
  },
  checkWechat() {
    if (!myRegExp.isWechat(this.data.weChat)) {
      wx.showToast({
        title: !this.data.weChat ? '请输入微信号' : '请输入正确格式的微信号',
        icon: 'none'
      })
    }
  },
  weChatFocus() {
    this.setData({
      isWeChatFocus: true
    })
  },
  qqFocus() {
    this.setData({
      isqqFocus: true
    })
  },
})
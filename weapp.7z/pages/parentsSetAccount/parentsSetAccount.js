// pages/parentsSetAccount/parentsSetAccount.js
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    navHeight: 0,
    avatar: '',
    name: '',
    gender: 1,
    phone: '',
    weChat: '',
    qqNum: '',
    babyList: [],
    sexList: [{
      text: '女',
      id: 1,
    }, {
      text: '男',
      id: 2
    },],
    isSelectSex: false,

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let { nickName, phone, avatar, gender } = app.globalData.userInfo
    this.setData({
      navHeight: app.globalData.Wechat.navHeight,
      name: nickName,
      phone,
      avatar,
      gender
    })
    this.getChildList()
    this.getParentsInfo(app.globalData.userInfo.id)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  },

  selectSex() {
    this.setData({
      isSelectSex: !this.data.isSelectSex
    })
  },
  sexPopupClose() {
    this.setData({
      isSelectSex: false
    })
  },
  confirmSex(event) {
    this.setData({
      gender: event.detail.value.id
    })
    this.sexPopupClose()
  },
  // 获取bady list数据 getParentChildList
  getChildList() {
    app.globalData.agriknow.getParentChildList()
      .then((res) => {
        this.setData({
          babyList: res.data.childList
        })
      })
  },
  // 新增宝宝资料
  addBadyData() {
    wx.navigateTo({
      url: '/pages/addBady/addBady'
    })
  },
  // 编辑孩子信息
  editChildInfo(event) {
    let { id } = event.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/addBady/addBady?id=${id}`,
    })
  },
  // 删除孩子信息
  deleteChildInfo(event) {
    let { birthdate,
      birthflag,
      gender,
      id } = event.currentTarget.dataset
    app.globalData.agriknow.deleteChildInfo({
      birthDate: birthdate,
      birthFlag: birthflag,
      gender,
      id
    })
      .then((res) => {
        wx.showToast({
          title: res.msg,
          icon: 'none',
        })
        this.getChildList()
      })
  },
  // 保存家长用户信息
  saveBtn() {
    let { avatar, gender, name, qqNum, weChat } = this.data
    app.globalData.agriknow.updataParentsSetAccount({
      avatar, gender, name, qq: qqNum, wechat: weChat
    })
      .then(res => {
        wx.showToast({
          title: res.msg,
          icon: 'none',
          duration: 2000,
          success: function () {
            setTimeout(() => {
              wx.switchTab({
                url: '/pages/mine/mine',
              })
            }, 2000)
          }
        })

      })
  },
  // 获取账号设置的数据
  getParentsInfo(uid) {
    app.globalData.agriknow.getParentsSetAccountInfo({ uid })
      .then(res => {
        let { avatar, name, gender, phone, wechat, qq } = res.data
        this.setData({
          avatar,
          name,
          gender,
          phone,
          weChat: wechat,
          qqNum: qq,
        })
      })
  },
  // uploadFile  上传接口
  uploadFile(event) {
    app.globalData.agriknow.uploadFile(event.detail.file,1)
      .then(res => {
        console.log(res)
        debugger
      })
  }
})
// pages/amah/amah.js 
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    height: 0,
    userCenterInfo: {},
    messageConcatCount: 0,
  },

  // 联系客服
  relationService() {
    wx.navigateTo({
      url: '/pages/chatPage/chatPage',
    })
  },
  // 保姆收款
  collection() {
    wx.navigateTo({
      url: '/pages/collectionQRcode/collectionQRcode'
    })
  },
  // 获取剩余短信条数
  getMessageCount(loading = true) {
    app.globalData.agriknow.getMessageCount({type:1},loading)
      .then(res => {
        this.setData({
          messageConcatCount: res.data.remainCount, // 短信剩余次数
        })
      })
  },
  // 刷新
  refreshEvent() {
    app.getCenterInfo(false)
      .then((res) => {
        let data = res
        data.nurseInfo && (data.nurseInfo.nurseScore = data.nurseInfo.nurseScore.toFixed(1))
        this.setData({
          userCenterInfo: data
        })
      })
  },
  // test() {
  //   wx.requestSubscribeMessage({
  //     tmplIds: ['ur01YrvpSbyxCYelKRGLbsmhxnaTZoJIlo7mnTWRuyE'],
  //     success(res) {
  //       console.log(res)
  //     }
  //   })
  // },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      height: app.globalData.Wechat.navHeight
    })
    app.getCenterInfo(false)
      .then((res) => {
        let data = res
        data.nurseInfo && (data.nurseInfo.nurseScore = data.nurseInfo.nurseScore.toFixed(1))
        this.setData({
          userCenterInfo: data
        })
      })
    this.getMessageCount(false)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getMessageCount(false)
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 4
      })
    }

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
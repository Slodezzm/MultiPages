// pages/amah/amah.js 
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navStyle: {
      height: 0,
    },
    userInfo: {
      nickName: "",
      vip: 0,
      role: 0,
    }
  },
  // 保姆收款
  collection() {
    wx.navigateTo({
      url: '/pages/collectionQRcode/collectionQRcode'
    })
  },
  // 去卡券
  goConpou() {
    wx.navigateTo({
      url: '/pages/coupon/coupon'
    })
  },
  // 会员套餐
  goSetMeal() {
    wx.navigateTo({
      url: '/pages/setMeal/setMeal'
    })
  },
  // 短信发送
  goPhoneLog() {
    wx.navigateTo({
      url: '/pages/phoneLog/phoneLog'
    })
  },
  // 我的招聘
  gomyRecruit() {
    wx.navigateTo({
      url: '/pages/myRecruit/myRecruit'
    })
  },
  // 账号设置
  goSetAccount() {
    // 跳转保姆账号设置
    if (this.data.userInfo.role === 1) {

    } else if (this.data.userInfo.role === 2) { // 跳转家长账号设置
      wx.navigateTo({
        url: '/pages/parentsSetAccount/parentsSetAccount'
      })
    }

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navStyle: { height: app.globalData.Wechat.navHeight },
      userInfo: app.globalData.userInfo
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getTabBar().setData({
      selected: 4
    })
    let getTabBar = this.getTabBar()
    console.log(getTabBar)

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
// pages/collectionQRcode/collectionQRcode.js
const app = getApp();
import drawQrcode from '../../utils/weapp.qrcode.esm.js'
import {
  formatDay
} from '../../utils/util.js'
import {
  h5Url
} from "../../config";
Page({
  /**
   * 页面的初始数据
   */
  data: {
    recordList: [],
    pageNo: 1,
    pageSize: 10,
    next: 0, // 是否有下一页
  },
  goDescription() {
    wx.navigateTo({
      url: '/pages/couponDescription/couponDescription',
    })
  },
  // 托育券收款记录列表
  descriptionList(data) {
    app.globalData.agriknow.getCouponExchangeList(data)
      .then(res => {
        if (res.code === 'success') {
          let list = res.data.records.map(item => {
            item.createTime = formatDay(item.createTime, true)
            return item
          })
          if (data.pageNum === 1) {
            this.setData({
              next: res.data.next,
              recordList: list,
            })
          } else {
            let newList = JSON.parse(JSON.stringify(this.data.recordList))
            this.setData({
              recordList: [...newList, ...list],
              next: res.data.next
            })
          }
        }
      })
  },
  // 打款失败原因弹框
  viewReason(e) {
    wx.showModal({
      title: '失败原因',
      content: e.currentTarget.dataset.desc || ''
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.descriptionList({
      couponType: 0,
      pageNo: this.data.pageNo,
      pageSize: this.data.pageSize,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 二维码携带的下载地址路径和参数
    // /pages/availableCoupon/availableCoupon 家长跳转的页面
    // https://c08-dev-admin.kf66.live/download?type=1&uid=2
console.log(app.globalData.userInfo().nickName , app.globalData.userInfo().name)
    drawQrcode({
      width: 146,
      height: 146,
      canvasId: 'myQrcode',
      text: `${h5Url}download?type=1&uid=${app.globalData.userInfo().id}&name=${app.globalData.userInfo().nickName}`,
      // image: { // 设置 二维码中间图片
      //   imageResource: '../../images/icon.png',
      //   dx: 70,
      //   dy: 70,
      //   dWidth: 60,
      //   dHeight: 60
      // }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.next) {
      let newPagenum = this.data.pageNo
      this.setData({
        pageNo: newPagenum++
      })
      this.descriptionList({
        couponType: 0,
        pageNo: newPagenum,
        pageSize: this.data.pageSize,
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
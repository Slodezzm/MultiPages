const app = getApp()

Page({
  data: {
    // navHeight: 0,
    // offsetTop: false,
    bgColor: false,
    topHeight: 0,
    theTimeList: [], // 托育时间的基础数据
    timeList: [], // 托育时间段
    imageView: [],
    imageViewShow: false,
    viewCurrent: 0,
    isVip: true,
    showReviewBox: false,
    id: null,
    amahInfos: null,
    wageType: ["", "正常日每小时", "正常日每天", "假日每小时", "假日每天", "正常日每月"],
    userInfo: null,
    myInfo: null,
    reviewList: [], // 评论列表,
    loading: true,
    pageNum: 1,
    hasNextPage: false,
    myReview: {
      score: 0,
      likeDesc: "",
      betterDesc: "",
      uid: null
    },
    isMyself: false,
    chatFlag: false,
    offsetTop: 0,
    tabIndex: 0
  },
  onLoad(options) {
    this.setData({
      offsetTop: app.globalData.Wechat.navHeight,
      id: options.id,
      navHeight: app.globalData.Wechat.navHeight,
      myInfo: wx.getStorageSync('userInfo') ? JSON.parse(wx.getStorageSync('userInfo')) : {
        role: -1,
        id: -1
      }
    })
    if (this.data.myInfo.id === -1) {
      return this.toLogin("暂未登录，无法访问")
    }
    this.setData({
      isMyself: this.data.myInfo.id == this.data.id
    })
    this.getPointTimeList()
    this.getUserInfo()
  },
  onShow() {
    this.setData({
      chatFlag: this.data.myInfo.role === 2
    })
  },
  onReady() {
    // wx.createSelectorQuery().select('#topHeight').boundingClientRect((rect) => {
    //   console.log(rect)
    //   this.setData({
    //     topHeight: rect.height
    //   })
    // }).exec()
  },
  onPageScroll(e) { // 页面滚动
    // if (e.scrollTop >= this.data.topHeight) {
    //   if (this.data.offsetTop) return
    //   this.setData({
    //     offsetTop: true,
    //     bgColor:true
    //   })
    // } else {
    //   if (!this.data.offsetTop) return
    //   this.setData({
    //     offsetTop: false,
    //     bgColor:false
    //   })
    // }
  },
  // 获取时间段的基础数据
  getPointTimeList() {
    app.globalData.agriknow.getTimePointList(false)
      .then(res => {
        let theTimeList = res.data.serviceTime
        this.setData({
          theTimeList: theTimeList
        })
      })
  },
  showImageView(e) { // 图片浏览
    wx.previewImage({
      current: this.data.imageView[e.currentTarget.dataset.index],
      urls: this.data.imageView
    })
  },
  openReviewBox() { // 打开评价框
    if (this.data.isMyself) {
      return wx.showToast({
        title: '无法对自己进行评论哦！',
        icon: "none",
        duration: 2000
      })
    }
    this.setData({
      showReviewBox: true
    })
  },
  closeReviewBox() { // 关闭评价框
    this.setData({
      showReviewBox: false
    })
    wx.showToast({
      title: '已取消评价',
      icon: "none",
      duration: 2000
    })
  },
  submitReview() { // 提交评价
    if (this.data.isMyself) {
      return wx.showToast({
        title: '无法对自己进行评论哦！',
        icon: "none",
        duration: 2000
      })
    }
    if (this.data.myInfo.id === -1) {
      this.toLogin("暂未登录，无法评价")
      return
    } else {
      let myReview = {
        ...this.data.myReview
      }
      myReview.uid = this.data.userInfo.id
      if (myReview.score === 0) return wx.showToast({
        title: '请提交评分',
        icon: "none",
        duration: 2000
      })
      if (myReview.likeDesc === "" && myReview.betterDesc === "") return wx.showToast({
        title: '喜欢和改进至少需要填写一项，以方便我们做出改进！',
        icon: "none",
        duration: 3000
      })
      app.globalData.agriknow.reviewToAmah(myReview).then(res => {
        this.setData({
          pageNum: 1
        })
        this.getAmahReviewList(true)
        if (res.code === "success") {
          wx.showToast({
            title: '评价成功',
            icon: "success",
            duration: 2000
          })
        } else {
          wx.showToast({
            title: res.msg,
            icon: "error",
            duration: 2000
          })
        }
      })
    }
  },
  changeMark(e) { // 评价-评分
    let myReview = {
      ...this.data.myReview
    }
    myReview.score = e.detail
    this.setData({
      myReview: myReview
    })
  },
  changeLike(e) { // 评价-喜欢
    let myReview = {
      ...this.data.myReview
    }
    myReview.likeDesc = e.detail
    this.setData({
      myReview: myReview
    })
  },
  changeBetter(e) { // 评价-改进
    let myReview = {
      ...this.data.myReview
    }
    myReview.betterDesc = e.detail
    this.setData({
      myReview: myReview
    })
  },
  getAmahInfos() { // 获取保姆信息
    app.globalData.agriknow.getNurseInfo({
      id: this.data.id
    }).then(res => {
      this.getAmahReviewList(true)
      if (res.code === "success") {
        let historyImg = [...res.data.historyImg]
        let data = res.data
        data.nurseScore = data.nurseScore.toFixed(1)
        this.setData({
          amahInfos: data,
          imageView: historyImg.map(a => {
            return a.fileUrl
          }),
          timeList: data.serviceTimes
        })
      }
    })
  },
  getUserInfo() { // 获取用户基础信息
    app.globalData.agriknow.getParentsSetAccountInfo({
      uid: this.data.id
    }, true).then(res => {
      if (res.code === "success") {
        this.getAmahInfos()
        this.setData({
          userInfo: res.data
        })
      } else {
        wx.showToast({
          title: '获取保姆信息失败，返回后重试！',
          icon: 'error',
          duration: 2000
        })
      }
    })
  },
  toLogin(text) { // 未登录提示登录
    wx.showModal({
      title: text,
      content: '是否跳转到登录页?',
      success(res) {
        if (res.confirm) {
          wx.redirectTo({
            url: "/pages/login/login"
          })
        } else if (res.cancel) {
          wx.showToast({
            title: '请先登录哦！',
            icon: 'none'
          })
        }
      }
    })
  },
  attention() { // 关注
    if (this.data.isMyself) return wx.showToast({
      title: '无法关注自己',
      icon: 'none'
    })
    if (this.data.myInfo.id === -1) {
      this.toLogin("暂未登录，无法关注")
      return false
    }
    if (this.data.myInfo.role === 1) {
      wx.showToast({
        title: '角色相同，无法关注',
        icon: 'none'
      })
      return false
    }
    app.globalData.agriknow.attention({
      followerUid: this.data.id,
      subscribeFlag: ([1, 0][this.data.userInfo.subscribeFlag])
    }).then(res => {
      if (res.code === "success") {
        wx.showToast({
          title: ["关注成功", "已取消关注"][this.data.userInfo.subscribeFlag],
          icon: "success",
          duration: 1000
        })
        let userInfo = {
          ...this.data.userInfo
        }
        userInfo.subscribeFlag = [1, 0][userInfo.subscribeFlag]
        this.setData({
          userInfo: userInfo
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: "error",
          duration: 1000
        })
      }
    })
  },
  getAmahReviewList(isFirst = false) { // 获取评论列表
    this.setData({
      loading: true
    })
    app.globalData.agriknow.getAmahReviewList({
      targetUid: this.data.id,
      pageSize: 10,
      pageNum: this.data.pageNum
    }, false).then(res => {
      if (res.code === "success") {
        this.setData({
          reviewList: isFirst ? [...res.data.records] : [...this.data.reviewList, ...res.data.records],
          hasNextPage: res.data.next === 1,
          loading: false
        })
      }
    })
  },
  onReachBottom() { //触底加载
    if (this.data.loading || !this.data.hasNextPage || this.data.tabIndex != 4) return
    this.setData({
      pageNum: this.data.pageNum + 1
    })
    this.getAmahReviewList()
  },
  toggleMyPage() { // 打开、关闭主页
    let _this = this
    if (this.data.userInfo.homeSwitch) {
      wx.showModal({
        title: '提示',
        content: '是否关闭主页？',
        success(res) {
          if (res.confirm) {
            _this.closeOrOpenPage()
          } else if (res.cancel) {
            wx.showToast({
              title: '已取消关闭主页！',
              icon: 'none'
            })
          }
        }
      })
    } else {
      this.closeOrOpenPage()
    }
  },
  closeOrOpenPage() { // 打开、关闭主页接口
    app.globalData.agriknow.toggleMyPage({
      homeSwitch: [1, 0][this.data.userInfo.homeSwitch]
    }).then(res => {
      if (res.code === "success") {
        wx.showToast({
          title: ["主页已开启", "主页已关闭"][this.data.userInfo.homeSwitch],
          icon: 'success',
          duration: 2000
        })
        let userInfo = {
          ...this.data.userInfo
        }
        userInfo.homeSwitch = [1, 0][userInfo.homeSwitch]
        this.setData({
          userInfo: userInfo
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: 'error'
        })
      }
    })
  },
  connectionAmah() { // 联系保姆
    app.globalData.agriknow.getMessageCount({
        type: 2
      })
      .then(res => {
        if (res.code === 'success') {
          if (res.data.remainCount) {
            wx.navigateTo({
              url: `/pages/chatPage/chatPage?huanxinUserName=${this.data.userInfo.huanxinUserName}&name=${this.data.userInfo.nickName}`,
            })
          } else {
            wx.showModal({
              title: '提示',
              content: '站内信消息已用完，立即前往充值！',
              confirmText: '立即充值',
              confirmColor: '#FF6075FF',
              success(res) {
                if (res.confirm) {
                  wx.navigateTo({
                    url: "/pages/setMeal/setMeal"
                  })
                }
              }
            })
          }
        }
      })
  },
  changeTab(e) {
    this.setData({
      tabIndex: e.detail.index
    })
  }
})
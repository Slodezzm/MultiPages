const app = getApp()

Page({
  data: {
    scrollTop: 0,
    offsetTop: 0,
    weeks: ["日","一","二","三","四","五","六"],
    times: ["6AM","9AM","12AM","3PM","6PM","9PM","12PM"],
    frame: [
      [true,true,false,false,true,true,false],
      [true,true,false,false,true,true,false],
      [true,true,false,false,true,true,false],
      [true,true,true,false,true,true,false],
      [true,true,false,false,true,true,false],
      [true,true,false,false,true,true,false],
      [true,true,false,false,true,true,false]
    ],
    imageView: [
      "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201707%2F11%2F20170711171209_Aitfn.jpeg&refer=http%3A%2F%2Fb-ssl.duitang.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620550982&t=9f745751dc330691259b7b4d726b3f07",
      "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fc-ssl.duitang.com%2Fuploads%2Fitem%2F201802%2F22%2F20180222125638_wipph.jpeg&refer=http%3A%2F%2Fc-ssl.duitang.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620550982&t=67fb4de0920e180d37c300fee8b61ab2",
      "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201703%2F02%2F20170302204209_NVFnR.jpeg&refer=http%3A%2F%2Fb-ssl.duitang.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1620550982&t=5f1f4c4b6c7262dd68a8d8e333fd26ec",
      "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3137640453,1905189871&fm=26&gp=0.jpg"
    ],
    imageViewShow: false,
    viewCurrent: 0,
    isVip: true,
    showReviewBox: false,
  },
  onLoad() {
    this.setData({
      offsetTop: app.globalData.Wechat.navHeight
    })
  },
  onPageScroll(e) {// 页面滚动
    this.setData({
      scrollTop: e.scrollTop
    })
  },
  showImageView(e) {// 图片浏览
    wx.previewImage({
      current: this.data.imageView[e.currentTarget.dataset.index],
      urls: this.data.imageView
    })
  },
  openReviewBox() {// 打开评价框
    this.setData({
      showReviewBox: true
    })
  },
  closeReviewBox() {// 关闭评价框
    this.setData({
      showReviewBox: false
    })
  },
  changeMark(e) {
    console.log(e)
  }
})
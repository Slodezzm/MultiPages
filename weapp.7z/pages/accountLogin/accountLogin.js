// pages/accountLogin/accountLogin.js
const app = getApp()
import {
  rulePhone,
  rulePassword
} from '../../utils/util'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    navHeight: 0,
    phone: '15555555555',
    password: 'qq123456',
    protocol: true, //是否阅读协议
    isShow: false
  },
  login() {
    if (!this.data.protocol) {
      wx.showToast({
        title: '请勾选协议',
        icon: 'none',
      })
      return
    }
    if (!rulePhone(this.data.phone)) {
      wx.showToast({
        title: '请输入有效的电话号码！',
        icon: 'none',
      })
      return
    }
    if (!rulePassword(this.data.password)) {
      wx.showToast({
        title: '请输入6-15位并且含有字母的组合！',
        icon: 'none',
      })
      return
    }
    app.globalData.agriknow.login({
        loginType: 2,
        password: this.data.password,
        phone: this.data.phone,
        verifyType: 1
      })
      .then((result) => {
        app.loginHandle(result)
      })
      .catch(err => {
        wx.showToast({
          title: err.data.msg,
          icon: 'none'
        })
      })
  },
  // 失去焦点 校验
  check(e) {
    if (e.currentTarget.dataset.input === 'phone') {
      if (!rulePhone(this.data.phone)) {
        wx.showToast({
          title: '请输入有效的电话号码！',
          icon: 'none',
        })
        return
      }
    } else if (e.currentTarget.dataset.input === 'pwd') {
      if (!rulePassword(this.data.password)) {
        wx.showToast({
          title: '请输入6-15位并且含有字母的组合！',
          icon: 'none',
        })
        return
      }
    }
  },
  changeProtocol() {
    this.setData({
      protocol: !this.data.protocol
    })
  },
  // 查看密码
  viewPassword() {
    this.setData({
      isShow: !this.data.isShow
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navHeight: app.globalData.Wechat.navHeight,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
// pages/amah/amah.js
const app = getApp();
import {
  analysisUrlParam
} from "../../utils/util";
Page({
  /**
   * 页面的初始数据
   */
  data: {
    loading: false,
    couponList: [],
    next: 0, // 是否有下一页
    pageSize: 10,
    pageNo: 1,
    couponType: 1, // 有效优惠券
    show: false
  },
  getCouponList(data) {
    this.setData({
      loading: true
    })
    app.globalData.agriknow.getCouponList(data)
      .then(res => {
        if (res.code === 'success') {
          this.setData({
            loading: false,
            show: false
          })
          if (data.pageNum === 1) {
            this.setData({
              next: res.data.next,
              couponList: res.data.records,
            })
          } else {
            let newList = JSON.parse(JSON.stringify(this.data.couponList))
            this.setData({
              recordList: [...newList, ...res.data.records],
              next: res.data.next
            })
          }
        }
      })
  },
  goOutCoupon() {
    wx.navigateTo({
      url: '/pages/outCoupon/outCoupon',
    })
  },
  // 使用卡券 
  useCoupon(data) {
    let {
      price,
      status
    } = data.detail
    if (price && (status === 1 || status === 4)) {
      // 允许从相机和相册扫码
      wx.scanCode({
        success(res) {
          if (res.errMsg === 'scanCode:ok') {
            let params = analysisUrlParam(res.result)
            if (params.uid) {
              wx.navigateTo({
                url: `/pages/availableCoupon/availableCoupon?uid=${params.uid}&name=${params.name}`,
              })
            } else {
              wx.showToast({
                title: '该二维码不可用,请选择正确的二维码进行扫描',
                iconL: 'none'
              })
            }
          }
        }
      })
    } else if (!price && (status === 1 || status === 4)) {
      wx.navigateTo({
        url: '/pages/setMeal/setMeal?tab=1',
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getCouponList({
      couponType: this.data.couponType,
      pageNo: this.data.pageNo,
      pageSize: this.data.pageSize
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.next) {
      this.setData({
        show: true
      })

      this.getCouponList({
        couponType: this.data.couponType,
        pageNo: ++this.data.pageNo,
        pageSize: this.data.pageSize
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
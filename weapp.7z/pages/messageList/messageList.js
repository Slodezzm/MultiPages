const app = getApp();
let disp = require("../../utils/broadcast");

Page({
  /**
   * 页面的初始数据
   */
  data: {
    height: 0,
    chatList: [],
    huanxinUserName: null,
    scroll: {
      pagination: {
        page: 1
      },
      refresh: {
        type: 'default',
        style: 'black',
        background: {
          color: "#f2f2f2"
        },
        shake: true
      },
    },
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let self = this
    this.setData({
      huanxinUserName: JSON.parse(wx.getStorageSync('huanxin_info')).username,
      height: (app.globalData.Wechat.clientHeight - app.globalData.Wechat.navHeight) - (49 + 18)
    })
    //收到普通消息
    disp.on('app.onTextMessage', function (message) {
      self.getList()
    })
    disp.on('app.onAudioMessage', function (message) {
      self.getList()
    })
    // self.getList(true)
    // 客户提示
    this.getService({
        type: 'service_time_desc'
      })
      .then(res => {
        this.setData({
          serviceHint: res.data[0].dictLabel
        })
      })
  },
  getList(bool) {
    // 获取聊天列表
    app.getChatList(bool).then(() => {
      this.setData({
        chatList: app.globalData.chatList
      })
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 3
      })
    }
    this.getMessageCount()
      .then(res => {
        if (!res.data.remainCount) {
          wx.showModal({
            title: '提示',
            content: '站内信消息已用完，立即前往充值！',
            confirmText: '立即充值',
            confirmColor: '#FF6075FF',
            success(res) {
              if (res.confirm) {
                wx.navigateTo({
                  url: "/pages/setMeal/setMeal"
                })
              } else if (res.cancel) {
                wx.switchTab({
                  url: '/pages/home/home',
                })
              }
            }
          })
        }
      })
    // 页面展示就要去清空消息
    disp.fire('app.tabBar.newMessageNum', 0)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},
  // 聊天详情
  toChat(data) {
    let clickData = this.data.chatList[data.detail]
    let hxname = clickData.meta.payload.from === this.data.huanxinUserName ? clickData.meta.payload.to : clickData.meta.payload.from
    wx.navigateTo({
      url: `/pages/chatPage/chatPage?&huanxinUserName=${ hxname }&name=${clickData.meta.payload.ext.name}`
    })
  },
  // 获取客服默认展示语
  getService(data) {
    return new Promise((resovle, reject) => {
      app.globalData.agriknow.getServiceHint(data, false)
        .then(res => {
          resovle(res)
        }).catch(err => {
          reject(err)
        })
    })
  },
  // 刷新
  refresh() {
    this.getList()
  },
  // 
  getMessageCount() {
    return new Promise((resovle, reject) => {
      app.globalData.agriknow.getMessageCount({type:2})
        .then(res => {
          if (res.code === 'success') {
            resovle(res)
          }
        })
        .catch(err => {
          reject(err)
        })
    })

  }
})
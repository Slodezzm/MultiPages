// pages/addBady/addBady.js
const app = getApp();

Page({
  /**
   * 页面的初始数据
   */
  data: {
    navHeight: 0,
    selectId: 0,
    active: 0,
    tabData: [{
      title: '待产',
      value: 0
    }, {
      title: '已出生',
      value: 1
    }],
    isDate: false,
    currentDate: new Date().getTime(),
    minDate: new Date(2000 - 5 - 7).getTime(),
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      if (type === 'day') {
        return `${value}日`;
      }
      return value;
    },
    birth: {
      year: new Date().getFullYear() + '年',
      month: new Date().getMonth() + 1 + '月',
      day: new Date().getDay() + '日',
    },
    birthDate: `${new Date().getFullYear()}-${new Date().getMonth() + 1}-${new Date().getDay()}`,
    id: null
  },
  // tab 栏切换
  tabChange(event) {
    this.setData({
      active: event.detail.index
    })
  },
  // 选择 性别
  selectID(event) {
    this.setData({
      selectId: event.currentTarget.dataset.id
    })
  },
  // 选择出生日期
  selectBirth(event) {
    let { id } = event.currentTarget.dataset
    this.setData({
      isDate: true
    })
  },
  // 关闭选择日期框
  selectBirthClose() {
    this.setData({
      isDate: false
    })
  },
  // 确定选择日期
  confirmBirth(event) {
    let time = new Date(event.detail)
    this.setData({
      birth: {
        year: time.getFullYear() + '年',
        month: time.getMonth() + 1 >= 10 ? (time.getMonth() + 1) + '月' : `0${time.getMonth() + 1}` + '月',
        day: time.getDate() >= 10 ? time.getDate() + '日' : `0${time.getDate()}` + '日',
      },
      birthDate: `${time.getFullYear()}-${(time.getMonth() + 1) >= 10 ? (time.getMonth() + 1) : `0${time.getMonth() + 1}`}-${time.getDate() >= 10 ? time.getDate() : `0${time.getDate()}`}`,
      isDate: false
    })
  },
  // 新增孩子资料
  finish() {
    app.globalData.agriknow.addAndUpdateChildInfo({
      birthDate: this.data.birthDate,
      birthFlag: this.data.active,
      gender: this.data.active === 0 || this.data.selectId === 0 ? 3 : this.data.selectId,
      id: this.data.id ? this.data.id : 0
    })
      .then(res => {
        wx.showToast({
          title: res.msg,
          icon: 'none',
        })
        wx.navigateBack({
          delta: 1
        })
        // wx.navigateTo({
        //   url: '/pages/parentsSetAccount/parentsSetAccount'
        // });
      })
  },
  getChildDetailInfo(id) {
    app.globalData.agriknow.getChildInfo(id)
      .then(res => {
        let time = res.data.birthDate.split('-')
        this.setData({
          birth: {
            year: time[0] + '年',
            month: time[1] + '月',
            day: time[2] + '日',
          },
          birthDate: res.data.birthDate,
          active: res.data.birthFlag,
          selectId: res.data.gender === 3 ? 0 : res.data.gender,
          id
        })
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let { id } = options
    this.setData({ navHeight: app.globalData.Wechat.navHeight })
   id &&  this.getChildDetailInfo(id)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
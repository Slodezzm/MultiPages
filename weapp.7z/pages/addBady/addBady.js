// pages/addBady/addBady.js
const app = getApp();
import {
  formatDay
} from '../../utils/util'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    selectId: 0,
    active: 0,
    tabData: [{
      title: '待产',
      value: 0
    }, {
      title: '已出生',
      value: 1
    }],
    isDate: false,
    currentDate: formatDay(Date.now(), true),
    maxDate: formatDay(new Date(Date.now() + 10 * 30 * 24 * 60 * 60 * 1000), true),
    birth: {
      year: new Date().getFullYear() + '年',
      month: new Date().getMonth() + 1 + '月',
      day: new Date().getDate() + '日',
    },
    birthDate: formatDay(Date.now(), true),
    id: null
  },
  // tab 栏切换
  tabChange(event) {
    // 待出生最多选择未来10个月 已出生只显示现在当前和过去
    event.detail.index === 0 && this.setData({
      maxDate: formatDay(new Date(Date.now() + 10 * 30 * 24 * 60 * 60 * 1000), true)
    })
    event.detail.index === 1 && this.setData({
      maxDate: formatDay(new Date(Date.now()), true)
    })
    this.setData({
      active: event.detail.index,
      birth: {
        year: new Date().getFullYear() + '年',
        month: new Date().getMonth() + 1 + '月',
        day: new Date().getDate() + '日',
      }
    })
  },
  // 选择 性别
  selectID(event) {
    this.setData({
      selectId: event.currentTarget.dataset.id
    })
  },
  // 关闭选择日期框
  selectBirthClose() {
    this.setData({
      isDate: false
    })
  },
  // 确定选择日期
  confirmBirth(event) {
    let time = event.detail.value.split('-')
    this.setData({
      birth: {
        year: time[0] + '年',
        month: time[1] + '月',
        day: time[2] + '日',
      },
      birthDate: event.detail.value,
      isDate: false
    })
  },
  // 新增孩子资料
  finish() {
    app.globalData.agriknow.addAndUpdateChildInfo({
        birthDate: this.data.birthDate,
        birthFlag: this.data.active,
        gender: this.data.active === 0 || this.data.selectId === 0 ? 3 : this.data.selectId,
        id: this.data.id ? this.data.id : 0
      })
      .then(res => {
        wx.showToast({
          title: '添加成功',
          icon: 'none',
          success: function () {
            wx.navigateBack({
              delta: 1
            })
          }
        })
      })
  },
  getChildDetailInfo(id) {
    app.globalData.agriknow.getChildInfo(id)
      .then(res => {
        let time = res.data.birthDate.split('-')
        this.setData({
          birth: {
            year: time[0] + '年',
            month: time[1] + '月',
            day: time[2] + '日',
          },
          birthDate: res.data.birthDate,
          active: res.data.birthFlag,
          selectId: res.data.gender === 3 ? 0 : res.data.gender,
          id
        })
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let {
      id
    } = options
    id && this.getChildDetailInfo(id)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
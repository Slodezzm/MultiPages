// pages/nannySetAccount/nannySetAccount.js
const app = getApp();
const list = {
  jobYear: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
  jobMonth: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navHeight: 0,
    nannyData: {
      name: '你保姆',
      sex: 1,
      jobYear: '3年6个月',
      birthDate: '2019/4/6',
      introduceSelf: '好好最好',
      phone: '1234546576',
      weChat: 'fsgsdfassfd',
      qqNum: '45467557845',
      idCardNum: '580878576547656456',
      openAccountBank: '尚未绑定',
      createBankAccount: {
        createBank: '',
        isCreateBank: false
      },
      bankNum: {
        bankNumber: '',
        isBank: false
      },
    },
    isSelectJobYear: false,
    isSelectBirth: false,
    defaultdate: [],
    minDate: new Date(2010, 0, 1).getTime(),
    maxDate: new Date().getTime(),
    sexList: [
      {
        text: '女',
        id: 1,
      },
      {
        text: '男',
        id: 2
      },

    ],
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      if (type === 'day') {
        return `${value}日`;
      }
      return value;
    },
    currentDate: new Date().getTime(),
    jobYearList: [
      {
        values: list.jobYear.map(item => item + '年'),
        className: 'column1',
      },
      {
        values: list.jobMonth.map(item => item + '月'),
        className: 'column2',
      }
    ]

  },
  // 选择性别
  selectSex() {
    this.setData({
      isSelectSex: !this.data.isSelectSex
    })
  },
  sexPopupClose() {
    this.setData({
      isSelectSex: false
    })
  },
  confirmSex(event) {
    console.log(event.detail.value.text)
    this.setData({
      'accountData.sex': event.detail.value.id
    })
    this.sexPopupClose()
  },
  // 选择 从业年限
  selectJobYear() {
    this.setData({
      isSelectJobYear: !this.data.isSelectJobYear
    })
  },
  onCloseJobYear() {
    this.setData({
      isSelectJobYear: false
    })
  },
  onConfirmJobYear(event) {
    this.setData({
      'nannyData.jobYear': event.detail.value.join(''),
      isSelectJobYear: false
    })
  },
  // 选择出生日期
  selectBirth() {
    this.setData({
      isSelectBirth: true
    })
  },
  birthPopupClose() {
    this.setData({
      isSelectBirth: false
    })
  },
  // 开户银行
  selectCreateBank() {
    this.setData({
      'nannyData.createBankAccount.isCreateBank': true
    })
  },
  // 修改银行卡
  selectBankNum() {
    this.setData({
      'nannyData.bankNum.isBank': true
    })
  },
  // 下一步
  nextBtn() {
    wx.navigateTo({
      url:'/pages/nannyUpload/nannyUpload'
    })
   },
  // 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navHeight: app.globalData.Wechat.navHeight
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
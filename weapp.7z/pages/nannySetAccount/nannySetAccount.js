// pages/nannySetAccount/nannySetAccount.js
const app = getApp();
const {
  formatDay
} = require('../../utils/util.js')
import myRegExp from '../../utils/myRegExp.js'
const list = {
  jobYear: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
  jobMonth: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
}
let jobList = [list.jobYear.map(item => {
  return item + '年'
}), list.jobMonth.map(item => {
  return item + '月'
})]
Page({
  /**
   * 页面的初始数据
   */
  data: {
    avatar: '',
    name: '',
    gender: 1,
    jobYear: '',
    jobYears: [],
    birthDate: '',
    introduceSelf: '',
    phone: '',
    weChat: '',
    qqNum: '',
    idCardNum: '',
    openAccountBank: '尚未绑定',
    createBank: '',
    isCreateBank: false,
    bankNumber: '',
    isBank: false,
    defaultdate: [],
    // minDate: formatDay(new Date(1970, 0, 1).getTime()),
    maxDate: formatDay(Date.now()),
    sexList: [{
        text: '女',
        id: 1,
      },
      {
        text: '男',
        id: 2
      },
      {
        text: '保密',
        id: 3,
      },
    ],
    jobYearList: jobList,
    isName: false,
    isIntroduceSelfFocus: false,
    isWeChatFocus: false,
    isqqFocus: false,
    idCardFocus: false,
  },
  // 上传头像
  uploadFile(event) {
    app.globalData.agriknow.uploadFile(event.detail.file, 1)
      .then(res => {
        wx.showToast({
          title: '更换成功',
          success: () => {
            this.setData({
              avatar: res.path
            })
          }
        })
      })
  },
  confirmSex(event) {
    this.setData({
      gender: parseInt(event.detail.value) + 1
    })
  },
  onConfirmJobYear(event) {

    this.setData({
      'jobYear': this.viewJobYear(event.detail.value),
      jobYears: event.detail.value
    })
  },
  confirmBirth(event) {
    this.setData({
      birthDate: event.detail.value
    })
  },
  // 开户银行
  selectCreateBank() {
    this.setData({
      isCreateBank: true
    })
  },
  // 修改银行卡
  selectBankNum() {
    this.setData({
      isBank: true
    })
  },
  // 下一步
  nextBtn() {
    let {
      name,
      gender,
      jobYears,
      birthDate,
      introduceSelf,
      weChat,
      qqNum,
      idCardNum,
      createBank,
      bankNumber,
      avatar
    } = this.data
    if (!gender) {
      wx.showToast({
        title: '请选择性别！',
        icon: 'none'
      });
      return
    }
    if (!name) {
      wx.showToast({
        title: '请输入姓名！',
        icon: 'none'
      });
      return
    }
    if (!jobYears.length) {
      wx.showToast({
        title: '请选择工作年限！',
        icon: 'none'
      });
      return
    }
    // 输入和没输入都要走
    if ((!weChat || weChat) && !myRegExp.isWechat(weChat)) {
      wx.showToast({
        title: !weChat ? '请输入的微信号' : '请输入正确格式的微信号',
        icon: 'none'
      })
      return
    }
    //身份证
    if ((!idCardNum || idCardNum) && !myRegExp.isIDcard(idCardNum)) {
      wx.showToast({
        title: !idCardNum ? '请输入身份证号' : '请输入正确格式的身份证号',
        icon: 'none'
      })
      return
    }
    // 银行卡号
    if ((!bankNumber || bankNumber) && !myRegExp.luhnCheck(bankNumber)) {
      wx.showToast({
        title: !bankNumber ? '请输入银行卡号' : '请输入正确格式的银行卡号',
        icon: 'none'
      })
      return
    }
    // 只有输入后才去校验，没输入就不管不是必填项
    if (qqNum && !myRegExp.isQQ(this.data.qqNum)) {
      wx.showToast({
        title: '请输入正确格式的QQ号',
        icon: 'none'
      })
      return
    }
    let infoFile = {
      name,
      gender,
      workYear: jobYears.length ? jobYears[0] : 0, // 工作年限
      workMonth: jobYears.length ? jobYears[1] : 0, // 工作月份
      birthDate,
      introduction: introduceSelf, // 自我介绍
      wechat: weChat,
      qq: qqNum,
      cardNum: idCardNum,
      bankName: createBank,
      bankAccount: bankNumber,
      avatar
    }
    if (wx.getStorageSync('_nannySetAccountInfo')) {
      let file = JSON.parse(wx.getStorageSync('_nannySetAccountInfo'))
      Object.assign(infoFile, file)
    }
    wx.setStorageSync('_nannySetAccountInfo', JSON.stringify(infoFile))
    wx.navigateTo({
      url: '/pages/nannyUpload/nannyUpload'
    })
  },
  // 获取 保姆详细资料  回显编辑
  getNurseInfo() {
    app.globalData.agriknow.getParentsSetAccountInfo({
        uid: app.globalData.userInfo().id
      })
      .then(res => {

        if (res.code === 'success') {
          let viewData = {
            avatar: res.data.avatar || '',
            name: res.data.nickName || '',
            gender: res.data.gender || '',
            phone: res.data.phone || app.globalData.userInfo().phone,
            weChat: res.data.wechat || '',
            qqNum: res.data.qq || '',

          }
          if (res.data.nurseInfo) {
            viewData.birthDate = res.data.birthDate || res.data.nurseInfo.birthDate || ''
            viewData.introduceSelf = res.data.introduction || res.data.nurseInfo.introduction || ''
            viewData.jobYear = this.viewJobYear([res.data.workYear || res.data.nurseInfo.workYear || 0, res.data.workMonth || res.data.nurseInfo.workMonth || 0])
            viewData.jobYears = [res.data.workYear || res.data.nurseInfo.workYear || 0, res.data.workMonth || res.data.nurseInfo.workMonth || 0]
            viewData.idCardNum = res.data.nurseInfo.cardNum || ''
            viewData.createBank = res.data.nurseInfo.bankName || ''
            viewData.bankNumber = res.data.nurseInfo.bankAccount || ''
          }
          this.setData(viewData)
          let newlist = this.data.jobYearList.map((item, index) => {
            item.defaultIndex = this.data.jobYears[index]
            return item
          })
          this.setData({
            jobYearList: newlist
          })
        }
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getNurseInfo()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    wx.removeStorageSync('_nannySetAccountInfo')
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},
  nameFocus() {
    this.setData({
      isName: true
    })
  },
  introduceSelfFocus() {
    this.setData({
      isIntroduceSelfFocus: true
    })
  },
  weChatFocus() {
    this.setData({
      isWeChatFocus: true
    })
  },
  qqFocus() {
    this.setData({
      isqqFocus: true
    })
  },
  cardFocus() {
    this.setData({
      idCardFocus: true
    })
  },
  viewJobYear(years) {
    if (years[0] && !years[1]) {
      return years[0] + '年'
    } else if (!years[0] && years[1]) {
      return years[1] + '个月'
    } else if (years[0] && years[1]) {
      return years[0] + '年' + years[1] + '个月'
    } else {
      return '无工作经验'
    }
  },
  // 校验
  checkQQ() {
    if (!this.data.qqNum) return
    if (!myRegExp.isQQ(this.data.qqNum)) {
      wx.showToast({
        title: '请输入正确格式的QQ号码',
        icon: 'none'
      })
    }
  },
  checkWechat() {
    if (!this.data.weChat) return
    if (!myRegExp.isWechat(this.data.weChat)) {
      wx.showToast({
        title: '请输入正确格式的微信号',
        icon: 'none'
      })
    }
  },
  checkCardNum() {
    if (!this.data.idCardNum) return
    if (!myRegExp.isIDcard(this.data.idCardNum)) {
      wx.showToast({
        title: '请输入正确格式的身份证号',
        icon: 'none'
      })
    }
  },
  checkBank() {
    if (!this.data.bankNumber) return
    if (!myRegExp.luhnCheck(this.data.bankNumber)) {
      wx.showToast({
        title: '请输入正确格式的银行卡号',
        icon: 'none'
      })
    }
  }
})
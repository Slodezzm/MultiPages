// pages/availableCoupon/availableCoupon.js
const app = getApp();
import {
  formatTime
} from '../../utils/util'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    // clientHeight: 0,
    isIphoneX: false,
    availableCoupon: [], // 券list
    totalPrice: 0, // 选中的price
    ischeckAll: false, // 全选
    pageNo: 1,
    pageSize: 10,
    next: 0, // 下一页
    loading: false,
    availableCouponSelects: [], // 选中的
    recipientUid: '', // 扫码跳转获取的 保姆id
    nannyName: ''
    // scroll: {
    //   pagination: {
    //     page: 1,
    //     totalPage: true,
    //     limit: 10,
    //   },
    //   refresh: {
    //     type: 'default',
    //     style: 'black',
    //     background: {
    //       color: "#f2f2f2"
    //     },
    //     shake: true
    //   },
    //   loadmore: {
    //     type: 'default',
    //     icon: {
    //       img: 'http://upload-images.jianshu.io/upload_images/5726812-95bd7570a25bd4ee.gif'
    //     },
    //     background: {
    //       color: "#f2f2f2",
    //       // img: 'http://coolui.coolwl.cn/assets/tm_mui_bike.gif'
    //     },
    //     shake: true,
    //     // backgroundImage: 'http://coolui.coolwl.cn/assets/bg.jpg',
    //     title: {
    //       show: true,
    //       text: '加载中',
    //       color: "#999",
    //       shadow: 5
    //     }
    //   }
    // },
  },
  priceSelected(event) {
    let total = 0;
    this.data.availableCoupon.forEach((item, index) => {
      if (event.detail.includes((item.id).toString())) {
        total += parseInt(this.data.availableCoupon[index]['price'])
      }
    })
    this.setData({
      availableCouponSelects: event.detail,
      totalPrice: total
    })
  },
  checkAll(event) {
    let total = 0;
    this.data.availableCoupon.forEach((item, index) => {
      total += parseInt(this.data.availableCoupon[index]['price'])
    })
    this.setData({
      availableCouponSelects: event.detail ? this.data.availableCoupon.map(item => {
        return (item.id).toString()
      }) : [],
      ischeckAll: event.detail,
      totalPrice: event.detail ? total : 0
    })
  },
  // 获取 可用卡券列表
  getScancodeCouponList(data) {
    this.setData({
      loading: true
    })
    app.globalData.agriknow.getScancodeCouponList(data)
      .then(res => {
        this.setData({
          loading: false
        })
        if (res.code === 'success') {
          let list = res.data.records.map(item => {
            item.endTime = formatTime(new Date(item.endTime))
            return item
          })
          if (data.pageNo === 1) {
            this.setData({
              next: res.data.next,
              availableCoupon: list,
            })
          } else {
            let newList = JSON.parse(JSON.stringify(this.data.availableCoupon))
            this.setData({
              messageLists: [...newList, ...list],
              next: res.data.next
            })
          }

        }
      })
  },
  // 使用优惠券 
  useBtn() {
    let self = this
    if (!self.data.availableCouponSelects.length) {
      wx.showToast({
        title: '请选择优惠券',
        icon: 'none'
      })
      return
    }
    if (self.data.recipientUid && self.data.nannyName) {
      wx.showModal({
        content: `确定支付现金券${self.data.totalPrice}元给“${self.data.nannyName}保姆”？`,
        success(res) {
          if (res.confirm) {
            app.globalData.agriknow.useCoupon({
                ids: self.data.availableCouponSelects.map(item => {
                  return parseInt(item)
                }),
                recipientUid: self.data.recipientUid
              })
              .then(res => {
                if (res.code === 'success') {
                  wx.navigateTo({
                    url: `/pages/availableCoupon/useSuccess/index?totalPrice=${self.data.totalPrice}&nannyName=${self.data.nannyName}`,
                  })

                }
              })
          }
        }
      })

    } else {
      wx.showToast({
        title: '获取保姆信息失败!',
        icon: 'none'
      })
    }
  },
  // 暂无优惠券 
  goBack() {
    wx.navigateBack({
      delta: 1
    })
  },
  /** 
   * 生命周期函数--监听页面加载 
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      isIphoneX: app.globalData.Wechat.isIphoneX,
      // clientHeight: (app.globalData.Wechat.clientHeight - app.globalData.Wechat.navHeight) - (app.globalData.Wechat.isIphoneX ? 90 : 60) - 10,
      recipientUid: options.uid,
      nannyName: options.name
    })
    this.getScancodeCouponList({
      pageNo: this.data.pageNo,
      pageSize: this.data.pageSize
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.next) {
      this.getScancodeCouponList({
        pageNo: ++this.data.pageNo,
        pageSize: this.data.pageSize
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
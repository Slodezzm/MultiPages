const app = getApp()

Page({
  data: {
    scrollTop: 0,
    offsetTop: 0,
    id: 0,
    newsDetail: null,
    title: ""
  },
  onLoad(options) {
    this.setData({
      id: options.id,
      title: options.title === 'none' ? '' :  (options.title || '资讯详情'),
      offsetTop: app.globalData.Wechat.navHeight
    })
    this.getNewsDetail()
  },
  onPageScroll(e) {// 页面滚动
    // this.setData({
    //   scrollTop: e.scrollTop
    // })
  },
  getNewsDetail() {
    wx.showLoading()
    app.globalData.agriknow.getNewsDetail({
      id: this.data.id
    }).then(res => {
      wx.hideLoading()
      if (res.code === "success") {
        this.setData({
          newsDetail: res.data
        })
      } else {
        let _this = this
        wx.showModal({
          title: '提示',
          content: '这是一个模态弹窗',
          success (res) {
            if (res.confirm) {
              _this.getNewsDetail()
            } else if (res.cancel) {
              wx.showToast({
                title: '点击右上角...重新进入小程序！',
                icon: 'none',
                duration: 2000
              })
            }
          }
        })
      }
    })
  }
})
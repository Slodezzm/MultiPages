const app = getApp()

Page({
  data: {
    scrollTop: 0,
  },
  onPageScroll(e) {// 页面滚动
    this.setData({
      scrollTop: e.scrollTop
    })
  },
})
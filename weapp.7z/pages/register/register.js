// pages/register/register.js
const app = getApp()
import {
  rulePhone,
  rulePassword
} from '../../utils/util'
Page({
  /** 
   * 页面的初始数据
   */
  data: {
    phone: '',
    password: '',
    code: '123543',
    sendCodeText: '发送验证码',
    isShow: false, // 查看密码
    isexe: false, // 是否发送了验证码
    action: ''
  },
  viewPassword() {
    this.setData({
      isShow: !this.data.isShow
    })
  },
  // login按钮
  submitRegister() {
    if (!rulePhone(this.data.phone)) {
      wx.showToast({
        title: '请输入有效的电话号码！',
        icon: 'none',
      })
      return
    }
    if (!rulePassword(this.data.password)) {
      wx.showToast({
        title: '请输入6-15位并且含有字母的组合！',
        icon: 'none',
      })
      return
    }
    // 调用接口
    app.globalData.agriknow.login({
        loginType: this.data.action === 'register' ? 1 : 3,
        password: this.data.password,
        phone: this.data.phone,
        smsCode: this.data.code,
      }, false)
      .then((result) => {
        wx.showToast({
          title: `${this.data.action === 'register'?'注册成功':'重置成功'}`,
          success: () => {
            setTimeout(() => {
              if (this.data.action === 'register') {
                // 用户信息和 token 存在本地
                wx.setStorageSync("token", result.data.token)
                wx.setStorageSync("userInfo", JSON.stringify(result.data))
                wx.navigateTo({
                  url: '/pages/selectiveID/selectiveID'
                })
              } else if (this.data.action === 'retrievePassword') {
                wx.navigateTo({
                  url: '/pages/accountLogin/accountLogin'
                })
              }
            }, 1000)
          }
        })
      })
  },
  // 发送验证码
  sendCode() {
    if (this.data.isexe) return
    let i = 60;
    let timeout = null
    if (!timeout) {
      timeout = setInterval(() => {
        this.setData({
          sendCodeText: `重新发送(${i--})`,
          isexe: true
        })
        if (i < 0) {
          clearInterval(timeout)
          this.setData({
            sendCodeText: `重新发送`,
            isexe: false
          })
        }
      }, 1000)
    }

  },
  // 失去焦点 校验
  check(e) {
    if (e.currentTarget.dataset.input === 'phone') {
      if (!rulePhone(this.data.phone)) {
        wx.showToast({
          title: '请输入有效的电话号码！',
          icon: 'none',
        })
        return
      }

    } else if (e.currentTarget.dataset.input === 'pwd') {
      if (!rulePassword(this.data.password)) {
        wx.showToast({
          title: '请输入6-15位并且含有字母的组合！',
          icon: 'none',
        })
        return
      }
    }
  },
  // 返回登录页
  accountLogin(){
    wx.navigateBack(-1)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      action: options.action
    })
    // if (options.action === "register") {
    //   this.setData({
    //     action：
    //   })
    // } else if (options.action === "retrievePassword") {
    //   this.setData({
    //     handle: '重置密码'
    //   })
    // }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
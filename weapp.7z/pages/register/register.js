// pages/register/register.js
const app = getApp()
import { rulePhone, rulePassword } from '../../utils/util'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    loading: false,
    navHeight: 0,
    phone: '',
    password: '',
    code: '123543',
    sendCodeText: '发送验证码',
    isShow: false, // 查看密码
    isexe: false // 是否发送了验证码
  },
  viewPassword() {
    this.setData({
      isShow: !this.data.isShow
    })
  },
  // login按钮
  submitRegister() {
    if (!rulePhone(this.data.phone)) {
      wx.showToast({
        title: '请输入有效的电话号码！',
        icon: 'none',
      })
      return
    }
    if (!rulePassword(this.data.password)) {
      wx.showToast({
        title: '请输入6-15位并且含有字母的组合！',
        icon: 'none',
      })
      return
    }
    this.setData({
      loading: true
    })
    // 调用接口
    app.globalData.agriknow.login({
      loginType: 1,
      password: this.data.password,
      phone: this.data.phone,
      smsCode: this.data.code,
    })
      .then((result) => {
        this.setData({
          loading: false
        })
        // 用户信息和 token 存在本地
        wx.setStorageSync("token", result.data.token)
        wx.setStorageSync("userInfo", JSON.stringify(result.data))
        wx.showToast({
          title: result.data.msg,
          icon: 'info',
        })
        wx.navigateTo({
          url: '/pages/selectiveID/selectiveID'
        })
      }).catch((err) => {
        this.setData({
          loading: false
        })
      });
  },
  // 发送验证码
  sendCode() {
    if (this.data.isexe) return
    let i = 60;
    let timeout = null
    if (!timeout) {
      timeout = setInterval(() => {
        this.setData({
          sendCodeText: `重新发送(${i--})`,
          isexe: true
        })
        if (i < 0) {
          clearInterval(timeout)
          this.setData({
            sendCodeText: `重新发送`,
            isexe: false
          })
        }
      }, 1000)
    }

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navHeight: app.globalData.Wechat.navHeight,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
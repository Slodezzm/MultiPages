const app = getApp()

Page({
  data: {
    id: null,
    scrollTop: 0,
    offsetTop: 0,
    theTimeList: [], // 托育时间的基础数据
    timeList: [], // 托育时间段
    isMyself: false,
    myInfo: null,
    childInfoList: null,
    jobInfo: null,
    userInfo: null,
    chatFlag: true
  },
  onLoad: function (options) { //生命周期函数--监听页面加载
    this.setData({
      offsetTop: app.globalData.Wechat.navHeight,
      navHeight: app.globalData.Wechat.navHeight,
      id: options.id,
      myInfo: wx.getStorageSync('userInfo') ? JSON.parse(wx.getStorageSync('userInfo')) : {
        role: -1,
        id: -1
      }
    })
    if (this.data.myInfo.id === -1) {
      return this.toLogin("暂未登录，无法访问")
    }
    this.getPointTimeList()
    this.getJobInfo()
  },
  onShow: function () {
    // this.setData({
    //   chatFlag: this.data.myInfo.role === 1
    // })
  },
  onPageScroll(e) { // 页面滚动
    // this.setData({
    //   scrollTop: e.scrollTop
    // })
  },
  // 获取时间段的基础数据
  getPointTimeList() {
    app.globalData.agriknow.getTimePointList()
      .then(res => {

        let theTimeList = res.data.serviceTimes
        this.setData({
          theTimeList: theTimeList
        })
      })
  },
  toLogin(text) { // 未登录提示登录
    wx.showModal({
      title: text,
      content: '是否跳转到登录页?',
      success(res) {
        if (res.confirm) {
          wx.redirectTo({
            url: "/pages/login/login"
          })
        } else if (res.cancel) {
          wx.showToast({
            title: '请先登录哦！',
            icon: 'none'
          })
        }
      }
    })
  },
  getJobInfo() {
    app.globalData.agriknow.getJobInfo({
      id: this.data.id
    }).then(res => {
      if (res.code === "success") {
        this.setData({
          childInfoList: [...res.data.childInfoList],
          jobInfo: {
            ...res.data.jobInfo
          },
          timeList: [...res.data.jobInfo.serviceTime],
          isMyself: this.data.myInfo.id === res.data.jobInfo.uid
        })
        this.getParentsInfo(res.data.jobInfo.uid)
      }
    })
  },
  attention() { // 关注
    if (this.data.isMyself) return wx.showToast({
      title: '无法关注自己',
      icon: 'none'
    })
    if (this.data.myInfo.id === -1) {
      this.toLogin("暂未登录，无法关注")
      return false
    }
    if (this.data.myInfo.role === 2) {
      wx.showToast({
        title: '角色相同，无法关注',
        icon: 'none'
      })
      return false
    }
    app.globalData.agriknow.attention({
      followerUid: this.data.userInfo.id,
      subscribeFlag: ([1, 0][this.data.userInfo.subscribeFlag])
    }).then(res => {
      if (res.code === "success") {
        wx.showToast({
          title: ["关注成功", "已取消关注"][this.data.userInfo.subscribeFlag],
          icon: "success",
          duration: 1000
        })
        let userInfo = {
          ...this.data.userInfo
        }
        userInfo.subscribeFlag = [1, 0][userInfo.subscribeFlag]
        this.setData({
          userInfo: userInfo
        })
      } else {
        wx.showToast({
          title: res.msg,
          icon: "error",
          duration: 1000
        })
      }
    })
  },
  getParentsInfo(uid) {
    app.globalData.agriknow.getParentsSetAccountInfo({
      uid: uid
    }).then(res => {
      if (res.code === "success") {
        this.setData({
          userInfo: res.data
        })
      } else {
        wx.showToast({
          title: '信息获取失败',
          icon: 'error'
        })
      }
    })
  },
  // 跳转 环信聊天
  connectionUser() {
    app.globalData.agriknow.getMessageCount({type:2})
      .then(res => {
        if (res.code === 'success') {
          if (res.data.remainCount) {
            wx.navigateTo({
              url: `/pages/chatPage/chatPage?huanxinUserName=${this.data.userInfo.huanxinUserName}&name=${this.data.userInfo.nickName}`,
            })
          } else {
            wx.showModal({
              title: '提示',
              content: '站内信消息已用完，立即前往充值！',
              confirmText: '立即充值',
              confirmColor: '#FF6075FF',
              success(res) {
                if (res.confirm) {
                  wx.navigateTo({
                    url: "/pages/setMeal/setMeal"
                  })
                }
              }
            })
          }
        }

      })
  }
})
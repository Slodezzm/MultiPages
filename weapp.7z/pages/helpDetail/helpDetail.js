const app = getApp()

Page({
  data: {
    weeks: ["日","一","二","三","四","五","六"],
    times: ["6AM","9AM","12AM","3PM","6PM","9PM","12PM"],
    frame: [
      [true,true,false,false,true,true,false],
      [true,true,false,false,true,true,false],
      [true,true,false,false,true,true,false],
      [true,true,true,false,true,true,false],
      [true,true,false,false,true,true,false],
      [true,true,false,false,true,true,false],
      [true,true,false,false,true,true,false]
    ],
  }
})
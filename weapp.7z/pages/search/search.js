// pages/search/search.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    height: '',
    navHeight: 0,// nav高度
    keyWord: '', //搜索关键字
    isShow: true, //是否显示历史搜索
    historyList: [], //历史搜索
    active: 0,
    parentList:[{current:0,children:[1,2,3]},{current:0,children:[1,2]},{current:0,children:[1]},{current:0,children:[1]}]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let historyList = wx.getStorageSync('historyList') ? JSON.parse(wx.getStorageSync('historyList')) : []
    this.setData({
      navHeight: app.globalData.Wechat.navHeight,
      historyList
    })

    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          height: res.windowHeight
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  onPageScroll(e) {// 页面滚动
    this.setData({
      scrollTop: e.scrollTop
    })
  },
  historyItem(e) { //点击历史搜索选项
    let word = e.currentTarget.dataset.keyword
    let historyList = wx.getStorageSync('historyList') ? JSON.parse(wx.getStorageSync('historyList')) : []
    historyList.unshift(word)
    historyList = Array.from(new Set(historyList))
    historyList.length > 10 && historyList.pop()
    wx.setStorage({
      key: "historyList",
      data: JSON.stringify(historyList)
    })
    this.setData({
      keyWord: word,
      historyList,
      isShow: false
    })
  },
  changeSearchKey(e) {
    this.setData({
      keyWord: e.detail.keyWord,
    })
    !e.detail.keyWord && this.setData({
      keyWord: e.detail.keyWord,
      isShow: true
    })
  },
  getHistoryList() { //获取搜索列表
    let historyList = wx.getStorageSync('historyList') ? JSON.parse(wx.getStorageSync('historyList')) : []
    this.setData({
      historyList,
      isShow: this.data.keyWord ? false : true
    })
  },
  delHistory(){
    wx.removeStorageSync('historyList')
    this.setData({
      historyList:[]
    })
  }
})

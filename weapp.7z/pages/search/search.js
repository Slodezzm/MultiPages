// pages/search/search.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    height: '',
    navHeight: 0,// nav高度
    keyWord: '', //搜索关键字
    isShow: true, //是否显示历史搜索
    historyList: [], //历史搜索
    active: 0,
    pageNum: 1,
    pageSize: 10,
    next: 1, //是否有下一页
    allList: { newList: [], nurseList: [], parentList: [] },
    newList: [],
    nurseList: [],
    parentList: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let historyList = wx.getStorageSync('historyList') ? JSON.parse(wx.getStorageSync('historyList')) : []
    this.setData({
      navHeight: app.globalData.Wechat.navHeight,
      historyList
    })

    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          height: res.windowHeight
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  onPageScroll(e) {// 页面滚动
    // this.setData({
    //   scrollTop: e.scrollTop
    // })
  },
  lower(e) {// 滚动到底部
    let active = this.data.active
    let next = this.data.next
    active === 1 && next && this.getAmahList()
    active === 2 && next && this.getParentList()
    active === 3 && next && this.getNewsList()
  },
  init() { //初始化搜索列表
    let active = this.data.active
    this.setData({
      pageNum: 1,
      pageSize: 10,
      next: 1,
      allList: { newList: [], nurseList: [], parentList: [] },
      newList: [],
      nurseList: [],
      parentList: []
    })
    active === 0 && this.getSearchAll()
    active === 1 && this.data.next && this.getAmahList()
    active === 2 && this.data.next && this.getParentList()
    active === 3 && this.data.next && this.getNewsList()
  },
  changeActive(e) { //切换tab
    let active = e.detail.index
    this.setData({
      active
    })
    this.init()
  },
  historyItem(e) { //点击历史搜索选项
    let word = e.currentTarget.dataset.keyword
    let historyList = wx.getStorageSync('historyList') ? JSON.parse(wx.getStorageSync('historyList')) : []
    historyList.unshift(word)
    historyList = Array.from(new Set(historyList))
    historyList.length > 10 && historyList.pop()
    wx.setStorage({
      key: "historyList",
      data: JSON.stringify(historyList)
    })
    this.setData({
      keyWord: word,
      historyList,
      isShow: false
    })
    this.init()
  },
  changeSearchKey(e) { //改变搜索关键字
    this.setData({
      keyWord: e.detail.keyWord,
    })
    !e.detail.keyWord && this.setData({
      keyWord: e.detail.keyWord,
      isShow: true
    })
  },
  searchKey() { //点击搜索
    let historyList = wx.getStorageSync('historyList') ? JSON.parse(wx.getStorageSync('historyList')) : []
    this.setData({
      historyList,
      // isShow: this.data.keyWord ? false : true
      isShow: false
    })
    this.init()
  },
  delHistory() { //删除搜索历史
    wx.removeStorageSync('historyList')
    this.setData({
      historyList: []
    })
  },
  getSearchAll() { //搜索全部
    app.globalData.agriknow.search({
      searchValue: this.data.keyWord
    })
      .then((result) => {
        let { newList = [], nurseList = [], parentList = [] } = result.data
        let allList = { newList, nurseList, parentList }
        this.setData({
          allList
        })
      })
  },
  getAmahList() { //搜索保姆
    app.globalData.agriknow.getAmahList({
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize,
      searchValue: this.data.keyWord
    })
      .then((result) => {
        this.setData({
          pageNum: ++this.data.pageNum,
          next: result.data.next,
          nurseList: [...this.data.nurseList, ...result.data.records]
        })
      })
  },
  getParentList() { //搜索家长
    app.globalData.agriknow.getParentList({
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize,
      searchValue: this.data.keyWord
    })
      .then((result) => {
  
        this.setData({
          pageNum: ++this.data.pageNum,
          next: result.data.next,
          parentList: [...this.data.parentList, ...result.data.records]
        })
      })
  },
  getNewsList() { //搜索资讯
    app.globalData.agriknow.getNewsList({
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize,
      searchValue: this.data.keyWord
    })
      .then((result) => {
        this.setData({
          pageNum: ++this.data.pageNum,
          next: result.data.next,
          newList: [...this.data.newList, ...result.data.records]
        })
      })
  },
  attention(e) { //用户关注
    let { followerUid, subscribeFlag } = e.detail
    app.globalData.agriknow.attention({
      followerUid,
      subscribeFlag:subscribeFlag?0:1
    })
      .then((result) => { 
        // 更新列表数据
        this.init()
      })
  }
})

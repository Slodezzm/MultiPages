// custom-tab-bar/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    show: true,
    selected: 2,
    selectedColor: "#45ACFB",
    color: "#666666",
    list: [
      {
        pagePath: "/pages/news/news",
        iconPath: "/image/nav0.png",
        selectedIconPath: "/image/nav0-act.png",
        text: "资讯"
      },
      {
        pagePath: "focus/focus",
        iconPath: "/image/nav1.png",
        selectedIconPath: "/image/nav1-act.png",
        text: "关注"
      },
      {
        pagePath: "/pages/home/home",
        iconPath: "/image/nav2.png",
        selectedIconPath: "/image/nav2.png",
        text: "找服务"
      },
      {
        pagePath: "/pages/message/message",
        iconPath: "/image/nav3.png",
        selectedIconPath: "/image/nav3-act.png",
        text: "消息"
      },
      {
        pagePath: "/pages/mine/mine",
        iconPath: "/image/nav4.png",
        selectedIconPath: "/image/nav4-act.png",
        text: "我的"
      }
    ]
  },

  /**
   * 组件的方法列表
   */
  methods: {
    switchTab(e) {
      wx.switchTab({
        url: e.currentTarget.dataset.path,
      })
      console.log(e.currentTarget.dataset)
      this.setData({
        selected: e.currentTarget.dataset.index
      })
    }
  }
})
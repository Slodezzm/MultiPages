// custom-tab-bar/index.js
const app = getApp()
let disp = require("../utils/broadcast");
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    show: true,
    selected: 2,
    selectedColor: "#45ACFB",
    color: "#666666",
    newMessageNum: 0,
    list: [{
        pagePath: "/pages/news/news",
        iconPath: "/image/nav0.png",
        selectedIconPath: "/image/nav0-act.png",
        text: "资讯"
      },
      {
        pagePath: "/pages/focus/focus",
        iconPath: "/image/nav1.png",
        selectedIconPath: "/image/nav1-act.png",
        text: "关注"
      },
      {
        pagePath: "/pages/home/home",
        iconPath: "/image/nav2.png",
        selectedIconPath: "/image/nav2.png",
        text: "找服务"
      },
      {
        pagePath: "/pages/messageList/messageList",
        iconPath: "/image/nav3.png",
        selectedIconPath: "/image/nav3-act.png",
        text: "消息"
      },
      {
        pagePath: "/pages/mine/mine",
        iconPath: "/image/nav4.png",
        selectedIconPath: "/image/nav4-act.png",
        text: "我的"
      }
    ]
  },
  ready() {
    let self = this
    //收到普通消息
    disp.on('app.onTextMessage', function (message) {
      self.setData({
        newMessageNum: ++ self.data.newMessageNum
      })
    })
    disp.on('app.onAudioMessage', function (message) {
      self.setData({
        newMessageNum:  ++ self.data.newMessageNum
      })
    })
    disp.on('app.tabBar.newMessageNum',function(){
      self.setData({
        newMessageNum:  0
      })
    })
  },
  /**
   * 组件的方法列表
   */
  methods: {
    switchTab(e) {
      let {
        index,
        path
      } = e.currentTarget.dataset
      wx.switchTab({
        url: path,
      })

      this.setData({
        selected: index
      })
    }
  }
})
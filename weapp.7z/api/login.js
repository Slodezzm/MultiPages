
module.exports = {
  login(data) {
    return this._request.postRequest('user/login/login', data).then(res => res.data)
  }
}